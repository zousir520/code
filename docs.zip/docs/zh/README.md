# Vibby.ai 中文文档

欢迎使用 **Vibby.ai** 完整中文文档 —— 您用 SvelteKit 构建 AI 创业公司的综合平台。

## 📖 文档概览

本文档采用 **MECE（互相独立，完全穷尽）** 原则组织，确保全面覆盖且无重叠。

## 🚀 快速开始路径

**初次使用 Vibby.ai？** 请按照推荐的学习路径：

1. **[快速开始指南](./01-getting-started/quick-start.md)** ⚡ *5 分钟*
2. **[安装指南](./01-getting-started/installation.md)** 🔧 *10 分钟*
3. **[基础配置](./01-getting-started/configuration.md)** ⚙️ *15 分钟*
4. **[第一个项目设置](./01-getting-started/first-project.md)** 🎯 *20 分钟*

**总设置时间：约 50 分钟**

## 📚 完整文档章节

### 🎯 01. 入门指南
**适合新手和快速设置**

| 指南 | 描述 | 时间 | 受众 |
|------|------|------|------|
| [快速开始](./01-getting-started/quick-start.md) | 5 分钟内运行起来 | 5 分钟 | 所有人 |
| [安装指南](./01-getting-started/installation.md) | 完整的设置指南 | 10 分钟 | 所有人 |
| [配置指南](./01-getting-started/configuration.md) | 环境和设置 | 15 分钟 | 管理员 |
| [第一个项目](./01-getting-started/first-project.md) | 创建您的第一个网站 | 20 分钟 | 用户 |
| [Sitemap 配置](./sitemap-configuration.md) | SEO sitemap 设置 | 10 分钟 | 开发者 |

### 👤 02. 用户指南
**适合内容创作者和网站管理员**

| 指南 | 描述 | 功能 | 受众 |
|------|------|------|------|
| [内容管理](./02-user-guide/content-management.md) | CMS 和内容编辑 | CMS、页面、媒体 | 内容创作者 |
| [博客管理](./02-user-guide/blog-management.md) | 博客创建和编辑 | 文章、分类、SEO | 博主 |
| [管理仪表板](./02-user-guide/admin-dashboard.md) | 平台管理 | 设置、用户、分析 | 管理员 |
| [SEO 优化](./02-user-guide/seo-optimization.md) | 搜索引擎优化 | 元标签、站点地图、性能 | 营销人员 |

### 🛠️ 03. 开发者指南
**适合开发者和技术实施者**

| 指南 | 描述 | 技术栈 | 受众 |
|------|------|---------|------|
| [技术架构](./03-developer-guide/technical-architecture.md) | 系统设计和结构 | SvelteKit、Supabase、TypeScript | 开发者 |
| [API 集成](./03-developer-guide/api-integration.md) | 使用 API | REST API、认证 | 开发者 |
| [自定义开发](./03-developer-guide/customization.md) | 主题、插件、扩展 | Svelte 组件、CSS | 开发者 |
| [插件开发](./03-developer-guide/plugin-development.md) | 创建自定义插件 | 插件 API、生命周期 | 高级开发者 |

### 🚀 04. 部署指南
**适合部署和运维**

| 指南 | 描述 | 平台 | 受众 |
|------|------|------|------|
| [部署指南](./04-deployment/deployment-guide.md) | 生产环境部署 | Vercel、Netlify、VPS | DevOps |
| [环境设置](./04-deployment/environment-setup.md) | 环境配置 | 变量、密钥 | DevOps |
| [安全最佳实践](./04-deployment/security.md) | 安全加固 | 认证、加密 | 安全工程师 |
| [生产技巧](./04-deployment/production-tips.md) | 优化和监控 | 性能、分析 | DevOps |

### 📡 05. API 参考
**完整的 API 文档**

| 参考 | 描述 | 方法 | 受众 |
|------|------|------|------|
| [API 参考](./05-api/api-reference.md) | 完整的 API 文档 | GET、POST、PUT、DELETE | 开发者 |
| [认证 API](./05-api/authentication.md) | 认证端点和流程 | 登录、注册、OAuth | 开发者 |
| [内容 API](./05-api/content-api.md) | 内容管理 API | CRUD 操作 | 开发者 |
| [管理 API](./05-api/admin-api.md) | 管理端点 | 设置、用户、统计 | 系统集成商 |

### 🔧 06. 故障排除
**问题解决和优化**

| 指南 | 描述 | 涵盖问题 | 受众 |
|------|------|----------|------|
| [常见问题](./06-troubleshooting/common-issues.md) | 常见问题 | 设置、运行时、配置 | 所有人 |
| [错误信息](./06-troubleshooting/error-messages.md) | 错误代码参考 | 错误代码和解决方案 | 开发者 |
| [性能指南](./06-troubleshooting/performance.md) | 优化技术 | 速度、内存、网络 | DevOps |
| [调试指南](./06-troubleshooting/debug-guide.md) | 调试技术 | 工具、技术、日志 | 开发者 |

## 🎯 基于角色的快速访问

### 🏢 **企业主 / 产品经理**
*专注于业务功能和内容管理*
- [快速开始](./01-getting-started/quick-start.md) → [管理仪表板](./02-user-guide/admin-dashboard.md) → [SEO 优化](./02-user-guide/seo-optimization.md)

### ✍️ **内容创作者 / 博主**
*专注于内容创建和管理*
- [内容管理](./02-user-guide/content-management.md) → [博客管理](./02-user-guide/blog-management.md) → [SEO 优化](./02-user-guide/seo-optimization.md)

### 👨‍💻 **前端开发者**
*专注于自定义和主题*
- [技术架构](./03-developer-guide/technical-architecture.md) → [自定义开发](./03-developer-guide/customization.md) → [API 集成](./03-developer-guide/api-integration.md)

### 🔌 **插件开发者**
*专注于扩展平台功能*
- [插件开发](./03-developer-guide/plugin-development.md) → [API 参考](./05-api/api-reference.md) → [调试指南](./06-troubleshooting/debug-guide.md)

### 🚀 **运维工程师**
*专注于部署和运营*
- [部署指南](./04-deployment/deployment-guide.md) → [安全最佳实践](./04-deployment/security.md) → [性能指南](./06-troubleshooting/performance.md)

## 🔍 涵盖的核心功能

### ✨ **核心平台功能**
- **多语言支持** - 内置国际化，轻松切换语言
- **CMS 集成** - 基于 Sveltia CMS 的文件管理系统
- **博客系统** - 功能完整的博客，支持 Markdown
- **管理仪表板** - 综合管理界面
- **插件架构** - 可扩展的插件系统

### 🛠️ **技术功能**
- **SvelteKit 框架** - 现代、快速、高效
- **TypeScript 支持** - 类型安全的开发
- **Supabase 集成** - 数据库和认证
- **性能优化** - 为速度而构建
- **SEO 友好** - 搜索引擎优化

### 🔐 **企业功能**
- **认证系统** - 多种认证提供商
- **基于角色的访问** - 细粒度权限
- **安全加固** - 生产就绪的安全性
- **分析集成** - Microsoft Clarity 等
- **邮件服务** - 事务性邮件

## 📊 文档质量标准

我们的文档保持高标准：

- ✅ **经过测试的代码示例** - 所有代码都经过验证和测试
- ✅ **最新信息** - 与最新代码库同步
- ✅ **清晰的截图** - 在有帮助的地方提供视觉指南
- ✅ **交叉引用** - 章节间轻松导航
- ✅ **移动优化** - 在所有设备上可读

## 🔗 外部资源

- **[GitHub 仓库](https://github.com/gstarwd/vibby.ai)** - 源代码和问题
- **[社区论坛](https://community.vibby.ai)** - 讨论和问答
- **[视频教程](https://youtube.com/vibbyai)** - 可视化学习资源
- **[API 演练场](https://api.vibby.ai)** - 交互式 API 测试

## 🚀 下一步是什么？

准备开始了吗？选择您的路径：

### 🎯 **快速设置**（推荐给大多数用户）
从我们的[快速开始指南](./01-getting-started/quick-start.md)开始，这是让 Vibby.ai 运行的最快方式。

### 🔧 **完整设置**（适合生产部署）
从[安装指南](./01-getting-started/installation.md)开始，进行彻底的设置过程。

### 🛠️ **开发设置**（适合开发者）
跳转到[技术架构](./03-developer-guide/technical-architecture.md)了解系统设计。

---

**需要帮助？** 查看我们的[常见问题](./06-troubleshooting/common-issues.md)或[联系支持](mailto:support@vibby.ai)。

**想要贡献？** 阅读我们的[贡献指南](https://github.com/gstarwd/vibby.ai/blob/main/CONTRIBUTING.md)。