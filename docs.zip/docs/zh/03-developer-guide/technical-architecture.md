# 技术架构指南

理解 **Vibby.ai** 技术架构，使开发者能够有效地构建、自定义和扩展平台。

## 🏗️ 架构概述

Vibby.ai 建立在现代网络技术之上，专为性能、可扩展性和开发者生产力而设计。

### 核心技术栈

**前端框架**
- **SvelteKit**：具有 SSR/SSG 的全栈框架
- **TypeScript**：类型安全的开发
- **TailwindCSS**：实用优先的 CSS 框架
- **Svelte 5**：带有 runes 的最新 Svelte

**后端与服务**
- **Node.js**：JavaScript 运行时
- **Supabase**：数据库和认证（可选）
- **基于文件的 CMS**：Git 驱动的内容管理
- **API 路由**：SvelteKit 服务器端函数

**开发工具**
- **Vite**：快速构建工具和开发服务器
- **ESLint**：代码检查和格式化
- **PostCSS**：CSS 处理和优化
- **pnpm**：快速、高效的包管理器

### 架构图

```
┌─────────────────────────────────────────────────────────────┐
│                    Vibby.ai 架构                            │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐     │
│  │   客户端    │    │   服务器    │    │  外部服务   │     │
│  │  (浏览器)   │    │ (SvelteKit) │    │             │     │
│  └─────────────┘    └─────────────┘    └─────────────┘     │
│         │                   │                   │           │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐     │
│  │   Svelte    │    │ API 路由    │    │  Supabase   │     │
│  │   组件      │◄──►│   +server   │◄──►│   数据库    │     │
│  └─────────────┘    └─────────────┘    └─────────────┘     │
│         │                   │                   │           │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐     │
│  │ TailwindCSS │    │ 内容 API    │    │    SMTP     │     │
│  │   样式      │    │ 文件系统    │    │   邮件      │     │
│  └─────────────┘    └─────────────┘    └─────────────┘     │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                      文件结构                               │
│                                                             │
│  src/                          static/                      │
│  ├── routes/          (页面)   ├── admin/     (CMS)        │
│  ├── lib/             (工具)   ├── images/    (资源)       │
│  ├── content/         (数据)   └── uploads/   (媒体)       │
│  └── app.html         (外壳)                               │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## 📁 项目结构深入分析

### 源代码组织

```
src/
├── app.html                    # HTML 外壳模板
├── app.css                     # 全局样式
├── app.d.ts                    # TypeScript 定义
├── hooks.server.ts             # 服务器端钩子
├── routes/                     # SvelteKit 路由
│   ├── +layout.svelte          # 根布局
│   ├── +layout.server.ts       # 根布局服务器逻辑
│   ├── +page.svelte           # 主页组件
│   ├── +page.server.ts        # 主页服务器逻辑
│   ├── [lang]/                # 国际化路由
│   │   ├── +layout.svelte
│   │   ├── +page.svelte
│   │   ├── blog/
│   │   └── about/
│   ├── api/                   # API 端点
│   │   ├── ping/+server.ts
│   │   ├── blog/+server.ts
│   │   └── admin/
│   ├── vibbyai/               # 管理仪表板
│   │   ├── +layout.svelte
│   │   ├── +page.svelte
│   │   ├── cms/+page.svelte
│   │   └── settings/
│   └── blog/                  # 博客路由
│       ├── +layout.svelte
│       ├── +page.svelte
│       └── [slug]/+page.svelte
├── lib/                       # 共享库
│   ├── components/            # 可重用组件
│   │   ├── ui/               # UI 组件库
│   │   ├── blocks/           # 页面构建块
│   │   ├── blog/             # 博客特定组件
│   │   └── dashboard/        # 管理组件
│   ├── services/             # 业务逻辑服务
│   │   ├── content.ts        # 内容管理
│   │   ├── api-client.ts     # API 工具
│   │   └── auth.ts           # 认证
│   ├── stores/               # Svelte 存储
│   │   ├── siteConfig.ts     # 网站配置
│   │   └── uiText.ts         # UI 文本管理
│   ├── utils/                # 工具函数
│   │   ├── response.ts       # HTTP 响应助手
│   │   └── time.ts           # 日期/时间工具
│   └── types/                # TypeScript 类型定义
│       ├── content.ts        # 内容类型
│       └── api.ts            # API 类型
└── content/                  # 内容文件
    ├── blog/                 # 博客文章
    ├── pages/                # 静态页面
    ├── home/                 # 主页内容
    └── site-config.json      # 网站配置
```

### 配置文件

```
项目根目录/
├── package.json              # 依赖和脚本
├── pnpm-lock.yaml           # pnpm 锁定文件
├── svelte.config.js         # SvelteKit 配置
├── vite.config.ts           # Vite 构建配置
├── tailwind.config.js       # TailwindCSS 配置
├── postcss.config.js        # PostCSS 配置
├── tsconfig.json            # TypeScript 配置
├── .env.example             # 环境变量模板
├── .gitignore               # Git 忽略规则
└── vercel.json              # 部署配置
```

## 🔧 核心系统架构

### 1. 路由系统

#### SvelteKit 基于文件的路由

```typescript
// 路由结构示例
const routeStructure = {
  // 静态路由
  '/': 'src/routes/+page.svelte',
  '/about': 'src/routes/about/+page.svelte',
  '/contact': 'src/routes/contact/+page.svelte',
  
  // 动态路由
  '/blog/[slug]': 'src/routes/blog/[slug]/+page.svelte',
  '/[lang]/blog/[slug]': 'src/routes/[lang]/blog/[slug]/+page.svelte',
  
  // API 路由
  '/api/ping': 'src/routes/api/ping/+server.ts',
  '/api/blog/posts': 'src/routes/api/blog/posts/+server.ts',
  
  // 管理路由
  '/vibbyai': 'src/routes/vibbyai/+page.svelte',
  '/vibbyai/cms': 'src/routes/vibbyai/cms/+page.svelte'
};
```

#### 路由加载模式

```typescript
// +page.server.ts - 服务器端数据加载
export async function load({ params, url }) {
  const { slug } = params;
  
  // 加载博客文章数据
  const post = await getBlogPost(slug);
  
  if (!post) {
    throw error(404, '文章未找到');
  }
  
  return {
    post,
    meta: {
      title: post.title,
      description: post.excerpt
    }
  };
}

// +page.svelte - 客户端组件
<script lang="ts">
  import type { PageData } from './$types';
  
  export let data: PageData;
  
  $: ({ post, meta } = data);
</script>

<svelte:head>
  <title>{meta.title}</title>
  <meta name="description" content={meta.description} />
</svelte:head>

<article>
  <h1>{post.title}</h1>
  <div>{@html post.content}</div>
</article>
```

### 2. 内容管理系统

#### 基于文件的内容架构

```typescript
// 内容加载系统
interface ContentLoader {
  // 加载博客文章
  getBlogPosts(): Promise<BlogPost[]>;
  getBlogPost(slug: string): Promise<BlogPost | null>;
  
  // 加载静态页面
  getPage(slug: string): Promise<Page | null>;
  getPages(): Promise<Page[]>;
  
  // 加载网站配置
  getSiteConfig(): Promise<SiteConfig>;
  getNavigationConfig(): Promise<NavigationConfig>;
}

// 实现
export class FileContentLoader implements ContentLoader {
  private contentDir = 'src/content';
  
  async getBlogPosts(): Promise<BlogPost[]> {
    const files = await glob(`${this.contentDir}/blog/*.md`);
    const posts = await Promise.all(
      files.map(file => this.loadMarkdownFile(file))
    );
    
    return posts
      .filter(post => post.published)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }
  
  private async loadMarkdownFile(filePath: string) {
    const content = await fs.readFile(filePath, 'utf-8');
    const { data: frontmatter, content: body } = matter(content);
    
    return {
      ...frontmatter,
      content: await this.processMarkdown(body),
      slug: this.extractSlug(filePath)
    };
  }
}
```

#### 内容类型定义

```typescript
// 内容的 TypeScript 接口
export interface BlogPost {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  author: Author;
  publishedAt: string;
  updatedAt: string;
  tags: string[];
  categories: string[];
  featured: boolean;
  published: boolean;
  readingTime: number;
  image?: string;
  seo: SEOMetadata;
}

export interface Page {
  id: string;
  title: string;
  slug: string;
  content: string;
  template: string;
  published: boolean;
  updatedAt: string;
  seo: SEOMetadata;
}

export interface SiteConfig {
  siteName: string;
  siteDescription: string;
  siteUrl: string;
  defaultLanguage: string;
  supportedLanguages: string[];
  theme: ThemeConfig;
  features: FeatureConfig;
  contact: ContactInfo;
  social: SocialLinks;
}
```

### 3. API 架构

#### RESTful API 设计

```typescript
// API 路由结构
export const apiRoutes = {
  // 健康和状态
  'GET /api/ping': () => ({ status: 'ok' }),
  'GET /api/health': () => getSystemHealth(),
  
  // 内容端点
  'GET /api/blog/posts': (params) => getBlogPosts(params),
  'GET /api/blog/posts/[slug]': (slug) => getBlogPost(slug),
  'POST /api/blog/posts': (data) => createBlogPost(data),
  
  // 网站配置
  'GET /api/site-config': () => getSiteConfig(),
  'PUT /api/site-config': (data) => updateSiteConfig(data),
  
  // 管理端点
  'GET /api/admin/stats': () => getAdminStats(),
  'POST /api/admin/env-config': (data) => updateEnvConfig(data)
};

// API 响应格式
interface APIResponse<T> {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
    details?: unknown;
  };
  meta?: {
    pagination?: PaginationInfo;
    timestamp: string;
  };
}
```

#### API 实现示例

```typescript
// src/routes/api/blog/posts/+server.ts
import { json } from '@sveltejs/kit';
import type { RequestHandler } from './$types';
import { getBlogPosts } from '$lib/services/content';

export const GET: RequestHandler = async ({ url }) => {
  try {
    const page = Number(url.searchParams.get('page')) || 1;
    const limit = Number(url.searchParams.get('limit')) || 10;
    const tag = url.searchParams.get('tag');
    
    const { posts, total } = await getBlogPosts({ page, limit, tag });
    
    return json({
      success: true,
      data: {
        posts,
        pagination: {
          current: page,
          total: Math.ceil(total / limit),
          hasNext: page * limit < total,
          hasPrev: page > 1
        }
      },
      meta: {
        timestamp: new Date().toISOString()
      }
    });
  } catch (error) {
    return json({
      success: false,
      error: {
        code: 'INTERNAL_ERROR',
        message: '获取博客文章失败'
      }
    }, { status: 500 });
  }
};
```

### 4. 状态管理

#### Svelte 存储架构

```typescript
// 网站配置存储
import { writable, derived } from 'svelte/store';
import type { SiteConfig } from '$lib/types';

// 核心存储
export const siteConfig = writable<SiteConfig | null>(null);
export const currentLanguage = writable<string>('zh');
export const theme = writable<'light' | 'dark'>('light');

// 派生存储
export const siteName = derived(
  siteConfig,
  ($config) => $config?.siteName || 'Vibby.ai'
);

export const supportedLanguages = derived(
  siteConfig,
  ($config) => $config?.supportedLanguages || ['zh']
);

// 存储操作
export const siteConfigActions = {
  async load() {
    const response = await fetch('/api/site-config');
    const config = await response.json();
    siteConfig.set(config.data);
  },
  
  async update(updates: Partial<SiteConfig>) {
    const response = await fetch('/api/site-config', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates)
    });
    
    if (response.ok) {
      const updated = await response.json();
      siteConfig.set(updated.data);
    }
  }
};
```

#### 组件状态模式

```svelte
<!-- 具有响应式状态的组件 -->
<script lang="ts">
  import { onMount } from 'svelte';
  import { siteConfig, theme } from '$lib/stores';
  
  // Props
  export let title: string;
  export let content: string;
  
  // 使用 Svelte 5 runes 的本地状态
  let loading = $state(false);
  let error = $state<string | null>(null);
  
  // 响应式计算
  const isDarkMode = $derived($theme === 'dark');
  const pageTitle = $derived(`${title} | ${$siteConfig?.siteName}`);
  
  // 效果
  onMount(() => {
    // 组件初始化
    loading = false;
  });
  
  // 事件处理器
  function handleAction() {
    loading = true;
    // 异步操作
    setTimeout(() => {
      loading = false;
    }, 1000);
  }
</script>

<div class="page" class:dark={isDarkMode}>
  <h1>{pageTitle}</h1>
  
  {#if loading}
    <div class="loading">加载中...</div>
  {:else if error}
    <div class="error">{error}</div>
  {:else}
    <div class="content">{@html content}</div>
  {/if}
  
  <button onclick={handleAction} disabled={loading}>
    {loading ? '处理中...' : '执行操作'}
  </button>
</div>
```

### 5. 插件架构

#### 插件系统设计

```typescript
// 插件接口
export interface Plugin {
  id: string;
  name: string;
  version: string;
  description: string;
  
  // 生命周期钩子
  onInit?(): Promise<void>;
  onActivate?(): Promise<void>;
  onDeactivate?(): Promise<void>;
  
  // 扩展点
  routes?: PluginRoute[];
  components?: PluginComponent[];
  services?: PluginService[];
  hooks?: PluginHook[];
}

// 插件管理器
export class PluginManager {
  private plugins = new Map<string, Plugin>();
  private activePlugins = new Set<string>();
  
  async loadPlugin(plugin: Plugin) {
    this.plugins.set(plugin.id, plugin);
    
    if (plugin.onInit) {
      await plugin.onInit();
    }
  }
  
  async activatePlugin(pluginId: string) {
    const plugin = this.plugins.get(pluginId);
    if (!plugin) throw new Error(`插件 ${pluginId} 未找到`);
    
    if (plugin.onActivate) {
      await plugin.onActivate();
    }
    
    this.activePlugins.add(pluginId);
  }
  
  getActivePlugins(): Plugin[] {
    return Array.from(this.activePlugins)
      .map(id => this.plugins.get(id)!)
      .filter(Boolean);
  }
}
```

#### 示例插件实现

```typescript
// 游戏插件示例
export const gamePlugin: Plugin = {
  id: 'game-plugin',
  name: '游戏内容插件',
  version: '1.0.0',
  description: '添加游戏相关内容管理功能',
  
  async onInit() {
    console.log('游戏插件已初始化');
  },
  
  routes: [
    {
      path: '/games',
      component: 'GameListPage'
    },
    {
      path: '/games/[slug]',
      component: 'GameDetailPage'
    }
  ],
  
  components: [
    {
      name: 'GameCard',
      component: GameCard
    },
    {
      name: 'GameGrid',
      component: GameGrid
    }
  ],
  
  services: [
    {
      name: 'gameService',
      implementation: new GameService()
    }
  ]
};
```

## 🔐 安全架构

### 认证与授权

#### 认证流程

```typescript
// 认证服务
export class AuthService {
  private sessionStore = writable<Session | null>(null);
  
  async login(credentials: LoginCredentials): Promise<Session> {
    const response = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(credentials)
    });
    
    if (!response.ok) {
      throw new Error('登录失败');
    }
    
    const { session } = await response.json();
    this.sessionStore.set(session);
    
    return session;
  }
  
  async logout(): Promise<void> {
    await fetch('/api/auth/logout', { method: 'POST' });
    this.sessionStore.set(null);
  }
  
  async checkAuth(): Promise<Session | null> {
    try {
      const response = await fetch('/api/auth/status');
      if (response.ok) {
        const { session } = await response.json();
        this.sessionStore.set(session);
        return session;
      }
    } catch (error) {
      // 处理认证检查错误
    }
    
    this.sessionStore.set(null);
    return null;
  }
}
```

#### 授权中间件

```typescript
// 服务器端授权钩子
export async function handleAuth({ event, resolve }) {
  const token = event.cookies.get('session-token');
  
  if (token) {
    try {
      const session = await verifyToken(token);
      event.locals.user = session.user;
      event.locals.session = session;
    } catch (error) {
      // 无效令牌，清除 cookie
      event.cookies.delete('session-token');
    }
  }
  
  return resolve(event);
}

// 路由保护
export function requireAuth(handler: RequestHandler): RequestHandler {
  return async (event) => {
    if (!event.locals.user) {
      return new Response(null, {
        status: 401,
        headers: { 'WWW-Authenticate': 'Bearer' }
      });
    }
    
    return handler(event);
  };
}

// 基于角色的访问控制
export function requireRole(role: string) {
  return function (handler: RequestHandler): RequestHandler {
    return async (event) => {
      const user = event.locals.user;
      
      if (!user || !user.roles.includes(role)) {
        return new Response(null, { status: 403 });
      }
      
      return handler(event);
    };
  };
}
```

### 数据安全

#### 加密和环境变量

```typescript
// 环境配置服务
export class EnvConfigService {
  private encryptionKey: string;
  
  constructor() {
    this.encryptionKey = process.env.ENCRYPTION_SECRET || this.generateKey();
  }
  
  encrypt(value: string): string {
    const cipher = crypto.createCipher('aes-256-cbc', this.encryptionKey);
    let encrypted = cipher.update(value, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    return encrypted;
  }
  
  decrypt(encryptedValue: string): string {
    const decipher = crypto.createDecipher('aes-256-cbc', this.encryptionKey);
    let decrypted = decipher.update(encryptedValue, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
  }
  
  private generateKey(): string {
    return crypto.randomBytes(32).toString('hex');
  }
}
```

## 🚀 性能架构

### 构建优化

#### Vite 配置

```typescript
// vite.config.ts
import { sveltekit } from '@sveltejs/kit/vite';
import { defineConfig } from 'vite';

export default defineConfig({
  plugins: [sveltekit()],
  
  build: {
    rollupOptions: {
      output: {
        manualChunks: {
          // 供应商块
          'vendor-svelte': ['svelte'],
          'vendor-ui': ['@tailwindcss/forms', '@tailwindcss/typography'],
          
          // 应用块
          'admin': ['src/routes/vibbyai'],
          'blog': ['src/routes/blog']
        }
      }
    }
  },
  
  optimizeDeps: {
    include: ['marked', 'gray-matter']
  },
  
  server: {
    port: 5173,
    host: true
  }
});
```

#### 代码分割策略

```typescript
// 用于代码分割的动态导入
export async function loadAdminModule() {
  const { AdminDashboard } = await import('$lib/components/dashboard/AdminDashboard.svelte');
  return AdminDashboard;
}

export async function loadBlogModule() {
  const { BlogPost } = await import('$lib/components/blog/BlogPost.svelte');
  return BlogPost;
}

// 懒加载组件
<script lang="ts">
  import { onMount } from 'svelte';
  
  let AdminComponent: any = null;
  
  onMount(async () => {
    if (userIsAdmin) {
      AdminComponent = await loadAdminModule();
    }
  });
</script>

{#if AdminComponent}
  <svelte:component this={AdminComponent} />
{/if}
```

### 缓存策略

#### 服务器端缓存

```typescript
// 内容缓存服务
export class ContentCache {
  private cache = new Map<string, CacheEntry>();
  private ttl = 5 * 60 * 1000; // 5 分钟
  
  async get<T>(key: string, loader: () => Promise<T>): Promise<T> {
    const cached = this.cache.get(key);
    
    if (cached && cached.expiry > Date.now()) {
      return cached.value;
    }
    
    const value = await loader();
    this.cache.set(key, {
      value,
      expiry: Date.now() + this.ttl
    });
    
    return value;
  }
  
  invalidate(pattern: string) {
    for (const key of this.cache.keys()) {
      if (key.includes(pattern)) {
        this.cache.delete(key);
      }
    }
  }
}

// 在 API 路由中使用
export const GET: RequestHandler = async ({ params }) => {
  const { slug } = params;
  
  const post = await contentCache.get(`blog:${slug}`, () => 
    getBlogPost(slug)
  );
  
  return json({ post });
};
```

## 🔄 开发工作流

### 本地开发设置

```bash
# 开发环境设置
git clone https://github.com/your-repo/vibby.ai.git
cd vibby.ai

# 安装依赖
pnpm install

# 设置环境
cp .env.example .env
# 编辑 .env 配置

# 启动开发服务器
pnpm dev

# 在浏览器中打开
open http://localhost:5173
```

### 构建和部署流程

```bash
# 生产构建
pnpm build

# 预览生产构建
pnpm preview

# 类型检查
pnpm check

# 代码检查
pnpm lint

# 测试（如果配置）
pnpm test
```

### 开发脚本

```json
{
  "scripts": {
    "dev": "vite dev",
    "build": "vite build",
    "preview": "vite preview",
    "check": "svelte-kit sync && svelte-check --tsconfig ./tsconfig.json",
    "check:watch": "svelte-kit sync && svelte-check --tsconfig ./tsconfig.json --watch",
    "lint": "eslint .",
    "format": "prettier --write .",
    "typesafe-i18n": "typesafe-i18n"
  }
}
```

## 🧪 测试架构

### 测试策略

```typescript
// 使用 Vitest 进行单元测试
import { describe, it, expect } from 'vitest';
import { getBlogPost } from '$lib/services/content';

describe('内容服务', () => {
  it('应该通过 slug 加载博客文章', async () => {
    const post = await getBlogPost('test-post');
    
    expect(post).toBeDefined();
    expect(post.title).toBe('测试文章');
    expect(post.published).toBe(true);
  });
  
  it('对于不存在的文章应该返回 null', async () => {
    const post = await getBlogPost('non-existent');
    expect(post).toBeNull();
  });
});

// 使用 Testing Library 进行组件测试
import { render, screen } from '@testing-library/svelte';
import BlogPost from '$lib/components/blog/BlogPost.svelte';

describe('BlogPost 组件', () => {
  it('渲染博客文章内容', () => {
    const post = {
      title: '测试文章',
      content: '<p>测试内容</p>',
      author: '测试作者'
    };
    
    render(BlogPost, { props: { post } });
    
    expect(screen.getByText('测试文章')).toBeInTheDocument();
    expect(screen.getByText('测试内容')).toBeInTheDocument();
  });
});
```

### E2E 测试设置

```typescript
// Playwright E2E 测试
import { test, expect } from '@playwright/test';

test('主页正确加载', async ({ page }) => {
  await page.goto('/');
  
  await expect(page).toHaveTitle(/Vibby.ai/);
  await expect(page.locator('h1')).toContainText('构建您的 AI 创业公司');
});

test('博客导航工作正常', async ({ page }) => {
  await page.goto('/');
  await page.click('text=博客');
  
  await expect(page).toHaveURL('/blog');
  await expect(page.locator('h1')).toContainText('博客');
});

test('管理仪表板需要认证', async ({ page }) => {
  await page.goto('/vibbyai');
  
  // 应该重定向到登录或显示登录表单
  await expect(page).toHaveURL(/login/);
});
```

## 📊 监控和分析

### 性能监控

```typescript
// 性能跟踪服务
export class PerformanceService {
  private metrics = new Map<string, PerformanceMetric>();
  
  startMeasure(name: string) {
    performance.mark(`${name}-start`);
  }
  
  endMeasure(name: string) {
    performance.mark(`${name}-end`);
    performance.measure(name, `${name}-start`, `${name}-end`);
    
    const measure = performance.getEntriesByName(name)[0];
    this.recordMetric(name, measure.duration);
  }
  
  private recordMetric(name: string, duration: number) {
    // 发送到分析服务
    if (typeof window !== 'undefined' && window.gtag) {
      window.gtag('event', 'timing_complete', {
        name: name,
        value: Math.round(duration)
      });
    }
  }
}
```

### 错误跟踪

```typescript
// 错误处理服务
export class ErrorService {
  static handleError(error: Error, context?: any) {
    console.error('应用程序错误:', error, context);
    
    // 发送到错误跟踪服务
    if (typeof window !== 'undefined') {
      // 示例：Sentry 集成
      // Sentry.captureException(error, { extra: context });
    }
  }
  
  static handleApiError(response: Response, context?: any) {
    const error = new Error(`API 错误: ${response.status} ${response.statusText}`);
    this.handleError(error, { ...context, url: response.url });
  }
}
```

---

**🏗️ 技术架构掌握完毕！** 您现在了解了 Vibby.ai 的完整技术基础，可以有效地构建、自定义和扩展平台。

**下一步**：[学习 API 集成](./api-integration.md) 或 [探索自定义选项](./customization.md)