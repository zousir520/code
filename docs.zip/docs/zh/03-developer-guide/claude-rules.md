# Claude.md 规则配置

本指南说明如何配置和使用 `CLAUDE.md` 文件，为 Claude Code 在您的 Vibby.ai 项目中工作时提供上下文和指导。

## 📖 概述

`CLAUDE.md` 文件作为 Claude Code 的综合参考，包含：
- 基本开发命令
- 项目架构概述
- 关键规则和约束
- 开发指南
- 常见故障排除信息

## 📁 文件位置

`CLAUDE.md` 文件应放置在项目根目录：

```
vibby.ai/
├── CLAUDE.md          # ← 主要 Claude 指令
├── package.json
├── src/
└── docs/
```

## 🏗️ CLAUDE.md 结构

### 1. 基本命令部分

始终包含最常用的开发命令：

```markdown
## 基本命令

### 开发
```bash
# 启动开发服务器
pnpm dev

# 生产构建
pnpm build

# 预览生产构建
pnpm preview

# 类型检查
pnpm check

# 数据库迁移
pnpm db:migrate
```

### 测试和验证
```bash
# 检查项目规则合规性
pnpm check:rules

# 验证 Svelte 组件
pnpm check:watch
```
```

### 2. 关键项目规则

定义不可协商的项目约束：

```markdown
## 关键项目规则

**⚠️ 进行任何更改前必须阅读 PROJECT_RULES.md**

### 核心设计原则
1. **CMS 页面设计**: `/vibbyai/cms` 必须使用 iframe 嵌入到 Sveltia CMS
2. **数据源策略**: CONTENT_STRATEGY 是 `CMS_ONLY` - 无 GitHub API 后备
3. **仅 Svelte 5**: 使用 `$state`、`$derived`、`onclick` 语法
4. **文档**: 所有文档仅放在 `docs/` 目录中

### 禁止操作
- 将 CMS iframe 更改为独立页面或卡片布局
- 重新启用 GitHub API 或添加多个数据源后备
- 使用 Svelte 4 语法或已弃用的功能
- 创建除 `docs/` 之外的文档目录
```

### 3. 架构概述

提供清晰的架构上下文：

```markdown
## 架构概述

### 多站点平台
这是一个**可作为 3 种不同站点类型运行的统一平台**：
- **site-tool**: 工具/SaaS 着陆页
- **site-blog**: 博客导向网站
- **site-game**: 游戏平台

站点类型由 `PUBLIC_SITE_TYPE` 环境变量确定。

### 数据存储策略
**具有明确分离的混合方法**：
- **静态内容** (CMS): `src/content/` → 博客文章、页面、设置
- **动态数据** (数据库): Supabase → 用户数据、反向链接、SEO 进度
- **优先级顺序**: 环境变量 → 数据库 → 本地文件 → 默认值
```

### 4. 目录结构

包含关键目录映射：

```markdown
### 关键目录结构
```
src/
├── routes/
│   ├── vibbyai/          # 管理仪表板（受保护）
│   ├── api/              # API 端点
│   ├── [lang]/           # 多语言路由 (en, zh)
│   └── blog/             # 博客系统
├── lib/
│   ├── components/       # 可重用 UI 组件
│   │   ├── site-*/       # 站点类型特定组件
│   │   └── ui/           # shadcn/ui 组件
│   ├── services/         # 业务逻辑
│   ├── stores/           # Svelte stores
│   └── types/            # TypeScript 定义
├── content/              # CMS 内容文件
└── static/admin/         # Sveltia CMS 配置
```
```

### 5. 开发指南

指定编码标准和模式：

```markdown
## 开发指南

### Svelte 5 语法
```svelte
<!-- 正确 -->
<script>
  let count = $state(0);
  let doubled = $derived(count * 2);
</script>

<button onclick={() => count++}>

<!-- 错误（已弃用） -->
<script>
  let count = 0;
  $: doubled = count * 2;
</script>

<button on:click={() => count++}>
```

### API 模式
```typescript
// 成功
return json({ success: true, data: result });

// 错误
return json({ error: '错误信息' }, { status: 500 });
```
```

### 6. 环境配置

记录必需的环境变量：

```markdown
## 部署 (Vercel)

### 环境变量
生产环境必需：
```env
PUBLIC_SUPABASE_URL=your_supabase_url
PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
PUBLIC_SITE_TYPE=site-tool  # 或 site-blog, site-game
```
```

### 7. 常见问题

包含故障排除信息：

```markdown
## 常见问题

### 数据库连接
如果 Supabase 连接失败，API 在开发中会优雅地回退到文件系统。检查环境变量和网络连接。

### 内容不加载
验证内容文件存在于 `src/content/` 中并遵循正确的命名约定。检查控制台是否有文件系统错误。

### 构建失败
本地运行 `pnpm check` 以捕获 TypeScript 错误。确保所有导入使用正确的路径并且类型正确定义。
```

## 🎯 Claude.md 最佳实践

### 1. 保持简洁

- 专注于 Claude Code 需要的基本信息
- 避免重复其他地方存在的文档
- 使用清晰、可操作的语言

### 2. 定期更新

- 保持命令和脚本最新
- 立即更新架构更改
- 反映当前项目约束

### 3. 使用示例

始终为以下内容提供代码示例：
- API 响应格式
- 组件结构
- 常见模式
- 错误处理

### 4. 优先考虑关键信息

将最重要的约束和模式放在顶部：
- 禁止操作
- 必需语法
- 破坏性更改

## 🔧 与开发工作流程的集成

### 1. 新开发者入职

CLAUDE.md 作为第一个参考点：

```bash
# 新开发者工作流程
1. 阅读 CLAUDE.md
2. 运行 pnpm check:rules
3. 设置环境变量
4. 使用 pnpm dev 开始开发
```

### 2. 代码审查过程

在审查期间参考 CLAUDE.md：
- 验证是否遵守既定规则
- 检查新模式是否需要文档
- 确保与架构原则的一致性

### 3. 自动合规性

在自动检查中使用 CLAUDE.md 规则：

```bash
# 添加到 CI/CD 管道
pnpm check:rules
pnpm check:claude-compliance
```

## 📋 CLAUDE.md 模板

这是您项目的完整模板：

```markdown
# CLAUDE.md

本文件为 Claude Code 在此仓库中工作时提供指导。

## 基本命令

### 开发
```bash
pnpm dev          # 启动开发服务器
pnpm build        # 生产构建
pnpm check        # 类型检查
```

## 关键项目规则

### 核心原则
1. [您的特定规则 1]
2. [您的特定规则 2]
3. [您的特定规则 3]

### 禁止操作
- [禁止操作 1]
- [禁止操作 2]

## 架构概述

[架构的简要描述]

### 关键组件
- [组件 1]: [描述]
- [组件 2]: [描述]

## 开发指南

### [技术] 标准
[特定编码标准]

### API 模式
[标准 API 模式]

## 常见问题

### [问题类别]
[解决方法]
```

## 🎯 高级 CLAUDE.md 功能

### 1. 上下文感知指令

根据文件类型提供不同的指令：

```markdown
## 文件类型特定指南

### 处理 `.svelte` 文件时：
- 始终使用 Svelte 5 语法
- 为 props 包含 TypeScript 接口
- 尽可能使用 shadcn/ui 组件

### 处理 API 路由 (`+server.ts`) 时：
- 实现适当的错误处理
- 使用标准响应格式
- 包含请求/响应类型定义

### 处理内容文件时：
- 遵循多语言命名约定
- 验证 frontmatter 结构
- 保持一致的格式
```

### 2. 决策树

帮助 Claude 做出架构决策：

```markdown
## 组件决策树

创建新组件时：

1. **是否与 UI 相关？**
   - 是 → 使用 `src/lib/components/ui/`
   - 否 → 继续到 #2

2. **是否特定于站点类型？**
   - 是 → 使用 `src/lib/components/site-{type}/`
   - 否 → 使用 `src/lib/components/common/`

3. **是否处理数据？**
   - 是 → 考虑是否需要 `src/lib/services/` 中的服务
   - 否 → 仅组件
```

### 3. 性能指南

包含性能考虑：

```markdown
## 性能考虑

### 加载策略
- 对大型组件使用动态导入
- 实现适当的加载状态
- 使用 Vercel 优化优化图片

### 状态管理
- 尽可能优先使用本地组件状态
- 对跨组件共享状态使用 stores
- 在效果中实现适当的清理
```

通过维护一个全面且最新的 CLAUDE.md 文件，您可以确保 Claude Code 拥有提供准确、一致的 Vibby.ai 项目开发帮助所需的所有上下文。