# Roo Code 规则指南

本指南说明如何使用 `.roo-rules` 文件来规范您的 Vibby.ai 项目开发。

## 📖 快速开始

### 1. 检查项目合规性

```bash
# 检查 Roo Rules 合规性
pnpm check:roo

# 检查原有项目规则
pnpm check:rules

# 同时检查所有规则
pnpm check:all
```

### 2. 理解检查结果

检查脚本会输出详细的合规性报告：

```
🔍 检查 Roo Rules 合规性...
=====================================

1. 检查必需文件...
✅ 必需文件: .roo-rules
✅ 必需文件: CLAUDE.md
❌ 必需文件: some-file.json
   → 文件不存在

...

📊 检查统计:
   总检查项: 45
   通过: 40
   失败: 5
   通过率: 89%

🎯 规范遵循度评级:
   🥈 良好 (80-89%) - 代码基本符合规范，有少量改进空间
```

## 🎯 核心规范说明

### Svelte 5 语法要求

#### ✅ 正确用法

```svelte
<!-- 新的 props 语法 -->
<script lang="ts">
  interface Props {
    title: string;
    count?: number;
  }
  
  let { title, count = 0 }: Props = $props();
  let doubled = $derived(count * 2);
  let message = $state('Hello');
</script>

<!-- 新的事件处理语法 -->
<button onclick={() => count++}>
  {title}: {count}
</button>
```

#### ❌ 过时用法（禁止）

```svelte
<!-- 过时的 props 语法 -->
<script lang="ts">
  export let title: string;  // ❌ 禁止
  export let count = 0;      // ❌ 禁止
  
  $: doubled = count * 2;    // ❌ 禁止
</script>

<!-- 过时的事件语法 -->
<button on:click={() => count++}>  <!-- ❌ 禁止 -->
  {title}: {count}
</button>
```

### TypeScript 类型定义

#### ✅ 推荐的类型定义模式

```typescript
// 1. 组件 Props 接口
interface ComponentProps {
  data: SiteConfig;
  currentLang: 'en' | 'zh';
  variant?: 'default' | 'secondary';
  className?: string;
}

// 2. API 响应类型
interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
}

// 3. 站点配置类型
interface SiteConfig {
  type: 'site-tool' | 'site-blog' | 'site-game';
  title: string;
  description: string;
  features?: FeatureConfig[];
}

// 4. 使用严格类型的函数
function processApiData(response: ApiResponse<SiteConfig>): SiteConfig {
  if (!response.success || !response.data) {
    throw new Error(response.error || 'Invalid response');
  }
  return response.data;
}
```

### 组件设计系统

#### shadcn/ui 组件使用示例

```svelte
<script lang="ts">
  import { Button } from '$lib/components/ui/button';
  import { Card, CardContent, CardHeader, CardTitle } from '$lib/components/ui/card';
  import { Badge } from '$lib/components/ui/badge';
  import { cn } from '$lib/utils';
  
  interface Props {
    title: string;
    description: string;
    variant?: 'default' | 'secondary';
    className?: string;
  }
  
  let { title, description, variant = 'default', className }: Props = $props();
</script>

<Card class={cn('w-full max-w-md', className)}>
  <CardHeader>
    <CardTitle class="flex items-center gap-2">
      {title}
      <Badge {variant}>{variant}</Badge>
    </CardTitle>
  </CardHeader>
  <CardContent>
    <p class="text-muted-foreground mb-4">{description}</p>
    <Button variant="default" size="lg" onclick={() => console.log('clicked')}>
      操作按钮
    </Button>
  </CardContent>
</Card>
```

## 🔧 开发工作流

### 1. 新组件开发流程

```bash
# 1. 创建组件文件（使用 PascalCase）
touch src/lib/components/ui/MyNewComponent.svelte

# 2. 编写组件代码（遵循 Svelte 5 语法）
# 3. 添加 TypeScript 类型定义
# 4. 使用 tailwind-variants 定义样式变体
# 5. 运行检查
pnpm check:roo

# 6. 修复发现的问题
# 7. 再次检查直到通过
```

### 2. API 开发流程

```bash
# 1. 创建 API 路由
touch src/routes/api/my-endpoint/+server.ts

# 2. 实现标准的错误处理和响应格式
# 3. 添加 TypeScript 类型定义
# 4. 测试 API 端点
curl http://localhost:5174/api/my-endpoint

# 5. 运行完整检查
pnpm check:all
```

## ❌ 常见错误和解决方案

### 1. Svelte 5 语法错误

**错误**：使用过时的 `export let` 语法
```svelte
<!-- ❌ 错误 -->
<script>
  export let title: string;
</script>
```

**解决**：使用新的 `$props()` 语法
```svelte
<!-- ✅ 正确 -->
<script lang="ts">
  interface Props {
    title: string;
  }
  let { title }: Props = $props();
</script>
```

### 2. TypeScript 类型缺失

**错误**：缺少类型定义
```typescript
// ❌ 错误
let data: any = await response.json();
```

**解决**：定义明确的类型
```typescript
// ✅ 正确
interface ApiData {
  id: string;
  name: string;
}
let data: ApiData = await response.json();
```

### 3. API 错误处理缺失

**错误**：没有错误处理
```typescript
// ❌ 错误
export async function GET() {
  const data = await getUser();
  return json(data);
}
```

**解决**：添加完整的错误处理
```typescript
// ✅ 正确
export async function GET() {
  try {
    const data = await getUser();
    return json({ success: true, data });
  } catch (error) {
    console.error('API Error:', error);
    return json({ success: false, error: '获取用户失败' }, { status: 500 });
  }
}
```

## 🎯 性能优化建议

### 1. 组件懒加载

对于大型组件，使用动态导入：

```svelte
<script lang="ts">
  import { onMount } from 'svelte';
  
  let HeavyComponent: any = null;
  
  onMount(async () => {
    const module = await import('$lib/components/HeavyComponent.svelte');
    HeavyComponent = module.default;
  });
</script>

{#if HeavyComponent}
  <svelte:component this={HeavyComponent} {props} />
{:else}
  <div class="animate-pulse">加载中...</div>
{/if}
```

### 2. 图片优化

使用适当的图片优化策略：

```svelte
<!-- 使用 Vercel 图片优化 -->
<img 
  src="/api/og-image/{slug}" 
  alt={title}
  loading="lazy"
  class="w-full h-auto rounded-lg" 
/>
```

## 📚 进一步学习

- [Svelte 5 官方文档](https://svelte.dev/docs/svelte/overview)
- [SvelteKit 文档](https://kit.svelte.dev/docs)
- [shadcn/ui 组件库](https://ui.shadcn.com/)
- [Tailwind CSS 文档](https://tailwindcss.com/docs)
- [TypeScript 最佳实践](https://www.typescriptlang.org/docs/)

通过遵循这些规范和最佳实践，您将能够构建高质量、可维护的 Vibby.ai 应用程序。