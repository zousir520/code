# 开发工具配置

本节包含为您的 Vibby.ai 项目配置各种 AI 驱动开发工具的全面指南。

## 📚 可用指南

### 1. [Roo Code 规则](./roo-code-rules.md)
学习如何使用 `.roo-rules` 文件来标准化项目开发，包含自动化合规性检查。

**主要功能：**
- 自动化代码合规性检查
- Svelte 5 语法强制执行
- TypeScript 类型安全验证
- 组件架构指导

### 2. [Cursor IDE 规则](./cursor-rules.md)
使用 `.cursorrules` 文件为 Vibby.ai 开发配置 Cursor IDE 的适当规则。

**主要功能：**
- Cursor IDE 配置
- AI 驱动的代码建议
- 项目特定模板
- 代码质量强制执行

### 3. [Claude.md 配置](./claude-rules.md)
使用 `CLAUDE.md` 文件为 Claude Code 设置全面的项目上下文。

**主要功能：**
- 项目架构文档
- 开发指南
- 常见故障排除
- 基本命令参考

### 4. [Augment Code 规则](./augment-code-rules.md)
使用自定义规则和模板配置 Augment Code 以获得最佳开发体验。

**主要功能：**
- AI 助手配置
- 自定义代码模板
- 项目特定快捷方式
- 团队协作工具

## 🚀 快速开始

### 1. 选择您的工具

选择您要使用的 AI 开发工具：

```bash
# 对于 Roo Code 用户
pnpm check:roo

# 对于 Cursor IDE 用户
# 配置 .cursorrules 文件

# 对于 Claude Code 用户
# 确保 CLAUDE.md 是最新的

# 对于 Augment Code 用户
augment init
```

### 2. 通用设置

所有工具都受益于这些项目配置：

```bash
# 确保 TypeScript 正确配置
pnpm check

# 验证 Svelte 5 语法合规性
pnpm check:rules

# 运行完整项目验证
pnpm check:all
```

### 3. 工具特定设置

遵循各个指南获得每个工具的详细设置说明。

## 🎯 通用原则

本项目中的所有开发工具都遵循这些核心原则：

### 1. 仅使用 Svelte 5 语法
```svelte
<!-- ✅ 正确 -->
<script lang="ts">
  interface Props {
    title: string;
  }
  let { title }: Props = $props();
  let count = $state(0);
</script>

<button onclick={() => count++}>
  {title}: {count}
</button>
```

### 2. 全面使用 TypeScript
- 所有组件使用 TypeScript
- 适当的接口定义
- 没有正当理由不使用 `any` 类型
- 启用严格类型检查

### 3. 组件架构
```
src/lib/components/
├── ui/                 # shadcn/ui 组件
├── site-tool/         # 工具特定组件
├── site-blog/         # 博客特定组件  
├── site-game/         # 游戏特定组件
└── common/            # 共享组件
```

### 4. API 标准
```typescript
// 标准响应格式
return json({ success: true, data: result });
return json({ success: false, error: 'Message' }, { status: 500 });
```

### 5. 多站点支持
- 站点类型由 `PUBLIC_SITE_TYPE` 确定
- 动态组件选择
- 基于环境的配置

## 🔧 开发工作流程

### 1. 初始设置
```bash
# 克隆和安装
git clone your-repo
cd your-repo
pnpm install

# 配置您首选的 AI 工具
# 查看各个指南获得设置说明
```

### 2. 日常开发
```bash
# 开始开发
pnpm dev

# 频繁运行检查
pnpm check:rules

# 提交前
pnpm check:all
```

### 3. 代码审查过程
- 验证工具配置是否被遵循
- 检查 Svelte 5 标准的合规性
- 确保 TypeScript 类型安全
- 验证组件架构

## 📋 配置检查清单

使用此检查清单确保所有工具都正确配置：

### 项目文件
- [ ] `CLAUDE.md` 存在且是最新的
- [ ] `.cursorrules` 已配置（如果使用 Cursor）
- [ ] `.roo-rules` 已配置（如果使用 Roo Code）
- [ ] `.augment/` 目录已设置（如果使用 Augment Code）

### 代码标准
- [ ] 所有组件使用 Svelte 5 语法
- [ ] TypeScript 接口已定义
- [ ] API 端点遵循标准格式
- [ ] 组件按站点类型组织

### 开发环境
- [ ] IDE 配置了适当的扩展
- [ ] 代码检查和格式化规则处于活动状态
- [ ] 类型检查已启用
- [ ] 热重载正常工作

### 团队协作
- [ ] 所有团队成员使用相同的工具配置
- [ ] 文档已更新任何自定义规则
- [ ] CI/CD 管道包含规则检查

## 🎯 最佳实践

### 1. 保持配置同步
- 当项目规则更改时更新所有工具配置
- 在不同 AI 助手之间保持一致性
- 记录任何工具特定的例外情况

### 2. 定期维护
- 每月审查和更新规则
- 跟上框架更新的步伐
- 记录新出现的模式

### 3. 团队采用
- 确保所有团队成员理解配置
- 提供工具特定功能的培训
- 维护共享配置文件

### 4. 持续改进
- 监控代码质量指标
- 收集工具有效性反馈
- 根据项目需求迭代配置

## 🚨 故障排除

### 常见问题

#### 工具冲突
如果多个 AI 工具给出冲突建议：
1. 优先项目特定规则（CLAUDE.md，.roo-rules）
2. 遵循 Svelte 5 语法标准
3. 维护 TypeScript 类型安全

#### 配置偏移
如果配置变得不一致：
1. 审查所有工具配置文件
2. 更新以匹配当前项目标准
3. 在所有工具中运行合规性检查

#### 性能问题
如果 AI 工具减慢开发：
1. 优化配置复杂性
2. 减少实时分析范围
3. 使用选择性工具激活

### 获取帮助

1. **检查各个指南**：每个工具都有特定的故障排除部分
2. **项目文档**：参考 `CLAUDE.md` 获得项目特定指导
3. **团队资源**：就配置最佳实践咨询团队成员

通过遵循这些开发工具配置，您将创建一个一致、高效的开发环境，利用 AI 辅助同时保持高代码质量标准。