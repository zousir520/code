# Vibby.ai 多平台部署指南

## 🎯 项目概述

Vibby.ai 现已支持多平台部署，实现了"一份代码，多平台运行"的目标。项目经过重构，完全兼容 Cloudflare Workers 和 Vercel 平台。

### ✅ 支持的平台

| 平台 | 状态 | 适配器 | 运行时 |
|------|------|--------|---------|
| **Vercel** | ✅ 完全支持 | `@sveltejs/adapter-vercel` | Node.js Edge Runtime |
| **Cloudflare Workers** | ✅ 完全支持 | `@sveltejs/adapter-cloudflare` | V8 Isolates |

## 🏗️ 技术架构重构

### 关键改进

1. **文件系统操作平台化**
   - 将所有文件系统操作重构为平台无关的数据访问
   - 实现环境检测和优雅降级
   - 动态导入避免构建时 Node.js 模块解析

2. **数据持久化策略**
   - **主要方案**: Supabase 数据库（两平台通用）
   - **备用方案**: 文件系统（仅 Node.js 环境）
   - 智能环境检测自动选择最佳方案

3. **内容预编译系统**
   - 构建时将 `content/` 目录预编译为 JavaScript 模块
   - 消除运行时文件系统依赖
   - 支持 Markdown、JSON 等多种格式

4. **邮件服务适配**
   - 替换 Nodemailer 为通用 HTTP API 调用
   - 支持多种邮件服务提供商
   - 平台无关的邮件发送逻辑

## 🚀 构建和部署

### 环境变量配置

创建 `.env.local` 文件：

```bash
# 基础配置
NODE_ENV=production
PUBLIC_SITE_URL=https://your-domain.com

# Supabase 配置（推荐 - 两平台通用）
PUBLIC_SUPABASE_URL=https://your-project.supabase.co
PUBLIC_SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-key

# 安全配置
ENCRYPTION_SECRET=your-48-character-encryption-key

# SMTP 配置（可选）
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password
SMTP_FROM=noreply@your-domain.com

# 分析工具（可选）
GOOGLE_ANALYTICS_ID=G-XXXXXXXXXX
MICROSOFT_CLARITY_ID=xxxxxxxxx
```

### 1. Vercel 部署

#### 自动部署（推荐）

```bash
# 1. 安装 Vercel CLI
npm i -g vercel

# 2. 登录 Vercel
vercel login

# 3. 构建并部署
npm run build:vercel
vercel --prod
```

#### 手动部署

1. 在 Vercel Dashboard 中连接 GitHub 仓库
2. 设置构建命令：`npm run build:vercel`
3. 设置输出目录：`.svelte-kit/output`
4. 配置环境变量
5. 点击部署

#### Vercel 配置文件

项目包含 `vercel.json` 配置：

```json
{
  "buildCommand": "npm run build:vercel",
  "outputDirectory": ".svelte-kit/output",
  "framework": "svelte",
  "functions": {
    "app/server.js": {
      "maxDuration": 30
    }
  }
}
```

### 2. Cloudflare Workers 部署

#### 使用 Wrangler CLI

```bash
# 1. 安装 Wrangler
npm install -g wrangler

# 2. 登录 Cloudflare
wrangler auth login

# 3. 构建项目
npm run build:cloudflare

# 4. 部署到 Cloudflare Workers
wrangler pages deploy .svelte-kit/output/client --project-name vibby-ai

# 5. 部署 Worker（如果需要）
wrangler deploy .svelte-kit/output/server/index.js
```

#### 环境变量配置

在 Cloudflare Dashboard 中设置：

1. 进入 Workers & Pages > 你的项目
2. 点击 "Settings" > "Environment variables"
3. 添加所有必要的环境变量

## 📦 构建脚本说明

### 可用命令

```bash
# 内容预编译
npm run build:content

# Vercel 构建
npm run build:vercel

# Cloudflare 构建  
npm run build:cloudflare

# 开发服务器
npm run dev

# 预览构建结果
npm run preview
```

### 构建流程

1. **内容预编译** (`build:content`)
   - 扫描 `src/content/` 目录
   - 转换 Markdown、JSON 文件为 TypeScript 模块
   - 生成 `src/lib/generated/content.ts`

2. **平台特定构建**
   - 根据 `ADAPTER` 环境变量选择适配器
   - 优化代码为目标平台
   - 生成平台特定的输出文件

## 🔧 平台差异和注意事项

### Cloudflare Workers 限制

1. **运行时限制**
   - 无文件系统访问
   - 无 Node.js 原生模块
   - CPU 执行时间限制
   - 内存使用限制

2. **解决方案**
   - 使用预编译内容系统
   - 依赖 Supabase 存储数据
   - 实现环境检测和优雅降级

### Vercel 特性

1. **优势**
   - 完整 Node.js 运行时支持
   - 文件系统访问
   - 更长的执行时间限制

2. **配置**
   - 支持 Serverless Functions
   - Edge Runtime 可选
   - 自动 CDN 分发

## 🛠️ 故障排除

### 常见问题

#### 1. 构建失败：`fs/promises` 模块错误

**解决方案**：
```bash
# 清理构建缓存
rm -rf .svelte-kit

# 重新构建
npm run build:cloudflare
```

#### 2. 环境变量未生效

**检查项**：
- 确保 `.env.local` 文件存在
- 验证环境变量名称正确
- 在部署平台中重新设置环境变量

#### 3. Supabase 连接失败

**解决方案**：
```bash
# 测试 Supabase 连接
npm run test:supabase

# 检查 URL 和密钥配置
echo $PUBLIC_SUPABASE_URL
echo $PUBLIC_SUPABASE_ANON_KEY
```

#### 4. 内容文件未更新

**解决方案**：
```bash
# 重新编译内容
npm run build:content

# 检查生成的文件
cat src/lib/generated/content.ts
```

### 调试工具

```bash
# 检查构建输出
find .svelte-kit/output -name "*.js" | head -10

# 验证适配器配置
cat svelte.config.js

# 检查环境检测
node -e "console.log(typeof process !== 'undefined' && process.cwd)"
```

## 📊 性能监控

### 构建统计

- **总文件数**: 319 个 JavaScript 文件
- **主入口文件**: `index.js` (~106KB)
- **客户端资源**: CSS + JavaScript 资源优化
- **服务端渲染**: 完全支持两平台

### 监控指标

1. **Cloudflare Analytics**
   - 请求响应时间
   - CPU 使用率
   - 内存消耗

2. **Vercel Analytics**
   - 函数执行时间
   - 冷启动时间
   - 错误率

## 🔄 持续集成

### GitHub Actions 示例

```yaml
name: Multi-Platform Deploy

on:
  push:
    branches: [main]

jobs:
  deploy-vercel:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - uses: actions/setup-node@v2
      - run: npm ci
      - run: npm run build:vercel
      - uses: amondnet/vercel-action@v20

  deploy-cloudflare:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - uses: actions/setup-node@v2
      - run: npm ci
      - run: npm run build:cloudflare
      - uses: cloudflare/wrangler-action@2.0.0
```

## 📚 相关文档

- [SvelteKit 适配器文档](https://kit.svelte.dev/docs/adapters)
- [Cloudflare Workers 文档](https://developers.cloudflare.com/workers/)
- [Vercel 部署文档](https://vercel.com/docs/concepts/deployments)
- [Supabase 集成指南](https://supabase.com/docs)

## 🎉 总结

通过这次重构，Vibby.ai 实现了真正的多平台兼容性：

- ✅ **零修改部署**: 同一份代码可直接部署到两个平台
- ✅ **智能适配**: 自动检测环境并选择最佳实现方案
- ✅ **性能优化**: 针对每个平台的特性进行优化
- ✅ **开发体验**: 统一的开发和构建流程
- ✅ **可维护性**: 清晰的架构和完善的文档

现在你可以根据需求选择最适合的部署平台，享受多平台部署的便利！