# Augment Code 规则配置

本指南说明如何为您的 Vibby.ai 项目配置 Augment Code，以获得最佳开发体验，包括设置、规则和最佳实践。

## 📖 概述

Augment Code 是一个 AI 驱动的编码助手，可以通过特定的规则和上下文进行配置，以了解您项目的要求、编码标准和架构模式。

## 🚀 快速设置

### 1. 安装

```bash
# 在您的 IDE 中安装 Augment Code 扩展
# 或访问: https://augmentcode.com

# 初始化配置
augment init
```

### 2. 配置文件

Augment Code 可以通过多个文件进行配置：

```
.augment/
├── config.yaml          # 主配置
├── rules.md             # 编码规则和指南
├── context.md           # 项目上下文和架构
└── templates/           # 代码模板
```

## ⚙️ 配置结构

### 1. 主配置 (.augment/config.yaml)

```yaml
# Vibby.ai 的 Augment Code 配置
project:
  name: "Vibby.ai"
  type: "SvelteKit"
  version: "1.0.0"

# 语言和框架设置
languages:
  primary: "TypeScript"
  frameworks: 
    - "SvelteKit"
    - "Svelte 5"
    - "TailwindCSS"

# 代码风格偏好
code_style:
  indentation: 2
  quotes: "single"
  semicolons: true
  trailing_commas: true

# AI 辅助偏好
ai_settings:
  suggestions: true
  auto_complete: true
  code_review: true
  documentation: true

# 文件类型关联
file_types:
  ".svelte": "svelte"
  ".ts": "typescript"
  ".md": "markdown"

# 自定义模式
patterns:
  components: "src/lib/components/**/*.svelte"
  api_routes: "src/routes/api/**/+server.ts"
  pages: "src/routes/**/+page.svelte"
```

### 2. 规则配置 (.augment/rules.md)

```markdown
# Vibby.ai Augment Code 规则

## 核心原则

1. **仅 Svelte 5**: 专门使用现代 Svelte 5 语法
2. **类型安全**: 所有代码必须使用 TypeScript 正确类型化
3. **基于组件**: 遵循组件驱动开发
4. **性能优先**: 优化速度和包大小

## 语法规则

### ✅ 必需的 Svelte 5 语法

```svelte
<script lang="ts">
  interface Props {
    title: string;
    count?: number;
  }
  
  let { title, count = 0 }: Props = $props();
  let doubled = $derived(count * 2);
  let message = $state('Hello');
</script>

<button onclick={() => count++}>
  {title}: {count}
</button>
```

### ❌ 禁止模式

永远不要使用这些已弃用的模式：
- `export let` 用于 props → 使用 `$props()`
- `$:` 用于响应性 → 使用 `$derived()`
- `on:click` 事件 → 使用 `onclick`
- `any` 类型 → 使用特定类型

## 组件架构

### 文件组织
```
src/lib/components/
├── ui/                 # shadcn/ui 组件
├── site-tool/         # 工具特定组件
├── site-blog/         # 博客特定组件
├── site-game/         # 游戏特定组件
└── common/            # 共享组件
```

### 组件结构
```svelte
<script lang="ts" module>
  // 类型和模块级导出
</script>

<script lang="ts">
  // 导入
  import { ComponentName } from '$lib/components/ui/component';
  
  // Props 接口
  interface Props {
    // 定义所有带有类型的 props
  }
  
  // Props 解构
  let { prop1, prop2 = defaultValue }: Props = $props();
  
  // 状态管理
  let localState = $state(initialValue);
  let derivedState = $derived(computation);
</script>

<!-- 具有正确结构的模板 -->
<div class="component-wrapper">
  <!-- 组件内容 -->
</div>
```

## API 开发标准

### 响应格式
```typescript
// 成功响应
return json({ success: true, data: result });

// 错误响应
return json({ success: false, error: '消息' }, { status: code });
```

### 错误处理
```typescript
export async function GET(): Promise<Response> {
  try {
    const data = await fetchData();
    return json({ success: true, data });
  } catch (error) {
    console.error('[API Error]', error);
    return json({ 
      success: false, 
      error: '操作失败' 
    }, { status: 500 });
  }
}
```

## TypeScript 要求

### 接口定义
```typescript
// 组件 Props
interface ComponentProps {
  title: string;
  variant?: 'default' | 'secondary';
  onClick?: () => void;
}

// API 类型
interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
}

// 站点配置
interface SiteConfig {
  type: 'site-tool' | 'site-blog' | 'site-game';
  title: string;
  description: string;
}
```

## 样式指南

### Tailwind CSS 使用
- 使用实用程序类进行样式设置
- 优先组合而不是自定义 CSS
- 使用响应式设计模式
- 遵循设计系统标记

### shadcn/ui 集成
```svelte
<script lang="ts">
  import { Button } from '$lib/components/ui/button';
  import { Card } from '$lib/components/ui/card';
  import { cn } from '$lib/utils';
</script>

<Card class={cn('custom-styles', className)}>
  <Button variant="default" onclick={handleClick}>
    操作
  </Button>
</Card>
```

## 多站点架构

### 站点类型处理
```typescript
// 基于站点类型的动态组件选择
const siteComponents = {
  'site-tool': ToolHomePage,
  'site-blog': BlogHomePage, 
  'site-game': GameHomePage
} as const;

const Component = siteComponents[siteType] || ToolHomePage;
```

### 环境配置
```typescript
// 配置的优先级顺序
1. 环境变量（最高）
2. 数据库值
3. 本地文件
4. 默认值（最低）
```

## 性能优化

### 代码分割
```typescript
// 大型组件的动态导入
const HeavyComponent = lazy(() => import('./HeavyComponent.svelte'));
```

### 图片优化
```svelte
<!-- 使用优化的图片 -->
<img 
  src="/optimized/{image}" 
  alt={alt}
  loading="lazy"
  class="responsive-image" 
/>
```

## 测试要求

### 组件测试
```typescript
import { render, screen } from '@testing-library/svelte';
import Component from './Component.svelte';

test('组件正确渲染', () => {
  render(Component, { props: { title: '测试' } });
  expect(screen.getByText('测试')).toBeInTheDocument();
});
```

## 代码质量标准

### ESLint 规则
- 无未使用变量
- 一致的命名约定
- 适当的错误处理
- 类型安全强制执行

### Prettier 配置
- 2空格缩进
- 单引号
- 尾随逗号
- 80字符行长度
```

### 3. 上下文文档 (.augment/context.md)

```markdown
# Vibby.ai 项目上下文

## 项目概述

Vibby.ai 是一个多站点 SaaS 平台，可以在三种不同模式下运行：
- **site-tool**: 工具/SaaS 着陆页
- **site-blog**: 博客导向网站
- **site-game**: 游戏平台

## 技术栈

- **前端**: SvelteKit with Svelte 5
- **样式**: TailwindCSS + shadcn/ui
- **后端**: SvelteKit API 路由
- **数据库**: Supabase
- **部署**: Vercel
- **内容**: Sveltia CMS

## 架构模式

### 数据流
1. 环境变量（最高优先级）
2. Supabase 数据库
3. 本地内容文件
4. 默认配置

### 组件层次结构
- 根布局 (`+layout.svelte`)
- 站点特定布局
- 页面组件
- 可重用 UI 组件

### API 设计
- `/api/` 下的 RESTful 端点
- 一致的响应格式
- 适当的错误处理
- 类型安全的请求/响应

## 开发工作流程

1. 使用 `pnpm dev` 开始
2. 遵循 Svelte 5 模式进行更改
3. 使用 `pnpm check` 测试
4. 部署到 Vercel

## 常见模式

### 状态管理
```svelte
<!-- 本地状态 -->
let count = $state(0);

<!-- 派生状态 -->
let doubled = $derived(count * 2);

<!-- 效果 -->
$effect(() => {
  console.log('Count changed:', count);
});
```

### 错误边界
```svelte
{#await promise}
  <LoadingSpinner />
{:then data}
  <DataDisplay {data} />
{:catch error}
  <ErrorMessage {error} />
{/await}
```

## 集成点

### CMS 集成
- Sveltia CMS 嵌入在 `/vibbyai/cms`
- `src/content/` 中的内容文件
- 支持多语言，使用 `.zh.md` 后缀

### 数据库集成
- `src/lib/supabase.ts` 中的 Supabase 客户端
- 类型安全的数据库查询
- 开发中回退到文件系统

### 身份验证
- 管理员的简单基于文件的身份验证
- 用户的 Supabase 身份验证
- 布局中的会话管理
```

## 🎯 高级功能

### 1. 自定义模板

在 `.augment/templates/` 中创建可重用的代码模板：

```svelte
<!-- .augment/templates/component.svelte -->
<script lang="ts">
  interface Props {
    {{propName}}: {{propType}};
  }
  
  let { {{propName}} }: Props = $props();
</script>

<div class="{{className}}">
  {{{propName}}}
</div>
```

### 2. 智能代码建议

配置 Augment 以提供上下文感知建议：

```yaml
# .augment/suggestions.yaml
suggestions:
  components:
    - when: "创建新组件"
      suggest: "使用 Svelte 5 语法和 TypeScript 接口"
    - when: "样式组件"
      suggest: "使用 Tailwind CSS 实用程序和 shadcn/ui 组件"
  
  api:
    - when: "创建 API 端点"
      suggest: "包含适当的错误处理和类型定义"
    - when: "数据库操作"
      suggest: "使用具有类型安全的 Supabase 客户端"
```

### 3. 项目特定快捷方式

定义常见操作：

```yaml
# .augment/shortcuts.yaml
shortcuts:
  new_component:
    description: "创建新的 Svelte 组件"
    template: "component.svelte"
    location: "src/lib/components/"
  
  new_api:
    description: "创建新的 API 端点"
    template: "api-endpoint.ts"
    location: "src/routes/api/"
  
  new_page:
    description: "创建新页面"
    template: "page.svelte"
    location: "src/routes/"
```

## 🔧 与开发工具的集成

### 1. VS Code 集成

```json
{
  "augment.enable": true,
  "augment.suggestions": true,
  "augment.autoComplete": true,
  "augment.codeReview": true
}
```

### 2. Git 钩子

```bash
# .git/hooks/pre-commit
#!/bin/bash
augment lint
augment check-rules
```

### 3. CI/CD 集成

```yaml
# .github/workflows/augment.yml
name: Augment Code Review
on: [push, pull_request]

jobs:
  augment-review:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: 运行 Augment Code Review
        run: |
          augment review --changed-files
          augment check-compliance
```

## 🎯 最佳实践

### 1. 保持规则更新

- 每月审查和更新规则
- 与项目发展保持一致
- 立即记录新模式

### 2. 上下文感知

- 提供丰富的项目上下文
- 包含架构决策
- 记录常见模式

### 3. 团队协作

- 在团队中共享配置
- 记录自定义快捷方式
- 维护一致的标准

### 4. 性能监控

- 监控建议准确性
- 跟踪代码质量改进
- 测量开发速度

### 5. 工具集成

- 与其他开发工具协调
- 避免冲突配置
- 维护统一的代码标准

## 🚨 故障排除

### 常见问题

#### 配置冲突
如果 Augment Code 与其他工具冲突：
1. 检查配置文件重叠
2. 调整 AI 建议优先级
3. 禁用冲突功能

#### 性能问题
如果 Augment Code 影响性能：
1. 减少实时分析范围
2. 优化配置复杂性
3. 调整建议频率

#### 建议质量
如果建议不准确：
1. 更新项目上下文
2. 细化规则定义
3. 提供更多示例

### 获取帮助

1. **查看文档**: Augment Code 官方文档
2. **社区支持**: 开发者社区和论坛
3. **团队协作**: 与团队成员分享配置经验

通过遵循这些 Augment Code 规则和配置，您将最大化 AI 助手的有效性，并在整个 Vibby.ai 项目开发过程中保持高代码质量标准。