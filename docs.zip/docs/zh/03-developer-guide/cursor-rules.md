# Cursor IDE 规则配置

本指南说明如何使用 `.cursorrules` 文件为 Vibby.ai 开发配置 Cursor IDE 的适当规则。

## 📖 快速设置

### 1. 创建 .cursorrules 文件

在项目根目录创建 `.cursorrules` 文件：

```bash
touch .cursorrules
```

### 2. .cursorrules 配置示例

```markdown
# Vibby.ai Cursor 规则

您是一位专注于 Vibby.ai 多站点平台的 TypeScript、SvelteKit 和 Tailwind 开发专家。

## 关键原则

- 编写简洁、技术性的回应
- 使用函数式和声明式编程模式
- 优先选择迭代和模块化而不是重复
- 使用带有辅助动词的描述性变量名（例如，isLoading、hasError）
- 文件结构：导出组件、子组件、辅助函数、静态内容、类型

## 技术栈

- **框架**: SvelteKit with Svelte 5 runes
- **样式**: Tailwind CSS + shadcn/ui 组件
- **数据库**: Supabase
- **语言**: TypeScript
- **构建**: Vite
- **部署**: Vercel

## Svelte 5 语法（必需）

始终使用新的 Svelte 5 语法：

### ✅ 正确（使用这个）
```svelte
<script lang="ts">
  interface Props {
    title: string;
    count?: number;
  }
  
  let { title, count = 0 }: Props = $props();
  let doubled = $derived(count * 2);
  let message = $state('Hello');
</script>

<button onclick={() => count++}>
  {title}: {count}
</button>
```

### ❌ 禁止（永远不要使用）
```svelte
<script lang="ts">
  export let title: string;  // ❌ 旧语法
  export let count = 0;      // ❌ 旧语法
  
  $: doubled = count * 2;    // ❌ 旧响应式语法
</script>

<button on:click={() => count++}>  <!-- ❌ 旧事件语法 -->
  {title}: {count}
</button>
```

## TypeScript 要求

- 始终使用严格的 TypeScript
- 为所有 props 和数据结构定义接口
- 为函数使用适当的返回类型
- 避免 `any` 类型 - 始终定义特定类型

### API 类型示例
```typescript
interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
}

interface SiteConfig {
  type: 'site-tool' | 'site-blog' | 'site-game';
  title: string;
  description: string;
  features?: FeatureConfig[];
}
```

## 组件架构

### 站点类型特定组件
- `src/lib/components/site-tool/` - 工具/SaaS 组件
- `src/lib/components/site-blog/` - 博客组件  
- `src/lib/components/site-game/` - 游戏组件
- `src/lib/components/ui/` - shadcn/ui 组件

### 组件结构
```svelte
<script lang="ts" module>
  // 类型和模块级代码
</script>

<script lang="ts">
  // 组件导入
  import { ComponentName } from '$lib/components/ui/component-name';
  import { cn } from '$lib/utils';
  
  // Props 接口
  interface Props {
    title: string;
    variant?: 'default' | 'secondary';
    className?: string;
  }
  
  // Props 解构
  let { title, variant = 'default', className }: Props = $props();
  
  // 响应式状态
  let isVisible = $state(false);
  let computedValue = $derived(title.length > 10);
</script>

<!-- 模板 -->
<div class={cn('base-styles', className)}>
  <h1>{title}</h1>
</div>
```

## API 开发标准

### 标准 API 响应格式
```typescript
// 成功响应
return json({ success: true, data: result });

// 错误响应  
return json({ success: false, error: '错误信息' }, { status: 500 });
```

### 错误处理模式
```typescript
export async function GET(): Promise<Response> {
  try {
    const data = await fetchData();
    return json({ success: true, data });
  } catch (error) {
    console.error('[API Error]', '操作失败:', error);
    return json({ 
      success: false, 
      error: '获取数据失败' 
    }, { status: 500 });
  }
}
```

## 多站点架构

平台通过 `PUBLIC_SITE_TYPE` 环境变量支持三种站点类型：
- `site-tool`: 工具/SaaS 着陆页
- `site-blog`: 博客导向网站  
- `site-game`: 游戏平台

### 动态组件选择
```svelte
<script lang="ts">
  import ToolHomePage from '$lib/components/site-tool/ToolHomePage.svelte';
  import BlogHomePage from '$lib/components/site-blog/BlogHomePage.svelte';
  import GameHomePage from '$lib/components/site-game/GameHomePage.svelte';
  
  const siteComponents = {
    'site-tool': ToolHomePage,
    'site-blog': BlogHomePage,
    'site-game': GameHomePage
  } as const;
  
  const CurrentComponent = siteComponents[data.siteConfig.type] || ToolHomePage;
</script>

<svelte:component this={CurrentComponent} {data} />
```

## 样式指南

- 使用 Tailwind CSS 进行所有样式设置
- 优先使用 shadcn/ui 组件作为 UI 元素
- 使用 `cn()` 工具处理条件类
- 遵循移动优先的响应式设计

### 使用 tailwind-variants 的示例
```typescript
import { tv, type VariantProps } from 'tailwind-variants';

export const buttonVariants = tv({
  base: 'inline-flex items-center justify-center rounded-md text-sm font-medium',
  variants: {
    variant: {
      default: 'bg-primary text-primary-foreground hover:bg-primary/90',
      destructive: 'bg-destructive text-destructive-foreground hover:bg-destructive/90',
    },
    size: {
      default: 'h-10 px-4 py-2',
      sm: 'h-9 rounded-md px-3',
      lg: 'h-11 rounded-md px-8',
    },
  },
  defaultVariants: {
    variant: 'default',
    size: 'default',
  },
});
```

## 文件命名约定

- 组件: `PascalCase.svelte` (例如, `UserProfile.svelte`)
- 页面: `+page.svelte`, `+layout.svelte`
- API 路由: `+server.ts`
- 工具: `kebab-case.ts` (例如, `site-config.ts`)
- 类型: `kebab-case.ts` (例如, `api-types.ts`)

## 禁止模式

❌ **永远不要使用这些模式:**
- Svelte 4 语法 (`export let`, `on:click`, `$:`)
- 没有特定原因的 `any` 类型
- 内联样式而不是 Tailwind 类
- 直接 DOM 操作（使用 Svelte 响应性）
- 创建 `doc/` 目录（只使用 `docs/`）

## CMS 集成

- 使用 Sveltia CMS 通过 iframe 嵌入在 `/vibbyai/cms`
- 内容文件在 `src/content/` 按语言组织
- 永远不要将 CMS 从 iframe 更改为独立页面

## 数据库优先级顺序

1. 环境变量（最高优先级）
2. Supabase 数据库
3. 本地文件
4. 默认值（最低优先级）

## 性能指南

- 对大型组件使用动态导入
- 实现适当的加载状态
- 使用 Vercel 优化优化图片
- 使用 SvelteKit 的 SSR 功能

## 代码审查检查清单

提交代码前，确保：
- [ ] 专门使用 Svelte 5 语法
- [ ] 所有 TypeScript 类型都正确定义
- [ ] API 端点有适当的错误处理
- [ ] 组件遵循 shadcn/ui 模式
- [ ] 文件名遵循约定
- [ ] 没有使用已弃用的语法
- [ ] 实现了多语言支持
- [ ] 站点类型特定组件在正确目录中

在代码建议中始终优先考虑类型安全、性能和可维护性。
```

## 🔧 IDE 配置

### 1. Cursor 设置

为最佳 Svelte 开发配置 Cursor：

```json
{
  "svelte.enable-ts-plugin": true,
  "typescript.preferences.quoteStyle": "single",
  "editor.formatOnSave": true,
  "editor.codeActionsOnSave": {
    "source.fixAll.eslint": true
  },
  "files.associations": {
    "*.svelte": "svelte"
  }
}
```

### 2. 扩展推荐

Vibby.ai 开发的基本 Cursor 扩展：

- **Svelte for VS Code** - Svelte 语言支持
- **Tailwind CSS IntelliSense** - Tailwind 类自动完成
- **TypeScript Importer** - 自动导入 TypeScript 模块
- **Prettier** - 代码格式化
- **ESLint** - 代码检查

### 3. 代码片段

创建自定义片段以加快开发：

```json
{
  "Svelte 5 组件": {
    "prefix": "sv5component",
    "body": [
      "<script lang=\"ts\">",
      "  interface Props {",
      "    ${1:propName}: ${2:string};",
      "  }",
      "  ",
      "  let { ${1:propName} }: Props = $props();",
      "</script>",
      "",
      "<div>",
      "  {${1:propName}}",
      "</div>"
    ],
    "description": "创建一个新的 Svelte 5 组件与 props"
  }
}
```

## 🎯 最佳实践

### 1. 代码组织

```
src/lib/components/
├── ui/                 # shadcn/ui 组件
├── site-tool/         # 工具特定组件
├── site-blog/         # 博客特定组件
├── site-game/         # 游戏特定组件
└── common/            # 共享组件
```

### 2. 类型安全

始终为组件 props 定义接口：

```typescript
interface UserCardProps {
  user: {
    id: string;
    name: string;
    email: string;
  };
  showActions?: boolean;
  onUserClick?: (userId: string) => void;
}
```

### 3. 状态管理

使用 Svelte 5 runes 进行状态管理：

```svelte
<script lang="ts">
  // 组件状态
  let isLoading = $state(false);
  let userData = $state<User[]>([]);
  
  // 派生状态
  let filteredUsers = $derived(
    userData.filter(user => user.active)
  );
  
  // 效果
  $effect(() => {
    if (isLoading) {
      fetchUsers();
    }
  });
</script>
```

通过遵循这些 Cursor 规则，您将保持一致的代码质量并有效地利用 Cursor 的 AI 功能进行 Vibby.ai 开发。