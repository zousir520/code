# 安装指南

完整的 Vibby.ai 平台安装指南，支持所有平台和配置。

## 系统要求

### 最低要求
- **Node.js**: 18.0 或更高版本
- **npm**: 8.0 或更高版本（或 yarn 1.22+, pnpm 7.0+）
- **Git**: 2.30 或更高版本
- **操作系统**: Windows 10+, macOS 10.15+, Linux (Ubuntu 20.04+)

### 推荐配置
- **Node.js**: 20.x LTS
- **内存**: 8GB RAM
- **存储**: 10GB 可用空间
- **网络**: 稳定的互联网连接

## 快速安装

### 1. 克隆项目

```bash
# 克隆 Vibby.ai 仓库
git clone https://github.com/yourusername/vibby.ai.git
cd vibby.ai

# 或者使用 GitHub CLI
gh repo clone yourusername/vibby.ai
cd vibby.ai
```

### 2. 安装依赖

```bash
# 使用 npm
npm install

# 或使用 yarn
yarn install

# 或使用 pnpm (推荐，更快更节省空间)
pnpm install
```

### 3. 环境配置

```bash
# 复制环境变量模板
cp .env.example .env.local

# 编辑环境变量
nano .env.local
```

### 4. 启动开发服务器

```bash
# 启动开发模式
npm run dev

# 或指定端口
npm run dev -- --port 3000
```

访问 `http://localhost:5173` 查看你的应用。

## 详细安装步骤

### Node.js 安装

#### Windows 用户

1. **使用官方安装包**
   ```bash
   # 访问 https://nodejs.org/
   # 下载 LTS 版本安装包
   # 运行安装程序
   ```

2. **使用 Chocolatey**
   ```bash
   choco install nodejs
   ```

3. **使用 Scoop**
   ```bash
   scoop install nodejs
   ```

#### macOS 用户

1. **使用官方安装包**
   ```bash
   # 访问 https://nodejs.org/
   # 下载 macOS 安装包
   ```

2. **使用 Homebrew**
   ```bash
   brew install node
   ```

3. **使用 MacPorts**
   ```bash
   sudo port install nodejs18
   ```

#### Linux 用户

1. **Ubuntu/Debian**
   ```bash
   # 使用 NodeSource 仓库
   curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
   sudo apt-get install -y nodejs
   ```

2. **CentOS/RHEL/Fedora**
   ```bash
   # 使用 NodeSource 仓库
   curl -fsSL https://rpm.nodesource.com/setup_20.x | sudo bash -
   sudo dnf install nodejs npm
   ```

3. **Arch Linux**
   ```bash
   sudo pacman -S nodejs npm
   ```

### 版本管理器 (推荐)

使用 Node 版本管理器可以轻松切换 Node.js 版本：

#### nvm (Linux/macOS)

```bash
# 安装 nvm
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash

# 重新加载 shell
source ~/.bashrc

# 安装并使用 Node.js 20
nvm install 20
nvm use 20
nvm alias default 20
```

#### nvm-windows (Windows)

```bash
# 下载安装包: https://github.com/coreybutler/nvm-windows/releases
# 安装后使用:
nvm install 20
nvm use 20
```

#### fnm (跨平台，更快)

```bash
# 安装 fnm
curl -fsSL https://fnm.vercel.app/install | bash

# 安装 Node.js 20
fnm install 20
fnm use 20
fnm default 20
```

## 项目设置

### 1. 环境变量配置

创建 `.env.local` 文件：

```bash
# 站点配置
PUBLIC_SITE_NAME="我的AI创业平台"
PUBLIC_SITE_DESCRIPTION="基于AI技术的创新创业平台"
PUBLIC_SITE_URL="http://localhost:5173"

# Supabase 配置
PUBLIC_SUPABASE_URL="你的supabase项目URL"
PUBLIC_SUPABASE_ANON_KEY="你的supabase匿名密钥"
SUPABASE_SERVICE_ROLE_KEY="你的supabase服务角色密钥"

# GitHub 配置（用于 CMS）
GITHUB_TOKEN="你的GitHub个人访问令牌"
CMS_REPO_URL="https://github.com/yourusername/vibby.ai"

# 分析工具
PUBLIC_GOOGLE_ANALYTICS_ID="G-XXXXXXXXXX"
PUBLIC_MICROSOFT_CLARITY_ID="你的Clarity项目ID"
```

### 2. Git 配置

```bash
# 配置 Git 用户信息
git config user.name "你的姓名"
git config user.email "your.email@example.com"

# 设置默认分支
git config init.defaultBranch main

# 配置 SSH（推荐）
ssh-keygen -t ed25519 -C "your.email@example.com"
cat ~/.ssh/id_ed25519.pub # 复制公钥到 GitHub
```

### 3. 依赖安装选项

#### npm (默认)
```bash
npm install
npm run dev
```

#### Yarn (更快的依赖解析)
```bash
# 安装 Yarn
npm install -g yarn

# 安装项目依赖
yarn install
yarn dev
```

#### pnpm (推荐：更快、更节省空间)
```bash
# 安装 pnpm
npm install -g pnpm

# 安装项目依赖
pnpm install
pnpm dev
```

## IDE 设置

### VS Code (推荐)

安装推荐的扩展：

```json
{
  "recommendations": [
    "svelte.svelte-vscode",
    "bradlc.vscode-tailwindcss",
    "esbenp.prettier-vscode",
    "dbaeumer.vscode-eslint",
    "ms-vscode.vscode-typescript-next"
  ]
}
```

配置 VS Code 设置：

```json
{
  "editor.formatOnSave": true,
  "editor.defaultFormatter": "esbenp.prettier-vscode",
  "svelte.enable-ts-plugin": true,
  "typescript.preferences.includePackageJsonAutoImports": "on"
}
```

### WebStorm/IntelliJ

1. 安装 Svelte 插件
2. 启用 TypeScript 支持
3. 配置 Prettier 作为默认格式化程序

### Vim/Neovim

配置 Svelte 语法高亮：

```vim
" 在 ~/.vimrc 或 ~/.config/nvim/init.vim 中添加
Plug 'evanleck/vim-svelte', {'branch': 'main'}
Plug 'leafgarland/typescript-vim'
Plug 'maxmellon/vim-jsx-pretty'
```

## 验证安装

运行以下命令验证安装：

```bash
# 检查 Node.js 版本
node --version  # 应该显示 v18.0+ 或 v20.x

# 检查 npm 版本
npm --version   # 应该显示 8.0+

# 检查项目依赖
npm list --depth=0

# 运行类型检查
npm run check

# 运行测试
npm run test

# 构建项目
npm run build
```

## 常见安装问题

### Node.js 版本问题

```bash
# 错误：Node.js 版本过低
# 解决：升级到 Node.js 18+
nvm install 20
nvm use 20
```

### 依赖安装失败

```bash
# 错误：网络超时或包下载失败
# 解决：使用国内镜像
npm config set registry https://registry.npmmirror.com
# 或临时使用
npm install --registry https://registry.npmmirror.com
```

### 权限问题 (Linux/macOS)

```bash
# 错误：Permission denied
# 解决：不要使用 sudo，配置 npm 全局目录
mkdir ~/.npm-global
npm config set prefix '~/.npm-global'
echo 'export PATH=~/.npm-global/bin:$PATH' >> ~/.bashrc
source ~/.bashrc
```

### Windows 路径问题

```bash
# 错误：路径太长
# 解决：启用长路径支持
git config --system core.longpaths true
```

### 内存不足

```bash
# 错误：JavaScript heap out of memory
# 解决：增加 Node.js 内存限制
export NODE_OPTIONS="--max-old-space-size=8192"
# 或在 package.json 中设置
"scripts": {
  "build": "NODE_OPTIONS='--max-old-space-size=8192' vite build"
}
```

## Docker 安装 (可选)

如果你喜欢使用 Docker：

```bash
# 克隆项目
git clone https://github.com/yourusername/vibby.ai.git
cd vibby.ai

# 构建 Docker 镜像
docker build -t vibby-ai .

# 运行容器
docker run -p 5173:5173 -v $(pwd):/app vibby-ai
```

或使用 Docker Compose：

```yaml
version: '3.8'
services:
  app:
    build: .
    ports:
      - "5173:5173"
    volumes:
      - .:/app
      - /app/node_modules
    environment:
      - NODE_ENV=development
```

## 下一步

安装完成后，请参阅：
- [配置指南](./configuration.md) - 配置你的开发环境
- [快速开始](./quick-start.md) - 启动你的第一个项目
- [第一个项目](./first-project.md) - 创建完整的AI创业网站