# 快速开始指南

仅需 **5 分钟** 即可启动并运行 **Vibby.ai**！本指南将让您快速预览您的第一个 AI 创业平台。

## ⚡ 前置条件检查

开始之前，请确保您有：

- **Node.js 18+** 或 **pnpm** 已安装
- **Git** 用于克隆仓库
- **5 分钟** 的时间

## 🚀 闪电设置

### 第 1 步：克隆和安装（2 分钟）

```bash
# 克隆仓库
git clone https://github.com/gstarwd/vibby.ai.git
cd vibby.ai

# 安装依赖（很快！）
pnpm install

# 启动开发服务器
pnpm dev
```

### 第 2 步：打开您的网站（30 秒）

打开浏览器并导航到：
```
http://localhost:5173
```

🎉 **恭喜！** 您应该能看到您的 Vibby.ai 主页。

### 第 3 步：访问管理仪表板（30 秒）

访问管理界面：
```
http://localhost:5173/vibbyai
```

### 第 4 步：快速配置（2 分钟）

1. **访问设置向导**：`http://localhost:5173/vibbyai/init`
2. **基础设置**：输入您的网站名称和 URL
3. **跳过可选项**：暂时跳过数据库/邮件设置
4. **完成设置**：点击"完成设置"

## ✅ 验证清单

设置完成后，验证这些功能是否正常：

- [ ] **主页** 在 `http://localhost:5173` 加载
- [ ] **管理仪表板** 可在 `/vibbyai` 访问
- [ ] **博客部分** 显示示例文章
- [ ] **CMS 界面** 在 `/vibbyai/cms` 加载

## 🎯 您刚刚创建了什么

您的 Vibby.ai 安装包括：

### 🏠 **前端功能**
- **动态主页** 可自定义的部分
- **博客系统** 支持 Markdown
- **多语言支持**（英语/中文）
- **内置 SEO 优化**

### 🛠️ **管理功能**
- **管理仪表板** 在 `/vibbyai`
- **内容管理** 通过 Sveltia CMS
- **配置向导** 便于设置
- **环境管理** 工具

### 🔧 **技术栈**
- **SvelteKit** - 现代 Web 框架
- **TypeScript** - 类型安全开发
- **TailwindCSS** - 实用优先的样式
- **基于文件的 CMS** - 内容无需数据库

## 🎉 成功！下一步是什么？

### 对于内容创作者
➡️ **[内容管理指南](../02-user-guide/content-management.md)** - 学习编辑内容

### 对于开发者
➡️ **[技术架构](../03-developer-guide/technical-architecture.md)** - 了解系统

### 对于生产部署
➡️ **[部署指南](../04-deployment/deployment-guide.md)** - 部署到网络

### 对于完整设置
➡️ **[安装指南](./installation.md)** - 完整配置选项

## 🔧 快速自定义

### 更改网站标题
编辑 `src/content/site-config.json`：
```json
{
  "siteName": "您的神奇 AI 创业公司",
  "siteDescription": "用 AI 构建未来"
}
```

### 更新主页英雄部分
编辑 `src/content/home/hero.json`：
```json
{
  "title": "欢迎来到您的 AI 创业公司",
  "subtitle": "将您的想法变为现实"
}
```

### 添加您的第一篇博客文章
1. 访问 `/vibbyai/cms`
2. 点击"新文章"
3. 编写您的内容
4. 发布！

## 🆘 快速故障排除

### 端口已被使用？
```bash
# 尝试不同端口
pnpm dev --port 3000
```

### 安装问题？
```bash
# 清理缓存并重新安装
rm -rf node_modules pnpm-lock.yaml
pnpm install
```

### 管理页面无法加载？
- 检查控制台错误：`F12 → 控制台`
- 确保开发服务器正在运行
- 尝试刷新页面

## 📞 需要帮助？

- **常见问题**：[故障排除指南](../06-troubleshooting/common-issues.md)
- **详细设置**：[安装指南](./installation.md)
- **社区**：[GitHub 讨论](https://github.com/gstarwd/vibby.ai/discussions)

---

**⚡ 总时间**：约 5 分钟  
**✅ 结果**：功能完整的 Vibby.ai 平台  
**🎯 下一步**：[探索您的管理仪表板](../02-user-guide/admin-dashboard.md)