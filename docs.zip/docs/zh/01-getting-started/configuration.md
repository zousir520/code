# 配置指南

完整的 Vibby.ai 平台配置指南。

## 环境变量配置

### 基础配置

在项目根目录创建 `.env.local` 文件：

```bash
# 站点基础配置
PUBLIC_SITE_NAME="你的AI创业网站"
PUBLIC_SITE_DESCRIPTION="使用AI技术的创新创业平台"
PUBLIC_SITE_URL="https://yourdomain.com"

# Supabase 配置
PUBLIC_SUPABASE_URL="你的supabase项目URL"
PUBLIC_SUPABASE_ANON_KEY="你的supabase匿名密钥"
SUPABASE_SERVICE_ROLE_KEY="你的supabase服务角色密钥"

# CMS 配置
CMS_REPO_URL="https://github.com/你的用户名/你的仓库"
CMS_BRANCH="main"

# SEO 配置
PUBLIC_GOOGLE_ANALYTICS_ID="GA_MEASUREMENT_ID"
PUBLIC_MICROSOFT_CLARITY_ID="你的Clarity项目ID"
```

### 高级配置

```bash
# API 配置
API_RATE_LIMIT="100"
API_CORS_ORIGINS="https://yourdomain.com,https://admin.yourdomain.com"

# 性能配置
PUBLIC_ENABLE_SW="true"
PUBLIC_PRELOAD_IMAGES="true"
PUBLIC_LAZY_LOADING="true"

# 多语言配置
PUBLIC_DEFAULT_LOCALE="zh"
PUBLIC_SUPPORTED_LOCALES="zh,en"

# 邮件配置
SMTP_HOST="smtp.gmail.com"
SMTP_PORT="587"
SMTP_USER="your-email@gmail.com"
SMTP_PASS="your-app-password"
```

## 站点配置

### app.html 配置

编辑 `src/app.html` 自定义站点元数据：

```html
<!DOCTYPE html>
<html lang="%lang%">
<head>
    <meta charset="utf-8" />
    <link rel="icon" href="%sveltekit.assets%/favicon.png" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    
    <!-- SEO 基础配置 -->
    <meta name="description" content="你的站点描述" />
    <meta name="keywords" content="AI,创业,科技,创新" />
    <meta name="author" content="你的名字" />
    
    <!-- 社交媒体配置 -->
    <meta property="og:title" content="你的AI创业平台" />
    <meta property="og:description" content="使用AI技术的创新创业平台" />
    <meta property="og:image" content="/og-image.jpg" />
    
    %sveltekit.head%
</head>
<body data-sveltekit-preload-data="hover">
    <div style="display: contents">%sveltekit.body%</div>
</body>
</html>
```

### 路由配置

配置 `src/hooks.server.ts` 进行服务器端处理：

```typescript
import type { Handle } from '@sveltejs/kit';
import { locale } from 'svelte-i18n';

export const handle: Handle = async ({ event, resolve }) => {
    // 语言检测
    const lang = event.request.headers.get('accept-language')?.split(',')[0] || 'zh';
    locale.set(lang.includes('zh') ? 'zh' : 'en');

    // 安全头部
    const response = await resolve(event);
    response.headers.set('X-Frame-Options', 'DENY');
    response.headers.set('X-Content-Type-Options', 'nosniff');
    
    return response;
};
```

## CMS 配置

### Sveltia CMS 设置

配置 `static/admin/config.yml`：

```yaml
backend:
  name: github
  repo: 你的用户名/你的仓库
  branch: main
  cms_label_prefix: '[CMS]'

media_folder: 'static/images'
public_folder: '/images'

# 中文本地化
locale: 'zh_Hans'

# 集合配置
collections:
  - name: 'blog'
    label: '博客文章'
    folder: 'src/lib/content/blog'
    create: true
    slug: '{{year}}-{{month}}-{{day}}-{{slug}}'
    fields:
      - {label: '标题', name: 'title', widget: 'string'}
      - {label: '发布日期', name: 'date', widget: 'datetime'}
      - {label: '摘要', name: 'excerpt', widget: 'text'}
      - {label: '内容', name: 'body', widget: 'markdown'}
      - {label: '标签', name: 'tags', widget: 'list'}
      - {label: '特色图片', name: 'image', widget: 'image', required: false}

  - name: 'pages'
    label: '页面'
    folder: 'src/lib/content/pages'
    create: true
    fields:
      - {label: '标题', name: 'title', widget: 'string'}
      - {label: 'URL路径', name: 'slug', widget: 'string'}
      - {label: '内容', name: 'body', widget: 'markdown'}
      - {label: 'SEO描述', name: 'description', widget: 'text'}
```

## 数据库配置

### Supabase 表结构

运行以下 SQL 创建必要的表：

```sql
-- 用户配置表
CREATE TABLE user_profiles (
  id UUID REFERENCES auth.users PRIMARY KEY,
  username TEXT UNIQUE,
  full_name TEXT,
  avatar_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 博客文章表
CREATE TABLE blog_posts (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  content TEXT,
  excerpt TEXT,
  published BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  author_id UUID REFERENCES auth.users
);

-- 分析数据表
CREATE TABLE analytics_events (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  event_type TEXT NOT NULL,
  page_url TEXT,
  user_agent TEXT,
  ip_address INET,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

### 行级安全策略

```sql
-- 启用行级安全
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE blog_posts ENABLE ROW LEVEL SECURITY;

-- 用户只能查看和编辑自己的配置
CREATE POLICY "Users can view own profile" ON user_profiles
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update own profile" ON user_profiles
  FOR UPDATE USING (auth.uid() = id);

-- 公开博客文章，但只有作者可以编辑
CREATE POLICY "Anyone can view published posts" ON blog_posts
  FOR SELECT USING (published = true);

CREATE POLICY "Authors can manage own posts" ON blog_posts
  USING (auth.uid() = author_id);
```

## 验证配置

运行配置验证脚本：

```bash
# 验证环境变量
npm run config:verify

# 验证数据库连接
npm run db:test

# 验证CMS配置
npm run cms:validate

# 运行完整的配置检查
npm run config:check
```

## 常见配置问题

### 环境变量未生效
- 确保 `.env.local` 文件在项目根目录
- 重启开发服务器
- 检查变量名是否以 `PUBLIC_` 开头（客户端使用）

### CMS 认证失败
- 验证 GitHub 仓库权限
- 检查 GitHub OAuth App 配置
- 确认回调 URL 设置正确

### 数据库连接问题
- 验证 Supabase 项目状态
- 检查网络连接
- 确认 API 密钥有效性

## 下一步

配置完成后，请参阅：
- [快速开始](./quick-start.md) - 启动你的第一个项目
- [第一个项目](./first-project.md) - 创建完整的AI创业网站
- [部署指南](../04-deployment/deployment-guide.md) - 将项目部署到生产环境