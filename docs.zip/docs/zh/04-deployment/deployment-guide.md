# 部署指南

使用本综合部署指南，自信地将您的 **Vibby.ai** 平台部署到生产环境，涵盖多个托管平台和最佳实践。

## 🚀 部署概览

Vibby.ai 支持多种部署选项，从简单的静态托管到具有服务器端渲染和数据库的全功能云平台。

### 部署选项

**静态站点生成 (SSG)**
- **平台**：Vercel、Netlify、GitHub Pages、Cloudflare Pages
- **适用于**：内容网站、博客、营销页面
- **功能**：快速加载、CDN 分发、自动构建
- **限制**：无服务器端功能、无实时数据

**服务器端渲染 (SSR)**
- **平台**：Vercel、Netlify Functions、Railway、DigitalOcean
- **适用于**：动态内容、用户认证、API
- **功能**：完整的 SvelteKit 功能、服务器端逻辑、实时数据
- **要求**：Node.js 运行时、数据库连接

**混合部署**
- **平台**：Vercel（推荐）、Netlify
- **适用于**：大多数使用场景
- **功能**：静态 + 动态页面、边缘函数、最佳性能

## 🔧 部署前准备

### 1. 环境配置

#### 生产环境变量

创建生产 `.env` 文件：

```bash
# 基础配置
NODE_ENV=production
PUBLIC_SITE_URL=https://yourdomain.com

# 数据库（如果使用 Supabase）
PUBLIC_SUPABASE_URL=https://your-project.supabase.co
PUBLIC_SUPABASE_ANON_KEY=your-production-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-production-service-key

# 邮件配置
SMTP_HOST=smtp.your-provider.com
SMTP_PORT=587
SMTP_USER=your-email@yourdomain.com
SMTP_PASS=your-app-password
SMTP_FROM=noreply@yourdomain.com

# 安全
ENCRYPTION_SECRET=your-secure-48-character-production-key

# 分析
PUBLIC_CLARITY_PROJECT_ID=your-clarity-id
PUBLIC_GA_MEASUREMENT_ID=G-XXXXXXXXXX

# 可选服务
SENTRY_DSN=your-sentry-dsn
REDIS_URL=redis://your-redis-instance
```

#### 环境验证

```bash
# 验证必需的环境变量
node -e "
const required = ['NODE_ENV', 'PUBLIC_SITE_URL'];
const missing = required.filter(key => !process.env[key]);
if (missing.length) {
  console.error('缺少必需的环境变量:', missing);
  process.exit(1);
}
console.log('✅ 环境验证通过');
"
```

### 2. 构建优化

#### 生产构建配置

更新 `vite.config.ts` 用于生产：

```typescript
import { sveltekit } from '@sveltejs/kit/vite';
import { defineConfig } from 'vite';

export default defineConfig(({ mode }) => ({
  plugins: [sveltekit()],
  
  build: {
    target: 'es2022',
    minify: 'terser',
    rollupOptions: {
      output: {
        manualChunks: {
          vendor: ['svelte'],
          ui: ['lucide-svelte', 'bits-ui'],
          utils: ['marked', 'gray-matter']
        }
      }
    }
  },
  
  define: {
    __BUILD_TIME__: JSON.stringify(new Date().toISOString()),
    __VERSION__: JSON.stringify(process.env.npm_package_version)
  },
  
  optimizeDeps: {
    include: ['marked', 'gray-matter', 'nodemailer']
  }
}));
```

#### 构建性能

```bash
# 清理之前的构建
rm -rf .svelte-kit dist

# 带性能分析的构建
npm run build -- --analyze

# 本地测试生产构建
npm run preview
```

### 3. 内容准备

#### 内容审核清单

- [ ] **博客文章**：所有已发布的文章都有正确的元数据
- [ ] **图片**：针对网络优化（WebP 格式、压缩）
- [ ] **媒体**：所有引用的文件都存在于 `static/` 目录中
- [ ] **链接**：内部链接使用相对路径
- [ ] **SEO**：所有页面都有适当的元标签
- [ ] **网站地图**：生成 XML 网站地图
- [ ] **Robots.txt**：设置搜索引擎指令

## 🌐 平台特定部署

### Vercel 部署（推荐）

#### 为什么选择 Vercel？
- **SvelteKit 原生支持**：专为 SvelteKit 应用构建
- **边缘函数**：全球快速的无服务器函数
- **自动 SSL**：免费 SSL 证书
- **预览部署**：每次推送都有预览 URL
- **分析**：内置性能监控

#### 分步 Vercel 部署

**1. 安装 Vercel CLI**

```bash
npm install -g vercel
```

**2. 初始化 Vercel 项目**

```bash
# 在您的项目目录中
vercel

# 按照提示操作：
# - 设置并部署？是
# - 选择哪个范围？选择您的账户
# - 链接到现有项目？否
# - 项目名称：your-project-name
# - 目录：./
# - 覆盖设置？否
```

**3. 配置环境变量**

```bash
# 设置生产环境变量
vercel env add NODE_ENV production
vercel env add PUBLIC_SITE_URL https://yourdomain.com
vercel env add PUBLIC_SUPABASE_URL https://your-project.supabase.co
vercel env add ENCRYPTION_SECRET your-48-char-secret

# 从本地 .env 文件导入
vercel env pull .env.production
```

**4. 自定义域名设置**

```bash
# 添加您的自定义域名
vercel domains add yourdomain.com

# 配置 DNS（在您的域名提供商处添加这些记录）：
# 类型：CNAME，名称：www，值：cname.vercel-dns.com
# 类型：A，名称：@，值：76.76.19.61
```

**5. 部署配置**

创建 `vercel.json`：

```json
{
  "framework": "sveltekit",
  "buildCommand": "npm run build",
  "outputDirectory": "build",
  "installCommand": "npm install",
  "devCommand": "npm run dev",
  "functions": {
    "src/routes/api/**/*.ts": {
      "maxDuration": 30
    }
  },
  "headers": [
    {
      "source": "/(.*)",
      "headers": [
        {
          "key": "X-Frame-Options",
          "value": "DENY"
        },
        {
          "key": "X-Content-Type-Options",
          "value": "nosniff"
        },
        {
          "key": "X-XSS-Protection",
          "value": "1; mode=block"
        }
      ]
    },
    {
      "source": "/static/(.*)",
      "headers": [
        {
          "key": "Cache-Control",
          "value": "public, max-age=31536000, immutable"
        }
      ]
    }
  ],
  "redirects": [
    {
      "source": "/admin",
      "destination": "/vibbyai",
      "permanent": false
    }
  ],
  "rewrites": [
    {
      "source": "/sitemap.xml",
      "destination": "/api/sitemap"
    }
  ]
}
```

**6. 部署**

```bash
# 部署到生产
vercel --prod

# 您的网站将在以下地址可用：
# https://your-project.vercel.app
# 和 https://yourdomain.com（如果配置了自定义域名）
```

### Netlify 部署

#### 分步 Netlify 部署

**1. 安装 Netlify CLI**

```bash
npm install -g netlify-cli
```

**2. 构建配置**

创建 `netlify.toml`：

```toml
[build]
  command = "npm run build"
  functions = "netlify/functions"
  publish = "build"

[build.environment]
  NODE_VERSION = "18"
  NPM_FLAGS = "--prefix=/dev/null"

[[headers]]
  for = "/*"
  [headers.values]
    X-Frame-Options = "DENY"
    X-XSS-Protection = "1; mode=block"
    X-Content-Type-Options = "nosniff"

[[headers]]
  for = "/static/*"
  [headers.values]
    Cache-Control = "public, max-age=31536000, immutable"

[[redirects]]
  from = "/admin"
  to = "/vibbyai"
  status = 302

[[redirects]]
  from = "/api/*"
  to = "/.netlify/functions/:splat"
  status = 200
```

**3. 环境变量**

```bash
# 登录到 Netlify
netlify login

# 设置环境变量
netlify env:set NODE_ENV production
netlify env:set PUBLIC_SITE_URL https://yourdomain.com
netlify env:set ENCRYPTION_SECRET your-secret-key
```

**4. 部署**

```bash
# 部署到生产
netlify deploy --prod

# 您的网站将在以下地址可用：https://app-name.netlify.app
```

### 自托管部署

#### Docker 部署

**1. 创建 Dockerfile**

```dockerfile
# 构建阶段
FROM node:18-alpine AS builder

WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production && npm cache clean --force

COPY . .
RUN npm run build

# 生产阶段
FROM node:18-alpine AS production

WORKDIR /app

# 安装 dumb-init 用于适当的信号处理
RUN apk add --no-cache dumb-init

# 创建非 root 用户
RUN addgroup -g 1001 -S nodejs
RUN adduser -S sveltekit -u 1001

# 复制构建的应用程序
COPY --from=builder --chown=sveltekit:nodejs /app/build build/
COPY --from=builder --chown=sveltekit:nodejs /app/node_modules node_modules/
COPY --from=builder --chown=sveltekit:nodejs /app/package.json package.json

USER sveltekit

EXPOSE 3000

ENV NODE_ENV=production
ENV PORT=3000

ENTRYPOINT ["dumb-init", "--"]
CMD ["node", "build"]
```

**2. 创建 docker-compose.yml**

```yaml
version: '3.8'

services:
  vibby-ai:
    build: .
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
      - PUBLIC_SITE_URL=https://yourdomain.com
      - ENCRYPTION_SECRET=${ENCRYPTION_SECRET}
    depends_on:
      - redis
    restart: unless-stopped

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    volumes:
      - redis-data:/data
    restart: unless-stopped

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
      - ./ssl:/etc/ssl/certs
    depends_on:
      - vibby-ai
    restart: unless-stopped

volumes:
  redis-data:
```

**3. 使用 Docker 部署**

```bash
# 构建并启动服务
docker-compose up -d

# 查看日志
docker-compose logs -f vibby-ai

# 更新应用程序
docker-compose pull
docker-compose up -d --build
```

#### VPS 部署（Ubuntu/Debian）

**1. 服务器设置**

```bash
# 更新系统
sudo apt update && sudo apt upgrade -y

# 安装 Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# 安装 PM2 进程管理
sudo npm install -g pm2

# 安装 Nginx
sudo apt install nginx

# 安装 SSL 证书（Let's Encrypt）
sudo apt install certbot python3-certbot-nginx
```

**2. 应用部署**

```bash
# 克隆仓库
git clone https://github.com/your-username/vibby.ai.git
cd vibby.ai

# 安装依赖
npm install

# 创建生产环境文件
cp .env.example .env.production
# 使用您的生产值编辑 .env.production

# 构建应用程序
npm run build

# 使用 PM2 启动
pm2 start ecosystem.config.js --env production
pm2 save
pm2 startup
```

**3. PM2 配置**

创建 `ecosystem.config.js`：

```javascript
module.exports = {
  apps: [{
    name: 'vibby-ai',
    script: 'build/index.js',
    instances: 'max',
    exec_mode: 'cluster',
    env: {
      NODE_ENV: 'development'
    },
    env_production: {
      NODE_ENV: 'production',
      PORT: 3000
    },
    error_file: './logs/err.log',
    out_file: './logs/out.log',
    log_file: './logs/combined.log',
    time: true
  }]
};
```

**4. Nginx 配置**

创建 `/etc/nginx/sites-available/vibby-ai`：

```nginx
server {
    listen 80;
    server_name yourdomain.com www.yourdomain.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name yourdomain.com www.yourdomain.com;

    ssl_certificate /etc/letsencrypt/live/yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/yourdomain.com/privkey.pem;

    # 安全头
    add_header X-Frame-Options "DENY" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;

    # Gzip 压缩
    gzip on;
    gzip_vary on;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }

    # 静态文件
    location /static/ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
```

**5. 启用和启动服务**

```bash
# 启用 Nginx 站点
sudo ln -s /etc/nginx/sites-available/vibby-ai /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx

# 生成 SSL 证书
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com

# 设置自动证书续期
sudo crontab -e
# 添加：0 12 * * * /usr/bin/certbot renew --quiet
```

## 📊 部署后配置

### 1. 域名和 SSL 设置

#### DNS 配置

在您的域名提供商处配置这些 DNS 记录：

```
类型：A     名称：@     值：[您的服务器 IP]
类型：A     名称：www   值：[您的服务器 IP]
类型：CNAME 名称：www   值：yourdomain.com（A 记录的替代方案）

# 对于 Vercel/Netlify：
类型：CNAME 名称：@     值：[平台特定域名]
类型：CNAME 名称：www   值：[平台特定域名]
```

#### SSL 证书验证

```bash
# 测试 SSL 配置
curl -I https://yourdomain.com

# 检查 SSL 评级
# 访问：https://www.ssllabs.com/ssltest/analyze.html?d=yourdomain.com
```

### 2. 性能优化

#### CDN 配置

**Cloudflare 设置**
1. 注册 Cloudflare
2. 添加您的域名
3. 在域名提供商处更新名称服务器
4. 配置缓存规则：

```
缓存所有内容：开启
浏览器缓存 TTL：1 年
边缘缓存 TTL：1 个月
```

#### 图片优化

```bash
# 优化现有图片
npm install -g imagemin-cli imagemin-webp imagemin-mozjpeg

# 转换和优化图片
imagemin static/images/*.jpg --out-dir=static/images/optimized --plugin=mozjpeg
imagemin static/images/*.png --out-dir=static/images/optimized --plugin=webp
```

### 3. 监控和分析

#### 使用 Sentry 进行错误跟踪

```bash
npm install @sentry/sveltekit
```

```typescript
// src/hooks.client.ts
import * as Sentry from '@sentry/sveltekit';

Sentry.init({
  dsn: 'YOUR_SENTRY_DSN',
  environment: 'production'
});
```

**性能监控**

```typescript
// src/lib/monitoring.ts
export class PerformanceMonitor {
  static trackPageLoad(pageName: string) {
    if (typeof window !== 'undefined') {
      const loadTime = performance.timing.loadEventEnd - performance.timing.navigationStart;
      
      // 发送到分析
      gtag('event', 'page_load_time', {
        page_name: pageName,
        value: loadTime
      });
    }
  }
}
```

#### 健康检查

```typescript
// src/routes/api/health/+server.ts
export async function GET() {
  const checks = {
    database: await checkDatabase(),
    email: await checkEmailService(),
    storage: await checkStorage()
  };
  
  const allHealthy = Object.values(checks).every(check => check === 'ok');
  
  return new Response(JSON.stringify({
    status: allHealthy ? 'healthy' : 'degraded',
    checks,
    timestamp: new Date().toISOString()
  }), {
    status: allHealthy ? 200 : 503,
    headers: { 'Content-Type': 'application/json' }
  });
}
```

### 4. 备份和恢复

#### 自动备份

```bash
#!/bin/bash
# backup.sh - 自动备份脚本

DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/backups/vibby-ai"

# 创建备份目录
mkdir -p $BACKUP_DIR

# 备份应用程序文件
tar -czf $BACKUP_DIR/app_$DATE.tar.gz /var/www/vibby-ai

# 备份数据库（如果使用）
pg_dump $DATABASE_URL > $BACKUP_DIR/db_$DATE.sql

# 上传到云存储（可选）
aws s3 cp $BACKUP_DIR/ s3://your-backup-bucket/ --recursive

# 清理旧备份（保留最近 30 天）
find $BACKUP_DIR -name "*.tar.gz" -mtime +30 -delete
find $BACKUP_DIR -name "*.sql" -mtime +30 -delete

echo "备份完成：$DATE"
```

```bash
# 添加到 crontab 进行每日备份
0 2 * * * /home/user/backup.sh >> /var/log/backup.log 2>&1
```

## 🔍 部署故障排除

### 常见问题

#### 构建失败

```bash
# 检查构建日志
npm run build 2>&1 | tee build.log

# 常见解决方案：
# 1. 清理 node_modules 并重新安装
rm -rf node_modules package-lock.json
npm install

# 2. 检查 TypeScript 错误
npm run check

# 3. 验证环境变量
node -e "console.log(process.env.NODE_ENV)"
```

#### 运行时错误

```bash
# 检查应用程序日志
pm2 logs vibby-ai

# 检查系统资源
htop
df -h

# 重启应用程序
pm2 restart vibby-ai
```

#### 性能问题

```bash
# 监控实时性能
npm install -g clinic
clinic doctor -- node build/index.js

# 分析打包大小
npm run build -- --analyze
```

### 回滚程序

```bash
# 基于 Git 的回滚
git log --oneline -10
git checkout [previous-commit-hash]
npm run build
pm2 restart vibby-ai

# 基于备份的回滚
tar -xzf /backups/vibby-ai/app_20240115_120000.tar.gz -C /var/www/
pm2 restart vibby-ai
```

## ✅ 部署清单

### 部署前
- [ ] 环境变量已配置
- [ ] 本地构建成功
- [ ] 所有测试通过
- [ ] 内容审核完成
- [ ] 性能已优化

### 部署中
- [ ] DNS 记录已配置
- [ ] SSL 证书已安装
- [ ] 应用程序已部署
- [ ] 数据库已迁移（如适用）
- [ ] 环境变量已设置

### 部署后
- [ ] 网站可通过 HTTPS 访问
- [ ] 所有页面正确加载
- [ ] 联系表单正常工作
- [ ] 管理仪表板可访问
- [ ] 分析跟踪激活
- [ ] 监控和警报已设置
- [ ] 备份系统已配置

---

**🚀 部署完成！** 您的 Vibby.ai 平台现在已上线，可以为全球用户提供最佳的性能、安全性和可靠性。

**下一步**：[设置监控](./monitoring.md) 或 [配置安全](./security.md)