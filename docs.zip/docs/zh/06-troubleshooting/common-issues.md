# 常见问题与解决方案

**Vibby.ai** 全面故障排除指南，涵盖开发者和用户遇到的最常见问题，提供逐步解决方案。

## 🔧 快速诊断

### 系统健康检查

运行这些命令快速评估您的系统：

```bash
# 检查 Node.js 版本
node --version
# 应该是 18.0.0 或更高版本

# 检查 npm/pnpm 版本
pnpm --version
npm --version

# 验证 Git 安装
git --version

# 检查开发服务器是否运行
curl http://localhost:5173/api/ping
```

### 环境验证

```bash
# 检查关键环境变量
echo "NODE_ENV: $NODE_ENV"
echo "PUBLIC_SITE_URL: $PUBLIC_SITE_URL"

# 验证 .env 文件是否存在
ls -la .env

# 检查常见配置问题
node -e "
const fs = require('fs');
const path = require('path');

// 检查关键文件是否存在
const criticalFiles = [
  'package.json',
  'svelte.config.js',
  'vite.config.ts',
  'src/app.html'
];

criticalFiles.forEach(file => {
  if (fs.existsSync(file)) {
    console.log('✅', file);
  } else {
    console.log('❌', file, '未找到');
  }
});
"
```

## 🚨 安装和设置问题

### 问题：`pnpm install` 失败

**症状：**
- 包安装错误
- 权限被拒绝错误
- 网络超时错误

**解决方案：**

```bash
# 清理包管理器缓存
pnpm store prune
npm cache clean --force

# 修复权限问题（macOS/Linux）
sudo chown -R $(whoami) ~/.npm
sudo chown -R $(whoami) ~/.pnpm

# 如有网络问题使用不同的注册表
pnpm install --registry https://registry.npmjs.org/

# 替代方案：使用 npm
rm -f pnpm-lock.yaml
npm install
```

### 问题：Node.js 版本冲突

**症状：**
- "不支持的引擎"错误
- 使用版本特定功能的构建失败

**解决方案：**

```bash
# 使用 nvm（推荐）
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash
source ~/.bashrc
nvm install 18
nvm use 18
nvm alias default 18

# 使用 Homebrew（macOS）
brew install node@18
brew link node@18 --force

# 验证安装
node --version
npm --version
```

### 问题：Git 克隆失败

**症状：**
- 权限被拒绝（公钥）
- 仓库未找到
- SSL 证书错误

**解决方案：**

```bash
# 使用 HTTPS 而不是 SSH
git clone https://github.com/your-username/vibby.ai.git

# 修复 SSH 密钥问题
ssh-keygen -t ed25519 -C "your-email@example.com"
cat ~/.ssh/id_ed25519.pub
# 将此密钥添加到您的 GitHub 账户

# 修复 SSL 问题
git config --global http.sslverify false  # 临时修复
# 或者更新证书
git config --global http.sslcainfo /path/to/ca-bundle.crt
```

## 🖥️ 开发服务器问题

### 问题：开发服务器无法启动

**症状：**
- 端口已被使用
- 服务器启动失败
- 空白页面或连接被拒绝

**解决方案：**

```bash
# 检查什么在使用端口 5173
lsof -i :5173
netstat -tulpn | grep 5173

# 杀死使用该端口的进程
kill -9 [PID]

# 在不同端口启动
pnpm dev --port 3000

# 清理 SvelteKit 缓存
rm -rf .svelte-kit
pnpm dev

# 检查 TypeScript 错误
pnpm run check
```

### 问题：热模块替换（HMR）不工作

**症状：**
- 更改不会自动反映
- 浏览器不更新
- 控制台显示 HMR 错误

**解决方案：**

```bash
# 重启开发服务器
pnpm dev

# 清理浏览器缓存
# 按 Ctrl+Shift+R（Windows/Linux）或 Cmd+Shift+R（macOS）

# 检查 Vite 配置
# vite.config.ts 应该有：
```

```typescript
export default defineConfig({
  plugins: [sveltekit()],
  server: {
    hmr: {
      port: 5173
    }
  }
});
```

### 问题：静态文件不加载

**症状：**
- 图片、CSS 或 JS 文件返回 404
- 资源显示损坏链接
- 静态文件无法访问

**解决方案：**

```bash
# 检查文件路径
ls -la static/
ls -la static/images/

# 验证静态文件引用
# 正确：/images/logo.svg
# 错误：./images/logo.svg 或 images/logo.svg

# 检查 Vite 在 vite.config.ts 中的静态处理
```

```typescript
export default defineConfig({
  plugins: [sveltekit()],
  publicDir: 'static'
});
```

## 📝 内容管理问题

### 问题：CMS 界面不加载

**症状：**
- `/vibbyai/cms` 显示空白页面
- 管理界面无法访问
- 认证错误

**解决方案：**

```bash
# 检查管理文件是否存在
ls -la static/admin/
cat static/admin/config.yml

# 验证 CMS 配置
```

```yaml
# static/admin/config.yml 应该包含：
backend:
  name: git-gateway
  branch: main

media_folder: "static/uploads"
public_folder: "/uploads"

collections:
  - name: "blog"
    label: "博客文章"
    folder: "src/content/blog"
    # ... 其余配置
```

```bash
# 检查 iframe 集成
# src/routes/vibbyai/cms/+page.svelte 应该有：
```

```svelte
<iframe
  src="/admin"
  title="Sveltia CMS"
  class="absolute inset-0 w-full h-full border-0"
  sandbox="allow-same-origin allow-scripts allow-forms allow-popups"
></iframe>
```

### 问题：博客文章不显示

**症状：**
- 博客页面不显示文章
- 单个博客文章返回 404
- 内容解析不正确

**解决方案：**

```bash
# 检查博客文章文件
ls -la src/content/blog/
cat src/content/blog/[first-post].md

# 验证前言格式
```

```markdown
---
title: "文章标题"
slug: "post-slug"
date: "2024-01-15"
published: true
---

# 文章内容在这里
```

```bash
# 检查内容加载逻辑
# 验证 gray-matter 是否正确处理文件
node -e "
const matter = require('gray-matter');
const fs = require('fs');
const file = fs.readFileSync('src/content/blog/example.md', 'utf8');
const { data, content } = matter(file);
console.log('前言:', data);
console.log('内容长度:', content.length);
"
```

### 问题：Markdown 不渲染

**症状：**
- 显示原始 markdown 而不是 HTML
- 格式未应用
- 代码块未高亮

**解决方案：**

```bash
# 如果缺少 marked，请安装
pnpm add marked
pnpm add @types/marked -D

# 检查 markdown 处理
```

```typescript
// src/lib/content.ts
import { marked } from 'marked';

// 配置 marked
marked.setOptions({
  gfm: true,
  breaks: true,
  headerIds: true
});

export function processMarkdown(content: string): string {
  return marked(content);
}
```

```svelte
<!-- 在 Svelte 组件中 -->
<div class="prose">
  {@html processedContent}
</div>
```

## 🔐 认证问题

### 问题：管理访问被拒绝

**症状：**
- 无法访问 `/vibbyai` 仪表板
- 认证重定向
- 会话超时

**解决方案：**

```bash
# 检查认证配置
cat src/lib/auth.ts

# 验证环境变量
echo "ENCRYPTION_SECRET: ${ENCRYPTION_SECRET:0:10}..."

# 重置管理凭据（如果使用简单认证）
```

```typescript
// src/lib/auth/simple-auth.ts
export const adminCredentials = {
  username: 'admin',
  password: 'your-secure-password' // 更改此密码！
};
```

### 问题：会话管理问题

**症状：**
- 频繁登出
- 会话不持久
- Cookie 问题

**解决方案：**

```typescript
// src/hooks.server.ts
import { dev } from '$app/environment';

export async function handle({ event, resolve }) {
  // 配置会话 cookie
  const cookieOptions = {
    httpOnly: true,
    secure: !dev,
    sameSite: 'lax' as const,
    maxAge: 60 * 60 * 24 * 7 // 7 天
  };
  
  // 其余认证逻辑
  return resolve(event);
}
```

## 🌐 API 问题

### 问题：API 端点返回 404

**症状：**
- `/api/*` 路由不工作
- 服务器函数不执行
- CORS 错误

**解决方案：**

```bash
# 检查 API 文件结构
ls -la src/routes/api/
ls -la src/routes/api/blog/

# 验证 +server.ts 文件存在
```

```typescript
// src/routes/api/ping/+server.ts
import { json } from '@sveltejs/kit';

export async function GET() {
  return json({ status: 'ok', timestamp: new Date().toISOString() });
}
```

```bash
# 测试 API 端点
curl http://localhost:5173/api/ping
curl http://localhost:5173/api/blog/posts
```

### 问题：数据库连接错误

**症状：**
- Supabase 连接超时
- 数据库查询失败
- 环境变量问题

**解决方案：**

```bash
# 测试 Supabase 连接
node -e "
const { createClient } = require('@supabase/supabase-js');
const supabase = createClient(
  process.env.PUBLIC_SUPABASE_URL,
  process.env.PUBLIC_SUPABASE_ANON_KEY
);

async function test() {
  try {
    const { data, error } = await supabase.from('test').select('*').limit(1);
    console.log('✅ Supabase 连接成功');
  } catch (err) {
    console.error('❌ Supabase 连接失败:', err.message);
  }
}
test();
"
```

```typescript
// src/lib/supabase.ts - 验证配置
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  throw new Error('缺少 Supabase 环境变量');
}

export const supabase = createClient(supabaseUrl, supabaseKey);
```

## 🎨 样式问题

### 问题：TailwindCSS 不工作

**症状：**
- 样式不应用
- 实用类不工作
- CSS 不生成

**解决方案：**

```bash
# 检查 Tailwind 配置
cat tailwind.config.js
cat postcss.config.js

# 验证 tailwind.config.js 中的内容路径
```

```javascript
module.exports = {
  content: [
    './src/**/*.{html,js,svelte,ts}',
    './src/**/*.svelte'
  ],
  theme: {
    extend: {}
  },
  plugins: []
};
```

```bash
# 检查 PostCSS 配置
```

```javascript
// postcss.config.js
module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {}
  }
};
```

```css
/* src/app.css - 验证 Tailwind 指令 */
@tailwind base;
@tailwind components;
@tailwind utilities;
```

### 问题：自定义样式不加载

**症状：**
- CSS 文件未找到
- 样式被覆盖
- 导入错误

**解决方案：**

```svelte
<!-- 在 +layout.svelte 中 -->
<script>
  import '../app.css';
</script>

<!-- 组件特定样式 -->
<style>
  .custom-class {
    /* 自定义样式在这里 */
  }
</style>
```

```typescript
// 在 vite.config.ts 中 - CSS 处理
export default defineConfig({
  css: {
    preprocessorOptions: {
      scss: {
        additionalData: '@use "src/variables.scss" as *;'
      }
    }
  }
});
```

## 🏗️ 构建问题

### 问题：生产构建失败

**症状：**
- 构建过程错误
- TypeScript 编译失败
- 缺少依赖

**解决方案：**

```bash
# 清理构建缓存
rm -rf .svelte-kit dist node_modules
pnpm install
pnpm run build

# 检查 TypeScript 错误
pnpm run check

# 详细构建输出
pnpm run build --verbose

# 检查构建日志
npm run build 2>&1 | tee build.log
```

### 问题：导入/导出错误

**症状：**
- 模块未找到错误
- 循环依赖警告
- 动态导入失败

**解决方案：**

```typescript
// 修复相对导入
// 而不是：import './component'
import Component from './Component.svelte';

// 修复动态导入
const Component = await import('./Component.svelte');

// 检查 tsconfig.json 路径
```

```json
{
  "compilerOptions": {
    "baseUrl": ".",
    "paths": {
      "$lib": ["src/lib"],
      "$lib/*": ["src/lib/*"]
    }
  }
}
```

### 问题：环境变量不工作

**症状：**
- 生产中值为 `undefined`
- 变量在客户端不可访问
- 构建时与运行时问题

**解决方案：**

```bash
# 检查 .env 文件位置和语法
cat .env

# 验证变量命名
# 客户端：必须以 PUBLIC_ 开头
PUBLIC_SITE_URL=https://example.com

# 服务器端：任何名称
PRIVATE_API_KEY=secret

# 检查 import.meta.env 使用
```

```typescript
// 客户端访问
const siteUrl = import.meta.env.VITE_SITE_URL; // Vite 前缀
const publicUrl = import.meta.env.PUBLIC_SITE_URL; // SvelteKit 前缀

// 服务器端访问
const privateKey = process.env.PRIVATE_API_KEY;
```

## 📱 移动端和浏览器问题

### 问题：移动端布局问题

**症状：**
- 移动端布局破损
- 文字太小
- 触摸目标太小

**解决方案：**

```html
<!-- 在 app.html 中验证视口元标签 -->
<meta name="viewport" content="width=device-width, initial-scale=1.0">
```

```css
/* 响应式设计修复 */
@media (max-width: 768px) {
  .container {
    padding: 1rem;
  }
  
  .text-responsive {
    font-size: clamp(1rem, 4vw, 1.5rem);
  }
}

/* 触摸友好的按钮 */
.button {
  min-height: 44px;
  min-width: 44px;
}
```

### 问题：浏览器兼容性

**症状：**
- 功能在旧浏览器中不工作
- Safari/IE 中的 JavaScript 错误
- CSS 不受支持

**解决方案：**

```typescript
// 在 vite.config.ts 中检查浏览器支持
export default defineConfig({
  build: {
    target: ['es2020', 'chrome80', 'firefox78', 'safari13']
  }
});
```

```javascript
// 功能检测而不是浏览器检测
if ('serviceWorker' in navigator) {
  // Service worker 代码
}

if (CSS.supports('display', 'grid')) {
  // Grid 布局代码
}
```

## 🔍 性能问题

### 问题：页面加载时间慢

**症状：**
- 高 Lighthouse 分数
- 慢的首字节时间（TTFB）
- 大包大小

**解决方案：**

```bash
# 分析包大小
pnpm run build
npx vite-bundle-analyzer dist

# 优化图片
npm install imagemin imagemin-webp imagemin-mozjpeg
```

```typescript
// 代码分割
export async function load() {
  const { heavyComponent } = await import('$lib/heavy-component');
  return {
    component: heavyComponent
  };
}

// 懒加载图片
<img loading="lazy" src="/image.jpg" alt="描述" />
```

### 问题：内存泄漏

**症状：**
- 浏览器标签页崩溃
- 内存使用增加
- 随时间性能下降

**解决方案：**

```svelte
<script>
  import { onDestroy } from 'svelte';
  
  let interval;
  
  onMount(() => {
    interval = setInterval(() => {
      // 一些重复任务
    }, 1000);
  });
  
  onDestroy(() => {
    if (interval) {
      clearInterval(interval);
    }
  });
</script>
```

## 🔧 高级故障排除

### 调试模式

启用调试模式以获得详细日志记录：

```bash
# 环境变量
DEBUG=true pnpm dev

# 或在 .env 中
DEBUG=true
LOG_LEVEL=debug
```

```typescript
// src/lib/debug.ts
export function debug(message: string, data?: any) {
  if (import.meta.env.MODE === 'development' || process.env.DEBUG) {
    console.log(`[调试] ${message}`, data);
  }
}
```

### 网络问题

```bash
# 测试 API 连接
curl -v http://localhost:5173/api/ping

# 检查 DNS 解析
nslookup yourdomain.com
dig yourdomain.com

# 测试 SSL 证书
openssl s_client -connect yourdomain.com:443
```

### 性能分析

```bash
# 安装 clinic.js 进行 Node.js 分析
npm install -g clinic

# 分析应用程序
clinic doctor -- node build/index.js
clinic flame -- node build/index.js
clinic bubbleprof -- node build/index.js
```

## 📞 获取帮助

### 自我诊断清单

在寻求帮助之前，请尝试这些步骤：

1. **检查最近的更改**
   - 您最后更改了什么？
   - 您能重现这个问题吗？
   - 在隐身模式下是否发生？

2. **验证环境**
   - 所有依赖都安装了吗？
   - 环境变量设置正确吗？
   - 开发服务器在运行吗？

3. **检查日志**
   - 浏览器控制台错误
   - 终端/命令行输出
   - 浏览器开发者工具中的网络标签

4. **在干净环境中测试**
   - 新的 git 克隆
   - 干净的 npm install
   - 默认配置

### 日志收集

```bash
# 收集综合系统信息
echo "=== 系统信息 ===" > debug-info.txt
echo "Node.js: $(node --version)" >> debug-info.txt
echo "npm: $(npm --version)" >> debug-info.txt
echo "操作系统: $(uname -a)" >> debug-info.txt
echo "" >> debug-info.txt

echo "=== Package.json ===" >> debug-info.txt
cat package.json >> debug-info.txt
echo "" >> debug-info.txt

echo "=== 环境 ===" >> debug-info.txt
env | grep -E "NODE_|PUBLIC_|VITE_" >> debug-info.txt
echo "" >> debug-info.txt

echo "=== 构建输出 ===" >> debug-info.txt
npm run build 2>&1 >> debug-info.txt
```

### 社区支持

- **GitHub 问题**：[报告错误和问题](https://github.com/your-repo/vibby.ai/issues)
- **讨论**：[提问和分享技巧](https://github.com/your-repo/vibby.ai/discussions)
- **Discord**：[加入我们的社区聊天](https://discord.gg/vibby-ai)
- **Stack Overflow**：用 `vibby-ai` 和 `sveltekit` 标记问题

### 专业支持

为需要即时协助的企业用户：
- **优先支持**：support@vibby.ai
- **紧急热线**：+86-400-VIBBY-AI
- **咨询服务**：consulting@vibby.ai

---

**🔧 故障排除完成！** 大多数问题都可以通过这些解决方案解决。如果您仍然遇到问题，请不要犹豫联系我们的社区或支持团队。

**下一步**：[性能优化](./performance.md) 或 [错误信息参考](./error-messages.md)