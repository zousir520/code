# API 参考文档

**Vibby.ai** 完整 API 文档。本指南涵盖所有可用端点、认证方法和集成示例。

## 🚀 API 概览

### 基本信息

- **基础 URL**：`https://yourdomain.com/api`
- **协议**：仅 HTTPS
- **格式**：JSON
- **认证**：API 密钥或会话认证
- **速率限制**：1000 请求/小时（可调整）
- **版本控制**：基于 URL（`/api/v1/`）

### 快速开始

```bash
# 健康检查
curl https://yourdomain.com/api/ping

# 认证请求示例
curl -H "Authorization: Bearer YOUR_API_KEY" \
     https://yourdomain.com/api/content/posts
```

## 🔐 认证

### API 密钥认证

#### 获取 API 密钥

1. **管理仪表板**：访问 `/vibbyai/api-keys`
2. **创建密钥**：点击"生成新 API 密钥"
3. **配置权限**：设置访问级别
4. **复制密钥**：安全保存（仅显示一次）

#### 使用 API 密钥

**头部认证**（推荐）：
```bash
curl -H "Authorization: Bearer YOUR_API_KEY" \
     https://yourdomain.com/api/endpoint
```

**查询参数**：
```bash
curl "https://yourdomain.com/api/endpoint?api_key=YOUR_API_KEY"
```

#### API 密钥管理

```typescript
// API 密钥的 TypeScript 接口
interface ApiKey {
  id: string;
  name: string;
  key: string;
  permissions: string[];
  createdAt: string;
  lastUsed: string;
  rateLimit: number;
  active: boolean;
}
```

### 会话认证

对于使用 Cookie 的 Web 应用程序：

```javascript
// 首先登录
const response = await fetch('/api/auth/login', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ username, password }),
  credentials: 'include'
});

// 后续请求自动包含会话 Cookie
const data = await fetch('/api/admin/stats', {
  credentials: 'include'
});
```

## 📊 核心 API 端点

### 健康状态

#### GET /api/ping
**描述**：健康检查端点

```bash
curl https://yourdomain.com/api/ping
```

**响应**：
```json
{
  "status": "ok",
  "timestamp": "2024-01-15T10:30:00Z",
  "version": "1.0.0",
  "uptime": 86400
}
```

#### GET /api/health
**描述**：详细系统健康状态

```bash
curl https://yourdomain.com/api/health
```

**响应**：
```json
{
  "status": "healthy",
  "checks": {
    "database": "ok",
    "email": "ok",
    "storage": "ok"
  },
  "metrics": {
    "memoryUsage": "45%",
    "cpuUsage": "12%",
    "diskUsage": "60%"
  }
}
```

## 📝 内容 API

### 博客文章

#### GET /api/blog/posts
**描述**：获取博客文章

**参数**：
- `page`（数字）：页码（默认：1）
- `limit`（数字）：每页文章数（默认：10，最大：100）
- `tag`（字符串）：按标签过滤
- `author`（字符串）：按作者过滤
- `published`（布尔值）：按发布状态过滤
- `search`（字符串）：在标题和内容中搜索

```bash
curl "https://yourdomain.com/api/blog/posts?page=1&limit=5&published=true"
```

**响应**：
```json
{
  "posts": [
    {
      "id": "post-1",
      "title": "AI 入门指南",
      "slug": "getting-started-with-ai",
      "excerpt": "学习人工智能基础...",
      "content": "完整的 Markdown 内容...",
      "author": {
        "name": "张三",
        "email": "zhangsan@example.com",
        "avatar": "/images/authors/zhangsan.jpg"
      },
      "publishedAt": "2024-01-15T09:00:00Z",
      "updatedAt": "2024-01-15T10:30:00Z",
      "tags": ["AI", "教程"],
      "featured": true,
      "readingTime": 5,
      "image": "/images/blog/ai-basics.jpg",
      "seo": {
        "title": "AI 入门指南 - 完整指南",
        "description": "人工智能综合指南..."
      }
    }
  ],
  "pagination": {
    "current": 1,
    "pages": 10,
    "total": 95,
    "hasNext": true,
    "hasPrev": false
  }
}
```

#### GET /api/blog/posts/{slug}
**描述**：获取单篇博客文章

```bash
curl https://yourdomain.com/api/blog/posts/getting-started-with-ai
```

**响应**：
```json
{
  "post": {
    "id": "post-1",
    "title": "AI 入门指南",
    "slug": "getting-started-with-ai",
    "content": "包含目录的完整 Markdown 内容...",
    "tableOfContents": [
      { "level": 2, "title": "介绍", "id": "introduction" },
      { "level": 2, "title": "核心概念", "id": "core-concepts" }
    ],
    "related": [
      {
        "title": "高级 AI 技术",
        "slug": "advanced-ai-techniques",
        "excerpt": "将您的 AI 知识提升到下一个水平..."
      }
    ],
    "prevPost": {
      "title": "上一篇文章",
      "slug": "previous-post"
    },
    "nextPost": {
      "title": "下一篇文章", 
      "slug": "next-post"
    }
  }
}
```

#### POST /api/blog/posts
**描述**：创建新博客文章（仅管理员）

**头部**：
```
Authorization: Bearer YOUR_API_KEY
Content-Type: application/json
```

**请求体**：
```json
{
  "title": "新博客文章",
  "content": "Markdown 内容在这里...",
  "excerpt": "简要描述",
  "tags": ["标签1", "标签2"],
  "featured": false,
  "published": true,
  "publishedAt": "2024-01-15T09:00:00Z",
  "seo": {
    "title": "自定义 SEO 标题",
    "description": "自定义元描述"
  }
}
```

**响应**：
```json
{
  "success": true,
  "post": {
    "id": "new-post-id",
    "slug": "new-blog-post",
    "createdAt": "2024-01-15T10:30:00Z"
  }
}
```

### 页面

#### GET /api/content/pages
**描述**：获取所有页面

```bash
curl https://yourdomain.com/api/content/pages
```

**响应**：
```json
{
  "pages": [
    {
      "id": "about",
      "title": "关于我们",
      "slug": "about",
      "content": "页面内容...",
      "template": "default",
      "published": true,
      "updatedAt": "2024-01-15T10:30:00Z"
    }
  ]
}
```

#### GET /api/content/pages/{slug}
**描述**：获取单个页面

```bash
curl https://yourdomain.com/api/content/pages/about
```

### 主页内容

#### GET /api/content/homepage
**描述**：获取主页部分

```bash
curl https://yourdomain.com/api/content/homepage
```

**响应**：
```json
{
  "hero": {
    "title": "快速构建您的 AI 创业公司",
    "subtitle": "启动所需的一切",
    "cta": {
      "primary": { "label": "开始使用", "url": "/signup" }
    }
  },
  "features": {
    "title": "强大功能",
    "items": [...]
  },
  "faq": {
    "title": "常见问题",
    "items": [...]
  }
}
```

## 🔧 网站配置 API

### 常规设置

#### GET /api/site-config
**描述**：获取网站配置

```bash
curl https://yourdomain.com/api/site-config
```

**响应**：
```json
{
  "siteName": "Vibby.ai",
  "siteDescription": "AI 创业平台",
  "siteUrl": "https://yourdomain.com",
  "defaultLanguage": "zh",
  "supportedLanguages": ["en", "zh"],
  "theme": {
    "defaultMode": "light",
    "allowDarkMode": true
  },
  "features": {
    "blog": true,
    "multilingual": true,
    "analytics": true
  }
}
```

#### PUT /api/site-config
**描述**：更新网站配置（仅管理员）

**头部**：
```
Authorization: Bearer YOUR_ADMIN_API_KEY
Content-Type: application/json
```

**请求体**：
```json
{
  "siteName": "新网站名称",
  "siteDescription": "更新的描述"
}
```

### 导航

#### GET /api/content/navigation
**描述**：获取导航结构

```bash
curl https://yourdomain.com/api/content/navigation
```

**响应**：
```json
{
  "header": {
    "logo": { "text": "Vibby.ai", "image": "/logo.svg" },
    "menu": [
      { "label": "首页", "url": "/" },
      { "label": "关于", "url": "/about" }
    ]
  },
  "footer": {
    "sections": [...]
  }
}
```

## 👤 用户管理 API

### 认证

#### POST /api/auth/login
**描述**：用户登录

**请求体**：
```json
{
  "email": "user@example.com",
  "password": "secure_password"
}
```

**响应**：
```json
{
  "success": true,
  "user": {
    "id": "user-123",
    "email": "user@example.com",
    "name": "张三",
    "role": "admin"
  },
  "session": {
    "token": "session_token",
    "expiresAt": "2024-01-16T10:30:00Z"
  }
}
```

#### POST /api/auth/logout
**描述**：用户登出

```bash
curl -X POST https://yourdomain.com/api/auth/logout \
     -H "Authorization: Bearer SESSION_TOKEN"
```

#### GET /api/auth/status
**描述**：检查认证状态

```bash
curl https://yourdomain.com/api/auth/status \
     -H "Authorization: Bearer SESSION_TOKEN"
```

**响应**：
```json
{
  "authenticated": true,
  "user": {
    "id": "user-123",
    "email": "user@example.com",
    "role": "admin"
  }
}
```

## 📊 分析 API

### 使用统计

#### GET /api/analytics/stats
**描述**：获取网站统计（仅管理员）

```bash
curl https://yourdomain.com/api/analytics/stats \
     -H "Authorization: Bearer YOUR_ADMIN_API_KEY"
```

**响应**：
```json
{
  "overview": {
    "totalPosts": 45,
    "totalPages": 12,
    "totalUsers": 156,
    "monthlyVisitors": 2340
  },
  "recent": {
    "newPosts": 3,
    "newUsers": 12,
    "pageViews": 890
  },
  "popular": {
    "posts": [
      {
        "title": "最受欢迎的文章",
        "slug": "most-popular-post",
        "views": 1250
      }
    ],
    "pages": [
      {
        "title": "热门页面",
        "slug": "popular-page", 
        "views": 890
      }
    ]
  }
}
```

#### GET /api/analytics/performance
**描述**：获取性能指标

**参数**：
- `period`（字符串）："day"、"week"、"month"、"year"
- `metric`（字符串）："views"、"users"、"sessions"

```bash
curl "https://yourdomain.com/api/analytics/performance?period=week&metric=views" \
     -H "Authorization: Bearer YOUR_ADMIN_API_KEY"
```

## 🛠️ 管理 API

### 系统管理

#### GET /api/admin/system
**描述**：获取系统信息

```bash
curl https://yourdomain.com/api/admin/system \
     -H "Authorization: Bearer YOUR_ADMIN_API_KEY"
```

**响应**：
```json
{
  "version": "1.0.0",
  "environment": "production",
  "uptime": 86400,
  "memory": {
    "used": "45MB",
    "total": "100MB",
    "percentage": 45
  },
  "storage": {
    "used": "2.1GB",
    "total": "10GB",
    "percentage": 21
  }
}
```

### 环境配置

#### GET /api/env-config
**描述**：获取环境配置

#### POST /api/env-config
**描述**：更新环境设置

**请求体**：
```json
{
  "SITE_NAME": "新网站名称",
  "SITE_URL": "https://newdomain.com",
  "ENABLE_ANALYTICS": "true"
}
```

## 🔍 搜索 API

### 内容搜索

#### GET /api/search
**描述**：搜索内容

**参数**：
- `q`（字符串）：搜索查询
- `type`（字符串）："posts"、"pages"、"all"
- `limit`（数字）：结果限制

```bash
curl "https://yourdomain.com/api/search?q=人工智能&type=posts&limit=5"
```

**响应**：
```json
{
  "query": "人工智能",
  "results": [
    {
      "type": "post",
      "title": "AI 入门指南",
      "excerpt": "学习人工智能基础...",
      "url": "/blog/getting-started-with-ai",
      "score": 0.95
    }
  ],
  "total": 12,
  "took": 45
}
```

## 📧 邮件 API

### 联系表单

#### POST /api/contact
**描述**：提交联系表单

**请求体**：
```json
{
  "name": "张三",
  "email": "zhangsan@example.com",
  "subject": "一般咨询",
  "message": "您好，我有个关于...的问题"
}
```

**响应**：
```json
{
  "success": true,
  "message": "感谢您的留言。我们会尽快回复您！"
}
```

### 订阅

#### POST /api/newsletter/subscribe
**描述**：订阅新闻通讯

**请求体**：
```json
{
  "email": "subscriber@example.com",
  "preferences": {
    "weekly": true,
    "product_updates": true
  }
}
```

## 🔧 实用工具端点

### 文件上传

#### POST /api/upload
**描述**：上传文件（仅管理员）

**头部**：
```
Authorization: Bearer YOUR_ADMIN_API_KEY
Content-Type: multipart/form-data
```

**请求体**：带有文件的 FormData

**响应**：
```json
{
  "success": true,
  "file": {
    "filename": "image.jpg",
    "url": "/uploads/images/image.jpg",
    "size": 102400,
    "type": "image/jpeg"
  }
}
```

### 网站地图

#### GET /api/sitemap
**描述**：获取网站地图数据

```bash
curl https://yourdomain.com/api/sitemap
```

**响应**：
```json
{
  "urls": [
    {
      "loc": "https://yourdomain.com/",
      "lastmod": "2024-01-15",
      "changefreq": "daily",
      "priority": 1.0
    },
    {
      "loc": "https://yourdomain.com/blog/post-1",
      "lastmod": "2024-01-15",
      "changefreq": "monthly",
      "priority": 0.8
    }
  ]
}
```

## 📚 SDK 和库

### JavaScript/TypeScript SDK

```bash
npm install @vibby/api-sdk
```

```typescript
import { VibbyAPI } from '@vibby/api-sdk';

const api = new VibbyAPI({
  baseUrl: 'https://yourdomain.com/api',
  apiKey: 'YOUR_API_KEY'
});

// 获取博客文章
const posts = await api.blog.getPosts({ limit: 10 });

// 创建文章
const newPost = await api.blog.createPost({
  title: '新文章',
  content: '内容在这里...'
});

// 获取网站配置
const config = await api.site.getConfig();
```

### Python SDK

```bash
pip install vibby-api
```

```python
from vibby_api import VibbyAPI

api = VibbyAPI(
    base_url='https://yourdomain.com/api',
    api_key='YOUR_API_KEY'
)

# 获取博客文章
posts = api.blog.get_posts(limit=10)

# 创建文章
new_post = api.blog.create_post({
    'title': '新文章',
    'content': '内容在这里...'
})
```

## ⚠️ 错误处理

### HTTP 状态码

- `200` - 成功
- `201` - 已创建
- `400` - 错误请求
- `401` - 未认证
- `403` - 禁止访问
- `404` - 未找到
- `422` - 验证错误
- `429` - 速率限制
- `500` - 服务器错误

### 错误响应格式

```json
{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "无效的输入数据",
    "details": {
      "field": "email",
      "reason": "无效的邮箱格式"
    },
    "timestamp": "2024-01-15T10:30:00Z",
    "requestId": "req-123"
  }
}
```

### 常见错误代码

- `UNAUTHORIZED` - 无效或缺失 API 密钥
- `VALIDATION_ERROR` - 无效请求数据
- `NOT_FOUND` - 资源未找到
- `RATE_LIMITED` - 请求过多
- `PERMISSION_DENIED` - 权限不足

## 🚦 速率限制

### 默认限制

- **已认证**：1000 请求/小时
- **匿名**：100 请求/小时
- **管理员**：5000 请求/小时

### 速率限制头部

```
X-RateLimit-Limit: 1000
X-RateLimit-Remaining: 999
X-RateLimit-Reset: 1642262400
X-RateLimit-Retry-After: 3600
```

### 处理速率限制

```javascript
const response = await fetch('/api/endpoint');

if (response.status === 429) {
  const retryAfter = response.headers.get('X-RateLimit-Retry-After');
  console.log(`速率限制。${retryAfter} 秒后重试`);
}
```

## 🔒 安全最佳实践

### API 密钥安全

- **永远不要暴露 API 密钥** 在客户端代码中
- **使用环境变量** 存储 API 密钥
- **定期轮换密钥**
- **使用适当的权限**（最小权限原则）
- **监控 API 密钥使用情况**

### 请求安全

- **生产环境始终使用 HTTPS**
- **在服务器端验证所有输入**
- **实施适当的 CORS** 策略
- **对敏感操作使用请求签名**

### 安全实现示例

```javascript
// ✅ 正确 - 服务器端 API 调用
// api/server-endpoint.js
export async function POST({ request }) {
  const apiKey = process.env.VIBBY_API_KEY; // 仅服务器端
  
  const response = await fetch('https://api.vibby.ai/endpoint', {
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json'
    }
  });
  
  return response.json();
}

// ❌ 错误 - 客户端暴露
// components/Component.svelte
const apiKey = 'your-api-key'; // 永远不要这样做！
```

## 📞 支持和资源

### 获取帮助

- **API 文档**：本指南
- **交互式 API 浏览器**：`/api/docs`（如果启用）
- **GitHub 问题**：[报告 API 问题](https://github.com/gstarwd/vibby.ai/issues)
- **社区**：[开发者讨论](https://github.com/gstarwd/vibby.ai/discussions)

### 额外资源

- **Postman 集合**：从 `/api/postman` 下载
- **OpenAPI 规范**：在 `/api/openapi.json` 可用
- **代码示例**：[GitHub 仓库](https://github.com/gstarwd/vibby.ai-examples)

---

**API 参考完成！** 🎉  
**下一步**：[探索认证](./authentication.md) 或 [查看部署指南](../04-deployment/deployment-guide.md)