# Sveltia CMS

Sveltia CMS 是一个基于 Git 的轻量级无头 CMS，正在积极开发中，作为 Netlify CMS 和 Decap CMS 的现代、强大、快速的替代方案。在一些简单的情况下，迁移只需要修改一行代码，尽管我们仍在努力改善兼容性。

这个免费、开源的 Netlify/Decap CMS 替代品/继承者现在处于公测阶段，拥有出色的用户体验、性能、国际化支持以及更多增强功能。

## 核心特性

- **正确构建的基于 Git 的无头 CMS**
- **快速轻量；现代化的用户界面，支持暗色模式**
- **库存图片集成：Pexels、Pixabay、Unsplash**
- **功能完整的资产库；一流的国际化支持；翻译 API 集成**
- **内置 WebP 和 SVG 图片优化器；移动设备和平板电脑支持**
- **流线化的本地和远程工作流；支持 GitHub、GitLab、Gitea 和 Forgejo；从 Netlify/Decap CMS 单行迁移（取决于您当前的设置）**

## 目录

- [动机](#动机)
- [我们的优势](#我们的优势)
- [我们的目标](#我们的目标)
- [开发状态](#开发状态)
- [差异化特性](#差异化特性)
  - [更好的用户体验](#更好的用户体验)
  - [更好的性能](#更好的性能)
  - [更好的生产力](#更好的生产力)
  - [更好的无障碍性](#更好的无障碍性)
  - [更好的安全性](#更好的安全性)
  - [更好的安装](#更好的安装)
  - [更好的配置](#更好的配置)
  - [更好的后端支持](#更好的后端支持)
  - [更好的国际化支持](#更好的国际化支持)
  - [更好的集合](#更好的集合)
  - [更好的内容编辑](#更好的内容编辑)
  - [更好的内容预览](#更好的内容预览)
  - [更好的数据输出](#更好的数据输出)
  - [更好的组件](#更好的组件)
  - [新组件](#新组件)
  - [更好的资产管理](#更好的资产管理)
  - [更好的自定义](#更好的自定义)
  - [更好的本地化](#更好的本地化)
- [兼容性](#兼容性)
  - [不会实现的功能](#不会实现的功能)
  - [当前限制](#当前限制)
  - [与 Static CMS 的兼容性](#与-static-cms-的兼容性)
  - [框架支持](#框架支持)
  - [后端支持](#后端支持)
  - [浏览器支持](#浏览器支持)
  - [其他说明](#其他说明)
- [快速开始](#快速开始)
  - [安装和设置](#安装和设置)
  - [迁移](#迁移)
  - [编辑配置文件](#编辑配置文件)
  - [从 Git Gateway 后端迁移](#从-git-gateway-后端迁移)
  - [通过 npm 安装](#通过-npm-安装)
  - [更新](#更新)
- [使用技巧](#使用技巧)
  - [将站点从 Netlify 迁移到其他托管服务](#将站点从-netlify-迁移到其他托管服务)
  - [为配置文件启用自动完成和验证](#为配置文件启用自动完成和验证)
  - [提供 JSON 配置文件](#提供-json-配置文件)
  - [提供多个配置文件](#提供多个配置文件)
  - [解决身份验证错误](#解决身份验证错误)
  - [使用本地 Git 仓库](#使用本地-git-仓库)
  - [在 Brave 浏览器中启用本地开发](#在-brave-浏览器中启用本地开发)
  - [为集合使用自定义图标](#为集合使用自定义图标)
  - [在集合列表中添加分隔符](#在集合列表中添加分隔符)
  - [为集合使用自定义媒体文件夹](#为集合使用自定义媒体文件夹)
  - [指定默认排序字段和方向](#指定默认排序字段和方向)
  - [在文件夹集合中包含 Hugo 的特殊索引文件](#在文件夹集合中包含-hugo-的特殊索引文件)
  - [使用单例](#使用单例)
  - [使用键盘快捷键](#使用键盘快捷键)
  - [一键翻译条目字段](#一键翻译条目字段)
  - [本地化条目别名](#本地化条目别名)
  - [禁用非默认语言内容](#禁用非默认语言内容)
  - [为条目别名使用随机 ID](#为条目别名使用随机-id)
  - [配置多个媒体库](#配置多个媒体库)
  - [优化上传图片](#优化上传图片)
  - [禁用库存资产](#禁用库存资产)
  - [编辑站点部署配置文件](#编辑站点部署配置文件)
  - [编辑具有顶级列表的数据文件](#编辑具有顶级列表的数据文件)
  - [更改 DateTime 字段的输入类型](#更改-datetime-字段的输入类型)
  - [在 Markdown 中将软换行渲染为硬换行](#在-markdown-中将软换行渲染为硬换行)
  - [控制数据输出](#控制数据输出)
  - [禁用自动部署](#禁用自动部署)
  - [设置内容安全策略](#设置内容安全策略)
  - [显示 CMS 版本](#显示-cms-版本)
- [支持和反馈](#支持和反馈)
- [贡献](#贡献)
- [路线图](#路线图)
  - [v1.0](#v10)
  - [v2.0](#v20)
  - [未来](#未来)
- [趣闻](#趣闻)
- [相关链接](#相关链接)
- [媒体报道](#媒体报道)
- [免责声明](#免责声明)

## 动机

Sveltia CMS 诞生于 2022 年 11 月，当时 Netlify CMS 的进展已经停滞了超过六个月。@kyoshino 的客户希望在不费太多力气的情况下替换他们的 Netlify CMS 实例，主要是为了获得更好的国际化（i18n）支持。

为了在用户体验、性能、国际化和其他方面实现根本性改进，最终决定从头开始构建一个替代方案，同时确保从其他产品的轻松迁移路径。在通过快速的 Svelte 原型验证了这个想法后，开发被加速以满足他们的主要用例。这个新产品已被命名为 Sveltia CMS 并作为开源软件发布，以鼓励更广泛的采用。

我们喜欢 Netlify CMS 的简单架构，它将 Git 仓库变成了一个数据库，通过从 CDN 提供的单页应用加上一个简单的 YAML 配置文件。为了支持 Jamstack 概念，我们希望重振它，使其现代化，并将其提升到一个新的水平。

## 我们的优势

由于在 2022 年初不幸被放弃，Netlify CMS 产生了 3 个继承者：

- **Static CMS**：社区分支，初始提交于 2022 年 9 月 — 在进行了有意义的改进后于 2024 年 9 月停止维护
- **Sveltia CMS**：不是分支而是完全重写或"完全重启"，始于 2022 年 11 月，2023 年 3 月首次出现在 GitHub 上
- **Decap CMS**：重新品牌的版本，于 2023 年 2 月宣布作为官方继承者，由 Netlify 代理合作伙伴接管所有权 — 大多处于停滞状态，只有偶尔的发布

Sveltia CMS 是唯一不继承 Netlify CMS（于 2015 年推出）复杂性、技术债务和众多错误的项目。我们的产品在设计上更好：我们使用现代框架从头开始重建应用程序，同时密切监控和分析前身的问题跟踪器。我们不使用他们的任何代码。这使我们能够在不被旧系统束缚的情况下进行数百项改进。

虽然 Sveltia CMS 是为了替换传统的 Netlify CMS 实例而创建的，但它也可以用作其他 Netlify CMS 继承者的替代品。凭借其坚实的国际化支持，我们希望我们的产品最终能够成为任何寻找免费无头 CMS 的人的有吸引力选择。

## 我们的目标

- 让 Sveltia CMS 成为 Netlify CMS 的可行、决定性继承者
- 赋能需要免费但强大、高质量 CMS 解决方案的中小企业和个人
- 成为基于 Git 的 CMS 市场中领先的开源产品
- 扩展其作为数字资产管理（DAM）软件的能力
- 展示 Svelte 和用户体验工程的力量

## 开发状态

Sveltia CMS 目前处于测试阶段，版本 1.0（正式版）预计将于 2025 年底发布。请查看我们的发布说明并在 Bluesky 上关注我们以获取更新。另请参阅我们的路线图。

虽然我们会尽快修复报告的错误，通常在 24 小时内，但我们的整体进展可能比您想象的要慢。事实上，这不仅仅是 @kyoshino 的个人项目，而是一个涉及各种活动的复杂系统，需要大量努力：

**确保与 Netlify/Decap CMS 的实质性兼容性**

**解决尽可能多的 Netlify/Decap CMS 问题**

到目前为止，已经在 Sveltia CMS 中有效解决了 235+ 个问题，如果包括重复项则为 485+（是的，您没看错）

**目标：**
- 到正式版时解决 250 个问题，如果包括重复项则为 500 个 — 即将达成！
- 未来解决 400 个问题，如果包括重复项则为 800 个 💪
- 或者每一个相关、可修复且值得处理的问题 🔥

问题包括从功能请求到错误报告以及因陈旧而关闭或没有有效解决方案的问题，以及讨论和停滞的拉取请求

- 许多错误，包括烦人的崩溃，已经得到解决
- 剩余的错误主要与未实现的功能相关
- 他们的许多热门功能都在我们的计划中或已在 Sveltia CMS 中实现

**解决我们自己的问题**

**为产品的每个部分实现我们自己的增强想法**

**响应维护者客户的请求**

**使代码干净且可维护**

**在 Sveltia CMS 中解决了 235 个 Netlify/Decap CMS 问题**

## 差异化特性

Netlify/Decap CMS 用户肯定会对我们所做的众多改进感到高兴和惊讶，从小到大。这就是 Sveltia CMS 的不同之处。看看我们有多认真！

> **注意：** 这个冗长的部分将 Sveltia CMS 与 Netlify CMS 和 Decap CMS 进行了比较。列出的一些错误可能已在当前版本的 Decap CMS 中得到修复。

### 更好的用户体验

- 由一位热爱代码、设计、营销和问题解决的经验丰富的用户体验工程师创建和积极维护。您可以期待整个平台的用户体验（UX）和开发者体验（DX）得到持续改进。
- 维护者尽量尽快响应错误报告。虽然没有保证，但错误修复的典型周转时间少于 24 小时。
- 频繁的发布更快地向用户提供新功能和增强功能。我们的大多数次要版本都解决了一个或多个 Netlify/Decap CMS 问题，为您提供了从传统前身切换的更多理由。
- 提供利用完整视口的现代直观用户界面，¹ 部分灵感来自 Netlify CMS v3 原型。²³⁴⁵⁶
- 提供沉浸式暗色模式。⁷ UI 主题默认遵循用户的系统偏好，可以在应用程序设置中更改。
- 用户可以通过移动设备和平板电脑支持轻松地随时随地管理内容。⁸⁹

为了获得更流畅的体验，我们甚至超越了响应式设计，采用了优化的导航、视图转换、更大的按钮和其他调整。但是，仍然有粗糙的边缘，我们正在努力为小屏幕和触摸设备完全优化应用程序。

如果您已经在桌面上登录，请打开 CMS 右上角的帐户菜单，单击"使用移动设备登录"，然后扫描二维码进行无密码登录。您的设置将被自动复制。

- 使用 Svelte 而不是 React 制作，意味着我们可以花更多时间在用户体验上，而不是繁琐的状态管理。它还允许我们避免常见的致命 React 应用程序崩溃。¹⁰¹¹ 最重要的是，Svelte 提供了出色的性能。
- Netlify/Decap CMS 中的其他崩溃也与我们无关，使 Sveltia CMS 更加稳定。¹²¹³¹⁴
- 我们构建自己的 UI 组件库，包括自定义对话框，以确保最佳可用性而不影响无障碍性。¹⁵¹⁶¹⁷¹⁸¹⁹²⁰²¹
- 用户可以使用各种设置个性化应用程序，包括外观和语言。还可以启用开发者模式。
- 通过在 CMS 更新可用时收到通知，永远不会错过最新功能和错误修复。²² 然后一键更新到最新版本。²³

### 更好的性能

- 完全使用 Svelte 从头构建，而不是分叉基于 React 的 Netlify/Decap CMS。应用程序启动快速并保持快速，没有虚拟 DOM 开销。请注意，Svelte 是一个编译器，Sveltia CMS 是框架无关的；它作为原生 JavaScript 包提供。
- **小体积**：缩小和 brotli 压缩后的包大小小于 500 KB，比 Netlify CMS（1.5 MB）、Decap CMS（1.5 MB）和 Static CMS（2.6 MB）轻得多。²⁴²⁵ 这个数字是显著的，因为即使 Sveltia CMS 中省略或未实现了一些 Netlify/Decap CMS 功能，我们还添加了许多新功能。这就是 Svelte 5 + Vite 的力量。
- 使用 GitHub 和 GitLab 的 GraphQL API 快速一次性获取内容，以便条目和资产可以即时列出和搜索²⁶²⁷（因此无用的搜索配置选项被忽略）。它还避免了关系字段的数百个请求导致的缓慢和潜在的 API 速率限制违规。²⁸
- 由于 GraphQL 突变，将条目和资产保存到 GitHub 也快得多。
- Gitea/Forgejo 后端也更快，因为它利用了 Gitea 1.24 和 Forgejo 12.0 中引入的高效 API 方法。
- 我们的本地仓库工作流利用现代文件系统访问 API 通过 Web 浏览器本地读写文件，而不是通过代理服务器使用缓慢的临时 REST API。
- 条目的排序、过滤和分组可以即时完成，无需重新加载整个内容。
- 使用缓存、延迟加载和无限滚动技术。仓库文件列表存储在本地，以便更快启动和节省带宽。
- 生成并缓存资产的缩略图，包括视频和 PDF 文件，以便更快地渲染资产库和 CMS 的其他部分。²⁹³⁰
- 输入字段没有输入延迟，特别是在嵌套列表和对象中。³¹
- 条目预览默认不使用 `<iframe>`，因为这是性能开销。³²

### 更好的生产力

- 开发者可以在没有任何额外配置或代理服务器的情况下使用本地 Git 仓库，从而实现流线化的工作流和改进的性能。³³

它还避免了许多问题，包括潜在的依赖项损坏，³⁴ 30 MB 文件大小限制，³⁵ publish_mode 的未知错误，³⁶ 和未使用的 logo_url。³⁷

- 当您删除条目或资产文件时，包含它的空文件夹也会被删除，因此您不必手动删除它。
- 在内容编辑器中提供更流畅的用户体验：
  - 条目草稿的本地备份会自动创建，不会被确认对话框中断，这会让用户烦恼并可能在关闭时导致页面导航问题。³⁸ 然后可以可靠地恢复备份，而不会出现意外覆盖。³⁹
  - 单击一次（保存按钮）而不是两次（发布 > 立即发布）来保存条目。或者只需按 Ctrl+S（Windows/Linux）或 Command+S（macOS）键来节省时间。
  - 保存条目时编辑器会自动关闭。此行为可以在应用程序设置中更改。
- 可以通过拖放上传文件。⁴⁰
- 用户可以一次将多个文件上传到资产库。
- 用户可以一次删除多个条目和资产。
- 按相关性排序的即时全文搜索结果可帮助您更快找到条目。
- 一些键盘快捷键可用于更快编辑。

### 更好的无障碍性

- 改进的键盘处理让您使用 Tab、Space、Enter 和箭头键高效地浏览 UI 元素。⁴¹⁴²
- 全面的 WAI-ARIA 支持使依赖屏幕阅读器（如 NVDA 和 VoiceOver）的用户受益。⁴³ 当您导航到另一个页面时会读出公告。
- 富文本编辑器使用 Lexical 构建，据说遵循无障碍性最佳实践。启用了 Dragon NaturallySpeaking 支持。
- 确保前景文本和背景颜色之间有足够的对比度。
- 启用和禁用的按钮可以清楚地区分。⁴⁴
- 链接默认带下划线，使其更容易识别。如果您愿意，可以在无障碍性设置中更改此行为。
- 尊重您操作系统的减少动画和减少透明度设置。稍后将添加对高对比度模式的支持。
- 开发者的浏览器控制台日志在浅色或暗色模式下都可读。⁴⁵
- 我们将继续测试和改进应用程序以满足 WCAG 2.2。

### 更好的安全性

- 通过持续更新、Dependabot 警报、pnpm 审计和频繁发布避免依赖项中的漏洞，与 Netlify/Decap CMS 不同，后者有许多高严重性漏洞长期未修补。⁴⁶
- 我们的本地仓库工作流不需要代理服务器，减少了攻击面。³⁴
- 我们已启用 npm 包来源证明。
- 我们已记录如何为 CMS 设置内容安全策略，以防止任何意外错误或其他不安全配置。⁴⁷
- script-src CSP 指令中不需要 unsafe-eval 和 unsafe-inline 关键字。⁴⁸
- 自动使用 `<meta>` 标签设置 same-origin 引用策略。
- Sveltia CMS 有安全上下文要求，强制站点内容（包括 CMS 配置文件）通过 HTTPS 提供。
- GitHub 提交会自动进行 GPG 签名并标记为已验证。⁴⁹

### 更好的安装

- Sveltia CMS 使用 Svelte 构建，我们只发布编译的原生 JavaScript 包，因此没有可能阻止开发者升级项目数月的 React 兼容性问题。⁵⁰ 我们实际上还没有为自定义组件和其他功能集成 React，但无论如何，当您使用 npm 安装应用程序时不会安装任何依赖项。
- Sveltia CMS 也不会主要由于传统第三方 React UI 库而导致对等依赖冲突。⁵¹⁵² 我们使用自己的 Svelte UI 组件库构建应用程序，以减少对第三方的依赖。
- 已知某些服务器和框架会根据配置从 CMS URL (/admin) 中删除尾随斜杠。在这种情况下，配置文件从正确的 URL (/admin/config.yml) 而不是常规相对 URL (./config.yml = /config.yml) 加载，这会导致 404 未找到错误。⁵³
- 自动将 robots 元标签添加到 HTML，以防止搜索引擎索引管理页面。⁵⁴ 仍然鼓励开发者手动将 `<meta name="robots" content="noindex">` 添加到 index.html，因为并非所有爬虫都支持动态添加的标签。但是，我们的解决方案至少应该与 Google 配合使用，以防您忘记这样做。
- 两次初始化 CMS（由于 window.CMS_MANUAL_INIT 的不正确或缺失放置）不会导致 NotFoundError。⁵⁵
- 当您导入 JavaScript 模块时，Sveltia CMS 会自动启用手动初始化，因此您不需要在代码中使用 window.CMS_MANUAL_INIT = true。

### 更好的配置

- Sveltia CMS 支持可以为批量或复杂集合生成的 JSON 配置文件。⁵⁶
- 还支持多个配置文件，允许开发者模块化配置。⁵⁷
- 我们为 YAML/JSON 配置文件提供最新的 JSON 架构，这在 VS Code 和其他代码编辑器中启用自动完成和验证。⁵⁸
- 改进的 TypeScript 支持：我们保持 CMS.init() 和其他方法的类型定义完整、准确、最新和带注释。⁵⁹⁶⁰⁶¹⁶²⁶³ 这使得在手动初始化 CMS 时更容易提供站点配置对象。

### 更好的后端支持

Sveltia CMS 中提供 GitHub、GitLab、Gitea/Forgejo 和 Test 后端。出于性能原因，我们不支持 Azure、Bitbucket 和 Git Gateway。

- 尽可能使用 GraphQL API 以获得更好的性能，如上所述。您不需要设置 use_graphql 选项来为 GitHub 和 GitLab 启用它。²⁷
- 如果配置文件中未指定，Git 分支名称会自动设置为仓库的默认分支（main、master 或其他），从而防止由于硬编码回退到 master 而导致的数据加载错误。⁶⁴⁶⁵ 如果指定了分支名称，它会按预期工作。⁶⁶
- 可以默认或按需禁用自动部署，以节省与 CI/CD 相关的成本和资源，并一次发布多个更改。⁶⁷
- GitLab 后端支持带有后台服务状态检查，就像 GitHub 一样。
- 频繁执行服务状态检查，并显著显示事件通知。
- 当启用开发者模式时，用户可以通过 3 点菜单快速在您的仓库中打开条目或资产的源文件。
- 我们为 GitHub 和 GitLab 提供自己的 OAuth 客户端。
- GitLab 后端支持 Git LFS（文档）。⁶⁸
- 当您登录 GitLab 后端时，用户不会收到 404 未找到错误。⁶⁹
- 我们的 Gitea/Forgejo 后端性能很高，因为它一次检索多个条目。它还支持 Git LFS（文档）。此外，由于文件路径中存在 DRAFT_MEDIA_FILES，后端不会导致 400 错误请求错误。⁷⁰
- 用户可以使用个人访问令牌（PAT）直接使用基于 Git 的后端登录，而不是通过常规 OAuth 流程。⁷¹ 为此，请单击登录按钮旁边的小箭头按钮，然后选择使用个人访问令牌。
- 当使用带有 PKCE 授权的 GitLab 或 Gitea/Forgejo 后端时，OAuth 访问令牌会自动续订。⁷² 其他后端配置的令牌续订将稍后实现。
- 具有全新的本地仓库工作流，可提升开发体验。请参阅上面的生产力部分。
- 开发者可以在本地服务器上工作时选择本地和远程后端。
- Test 后端将条目和资产保存在浏览器的源私有文件系统（OPFS）中，这样当浏览器标签关闭或重新加载时更改不会被丢弃。⁷³ 持久存储支持适用于除 Safari 之外的所有现代浏览器。

### 更好的国际化支持

Sveltia CMS 从一开始就采用多语言架构构建。您可以期待一流的国际化（i18n）支持，因为这是维护者 @kyoshino 的客户所要求的，他本人曾是 Mozilla 的长期日语本地化人员，目前居住在世界上最多元化的城市，那里使用 150 多种语言。

#### 配置

Netlify/Decap CMS 中的 i18n 限制不适用于 Sveltia CMS：

- 文件集合支持多文件/文件夹 i18n 结构。⁷⁴ 要启用它，只需在文件路径选项中使用 {{locale}} 模板标签，例如 content/pages/about.{{locale}}.json 或 content/pages/{{locale}}/about.json。为了向后兼容，全局结构选项仅适用于文件夹集合，文件集合的默认 i18n 结构仍然是单文件。
- List 和 Object 组件支持 i18n: duplicate 字段配置，以便使用这些组件所做的更改在语言环境之间重复。⁷⁵⁷⁶ i18n 配置通常可用于子字段。
- 新的 multiple_folders_i18n_root i18n 结构允许在项目根目录下有语言环境文件夹：`<locale>/<folder>/<slug>.<extension>`。⁷⁷
- 新的 omit_default_locale_from_filename i18n 选项允许从文件名中排除默认语言环境。此选项适用于启用了 multiple_files i18n 结构的条目集合，以及文件路径以 .{{locale}}.<extension> 结尾的文件集合项，旨在支持 Zola 的多语言站点。（讨论）
- required 字段选项除了布尔值外还接受语言环境代码数组，在启用 i18n 支持时使字段对语言环境的子集是必需的。例如，如果只需要英语，您可以写 required: [en]。空数组等价于 required: false。
- 条目相对媒体文件夹可以与 multiple_folders i18n 结构结合使用。⁷⁸
- {{locale}} 模板标签可以在 preview_path 集合选项中使用，为每种语言提供站点预览链接。⁷⁹
- 可以为条目别名使用随机 UUID，这对于用非拉丁字符书写的语言环境是一个很好的选择。
- 可以本地化条目别名，同时链接本地化文件，⁸⁰ 这要归功于对 Hugo 的 translationKey 的支持。⁸¹
- 当为条目别名启用 clean_accents 选项时，某些字符（如德语变音符号）将被音译。⁸²
- 可以通过使用 widget: hidden 以及 default: '{{locale}}' 在条目中嵌入语言环境代码。⁸³
- value_field 关系字段选项可以包含像 {{locale}}/{{slug}} 这样的语言环境前缀，它将被当前语言环境替换。它旨在支持 Astro 中的 i18n。（讨论）

#### 用户界面

- 消除 UI 混乱：预览面板可以在内容编辑器中显示而无需切换 i18n。两个面板都可以滚动。没有两个面板同时以相同语言编辑的情况。
- 当语言环境少于 5 个时，用户可以通过单击按钮而不是下拉列表在编辑时轻松切换语言环境。
- 语言标签以人类可读的显示名称而不是 ISO 639 语言代码出现，因为不是每个人都容易识别 DE 为德语、NL 为荷兰语、ZH 为中文等等。

#### 内容编辑

- 集成翻译服务，允许一键从另一种语言环境翻译文本字段。
- 内容编辑器支持 RTL 脚本，如阿拉伯语、希伯来语和波斯语。⁸⁴
- 可以禁用非默认语言环境内容。⁸⁵
- 条目预览中的布尔、DateTime、List 和 Number 字段以本地化格式显示。
- 布尔字段像其他组件一样在语言环境之间实时更新，以避免混乱。⁸⁶
- 启用了 i18n 的关系字段在您开始编辑现有条目时不会触发内容草稿状态的更改。⁸⁷
- 解决了 Markdown 组件富文本编辑器中中文、日文和韩文（CJK）IME 文本输入的问题。⁸⁸
- 如果使用 single_file 结构并且在任何语言环境中未填写必填字段，则会引发验证错误而不是静默失败。⁸⁹
- 非默认语言环境中的字段按预期验证。⁹⁰
- 更改语言环境时不会抛出内部错误。⁹¹
- 复制条目会复制所有语言环境内容，而不仅仅是默认语言环境。⁹²
- 使用菜单从另一种语言环境复制 Markdown 按预期工作。⁹³

### 更好的集合

#### 配置

提供一些新选项，包括：

- **icon**：为每个集合选择自定义图标。⁹⁴
  - 该选项也可用于文件集合中的单个文件。指定的图标将出现在文件列表中。
- **thumbnail**：指定在条目列表上显示的缩略图的字段名称，如 thumbnail: featuredImage。⁹⁵
  - 可以使用点表示法指定嵌套字段，例如 heroImage.src。
  - 字段名称中也支持通配符，例如 images.*.src。
  - 可以指定多个字段名称作为数组用于回退目的，例如 [thumbnail, cover]。
  - 有时，您可能没有适合缩略图的图像。例如，您的图像可能有细微差别或不同的纵横比。在这种情况下，您可以使用 thumbnail: [] 禁用缩略图。
  - 如果省略此选项，将使用任何非嵌套、非空的 Image 或 File 字段。⁹⁶
- **limit**：指定可以在文件夹集合中创建的条目的最大数量。⁹⁷
- **divider**：向集合列表添加分隔符。

**文件夹集合的条目过滤器选项的增强：**
- 布尔值按预期工作。⁹⁸
- value 接受 null 来匹配未定义的字段值。
- value 接受数组来提供多个可能的值。⁹⁹
- pattern 可以代替 value 使用来提供正则表达式，就像 view_filters 集合选项一样。¹⁰⁰

**摘要字符串转换的增强：**
- 转换可以在比集合摘要更多的地方使用：
  - slug 和 preview_path 集合选项¹⁰¹
  - List 和 Object 组件的摘要字段选项
- 默认转换接受像 {{fields.slug | default('{{fields.title}}')}} 这样的模板标签，使得可以回退到不同的字段值。（讨论）
- 日期转换支持时区参数。唯一可用的值是 utc，它将日期转换为 UTC。如果指定的 DateTime 字段是本地的，但您想在条目别名中强制 UTC，这很有用，例如 {{date | date('YYYYMMDD-HHmm', 'utc')}}。（讨论）
- 如果给出无效日期，日期转换返回空字符串。¹⁰²
- 多个转换可以链接，如 {{title | upper | truncate(20)}}。

**文件集合的增强：**
- Sveltia CMS 支持单例，这是文件集合的简单形式。¹⁰³
- 文件集合支持没有扩展名的文件。¹⁰⁴ 这对于编辑站点部署配置文件（如 _headers 和 _redirects）很有用。
- 文件集合中的每个文件都有格式和 frontmatter_delimiter 选项，可用于指定文件格式，使得可以并排使用 yaml-frontmatter、toml-frontmatter 和 json-frontmatter。¹⁰⁵
- 集合标签默认为名称值（根据 Decap CMS 文档），而 Netlify/Decap CMS 实际上在省略标签选项时抛出配置错误。
- 嵌套字段（点表示法）可以在文件夹集合的路径选项中使用，例如 {{fields.state.name}}/{{slug}}。¹⁰⁶
- 集合描述选项支持 Markdown。¹⁰⁷ 允许粗体、斜体、删除线、代码和链接。
- 如果您想将条目存储在根文件夹中，集合文件夹可以是空字符串（或 . 或 /）。这支持典型的 VitePress 设置。

#### 条目别名

- 可以为条目别名使用随机 UUID。
- 别名生成是故障安全的：如果无法从条目内容确定别名，则使用随机 UUID 的一部分，而不是抛出错误或填充任意字符串字段值。¹⁰⁸
- 用户可以通过内容编辑器中的 3 点菜单编辑条目别名。¹⁰⁹
- 如果集合只有 Markdown 正文字段，如果存在，条目别名将从正文中的标题生成。这支持典型的 VitePress 设置。
- 条目别名模板标签支持转换，就像摘要字符串模板标签一样。¹⁰¹
- 别名中的单引号（撇号）将被 sanitize_replacement（默认：连字符）替换，而不是被删除。¹¹⁰
- 条目别名的最大字符数可以使用新的 slug_length 集合选项设置，以避免 Netlify 或其他平台的部署错误。¹¹¹
- 设置集合路径不会影响使用关系组件存储的条目别名。¹¹²
- 条目别名是可本地化的。⁸⁰

#### 条目列表

- 可以指定默认排序字段和方向。¹¹³
- 按 DateTime 字段排序条目按预期工作。¹¹⁴
- 条目分组和排序可以协同工作。例如，如果配置正确，可以按年分组然后按年排序。
- sortable_fields 选项接受特殊的 slug 值以允许按条目别名排序。
- 索引文件包含允许用户编辑 Hugo 的特殊 _index.md 文件，包括本地化的文件如 _index.en.md，在文件夹集合中。¹¹⁵ 如果未定义 index_file 选项，这些文件将在文件夹集合中隐藏，除非路径选项配置为以 _index 结尾且扩展名为 md。¹¹⁶
- 当集合没有标题字段时不会抛出控制台错误。¹¹⁷ 在这种情况下，条目摘要将从 Markdown 正文字段中的标题（如果存在）或从条目别名生成，因此摘要永远不会为空。¹¹⁸ 这支持典型的 VitePress 和 Docusaurus 设置。¹¹⁹
- 如果解析条目文件时出错，如重复的前端事项键，它不会显示为空白条目，并且浏览器控制台中将显示清晰的错误消息。¹²⁰
- 单个文件可以用于文件集合中的多个项目。¹²¹

#### 用户界面

- 集合列表显示每个集合中的项目数量。
- 用户可以选择多个条目并一次删除它们。
- 在条目摘要中，标题中使用的基本 Markdown 语法（包括粗体、斜体和代码）被解析为 Markdown。HTML 字符引用（实体）也被正确解析。¹²²
- 如果您更新出现在集合摘要中的条目字段（如标题），条目列表会在您保存条目后显示更新的摘要。¹²³
- 缩略图不仅在网格视图中显示，还在列表视图中显示，使导航更容易。
- 如果条目没有用于缩略图的 Image 字段，条目列表将仅以列表视图显示，因为显示网格视图没有意义。¹²⁴
- 存储在集合媒体文件夹中的资产可以显示在条目旁边。
- 当开发者意外在文件集合上设置 create: true 选项时，不会出现"新建条目"按钮，因为它没有用。¹²⁵
- 当开发者意外在文件集合上设置 delete: true 选项时，不会出现"删除条目"按钮，因为不应删除预配置的文件。

### 更好的内容编辑

- 为了高效的数据输入，标记必填字段，而不是可选字段。
- 用户可以恢复对所有字段或特定字段的更改。
- 如果您恢复更改且没有未保存的更改，保存按钮会按预期禁用。¹²⁶
- 新的 readonly 字段选项使字段只读。当提供默认值且用户不应编辑字段时，这很有用。¹²⁷
- 如果验证错误字段是嵌套、折叠对象的一部分，它们会自动展开。¹²⁸
- 可以使用完整的正则表达式（包括标志）用于组件模式选项。¹²⁹ 例如，如果您想在多行文本字段中允许 280 个或更少的字符，您可以写 /^.{0,280}$/s（但您现在可以使用 maxlength 选项）。
- 长验证错误消息完整显示，不会隐藏在字段标签后面。¹³⁰
- 指向其他条目的任何链接都将按预期工作，内容编辑器会为其他条目更新。¹³¹
- 在布尔和选择组件中，保存条目后您不必更新值两次来重新启用保存按钮。¹³²
- data 可以用作字段名称，而不会在保存条目时导致错误。¹³³

### 更好的内容预览

- 预览面板带有最小的默认样式。¹³⁴ 即使没有自定义预览样式或模板，它也看起来不错。
- 为了更好的性能，除非注册了自定义预览样式表，否则预览面板不使用 `<iframe>`。³²
- 预览面板显示所有字段，包括每个标签，使查看填充了哪些字段变得更容易。
- 在字段中输入长值不会导致字段标签消失。¹³⁵
- 单击预览面板中的字段会聚焦编辑面板中的相应字段。¹³⁶ 它在折叠时自动展开。

这等价于 Decap CMS 3.6.0 中引入的（误导性）可视化编辑功能，但我们的点击高亮功能默认启用；您不需要使用 editor.visualEditing 集合选项选择加入。

- 我们的实现不会导致模块导入错误¹³⁷或损坏的图像预览。¹³⁸
- 预览面板不会导致滚动问题。¹³⁹
- 预览面板不会因 React 错误而崩溃。¹⁴⁰
- 在编辑或预览条目时提供面板之间更好的滚动同步。¹⁴¹
- 开发者可以使用新的字段选项隐藏特定字段的预览：preview: false。¹⁴²
- 有关组件特定增强（包括对变量类型¹⁴³和 YouTube 视频的支持），请参见下文。

### 更好的数据输出

- 生成的 JSON/TOML/YAML 内容中的键始终按配置字段的顺序排序，使 Git 提交干净且一致。¹⁴⁴
- Netlify/Decap CMS 经常（但不总是）从输出中省略可选和空字段。¹⁴⁵ Sveltia CMS 旨在完整和一致的数据输出 — 它始终保存适当的值，如空字符串、空数组或 null，而不是什么都没有（undefined），无论必填字段选项如何。¹⁴⁶¹⁴⁷¹⁴⁸¹⁴⁹

换句话说，在 Sveltia CMS 中，required: false 使数据输入可选，但不使数据输出可选。

要从数据输出中省略空的可选字段，请在数据输出选项中使用 omit_empty_optional_fields: true。如果您有期望 undefined 的数据类型验证，这很有用。¹⁵⁰

- JSON/TOML/YAML 数据在文件末尾保存一个新行，以防止对文件进行不必要的更改。¹⁵¹
- 保存条目时会自动删除文本类型字段值中的前导/尾随空格。¹⁵²
- YAML 字符串折叠（最大行宽）被禁用，主要是为了框架兼容性。¹⁵³
- 标准时间格式化为 HH:mm:ss 而不是 HH:mm，以实现框架兼容性。
- 当数据输出为 TOML 时，ISO 8601 格式的 DateTime 字段值以本机日期/时间格式而不是带引号的字符串存储。¹⁵⁴
- 作为数据输出选项的一部分提供 JSON/YAML 格式选项，包括缩进和引号。¹⁵⁵¹⁵⁶

> v0.5.10 中添加的 yaml_quote 集合选项现已弃用，将在 v1.0.0 中删除。yaml_quote: true 等价于新 YAML 格式选项中的 quote: double。

### 更好的组件

Sveltia CMS 支持 Netlify/Decap CMS 中可用的所有内置组件。我们在添加一些新组件的同时显著改进了这些组件。一些剩余的限制将在 1.0 版本之前解决。

#### Boolean

- 没有默认值的必填布尔字段默认保存为 false，而不会引发令人困惑的验证错误。¹⁴⁶
- 没有默认值的可选布尔字段也默认保存为 false，而不是什么都没有。¹⁴⁷

#### Code

- 由于 Prism 的广泛语言支持，有 300 多种语言可用。
- 语言切换器始终出现在用户界面中，因此很容易发现和更改选定的语言。
- 语言模式的动态加载按预期工作。¹⁵⁷
- List 字段下的 Code 字段按预期工作，保存代码和语言。¹⁵⁸
- 错误的初始值不会导致 TypeError 崩溃。¹⁵⁹

#### Color

- 组件不会导致滚动问题。¹⁶⁰
- 预览显示 RGB(A) 十六进制值和 rgb() 函数表示法。

#### DateTime

- 当您刚开始编辑新条目时，DateTime 字段不会触发内容草稿状态的更改。¹⁶¹
- 除非 picker_utc 选项为 true，否则用户的本地时间不会以 UTC 保存。¹⁶²
- 组件不会因格式化月份中的天数而抛出 RangeError。¹⁶³

#### Hidden

默认值支持以下模板标签：
- {{locale}}：当前语言环境代码。⁸³
- {{datetime}}：ISO 8601 格式的当前日期/时间。¹⁶⁴
- {{uuid}}、{{uuid_short}} 和 {{uuid_shorter}}：随机 UUID 或其较短版本，就像别名模板标签一样。¹⁶⁵

当您创建文件集合项时会保存默认值，而不仅仅是文件夹集合项。¹⁶⁶

#### List

- 可以使用新的 root 选项编辑具有顶级列表的数据文件。¹⁶⁷
- min 和 max 选项可以单独使用。您不需要指定两者来使用任一选项。¹⁶⁸
- 当 add_to_top 选项不为 true 时，添加项目按钮出现在列表底部，因此您不必每次添加新项目时都向上滚动。
- 列表项带有菜单，允许用户复制项目、在其上方/下方插入新项目或删除它。¹⁶⁹
- 用户可以展开或折叠整个列表，而"全部展开"和"全部折叠"按钮允许您一次展开或折叠列表中的所有项目。¹⁷⁰
- 没有子字段或值的必填 List 字段标记为无效。¹⁷¹ 无需设置 min 和 max 选项即可使必填选项工作。
- 没有子字段或值的可选 List 字段保存为空数组，而不是什么都没有。¹⁴⁸
- 当子字段有默认值时，可选 List 字段不会默认填充项目。¹⁷²
- 没有子字段的简单 List 字段显示为多行文本字段，¹⁷³ 用户可以使用空格¹⁷⁴和逗号¹⁷⁵作为列表项。逗号不再被视为列表分隔符。
- 用户可以预览变量类型，而无需注册预览模板。¹⁴³
- 可以省略变量类型对象中的字段。¹⁷⁶ 在这种情况下，输出中仅保存 typeKey（默认：type）。
- 如果未设置摘要选项，折叠的 List 字段不会显示像 List [ Map { "key": "value" } ] 这样的程序摘要。¹⁷⁷

#### Map

- 搜索栏使用户能够快速在地图上找到特定位置。¹⁷⁸
- 使用地理位置 API，用户可以一键获取当前位置。
- 如果字段是可选的，可以清除值。
- 使用捏合手势更直观地调整地图的缩放级别。
- 地图在暗色模式下看起来不错。

#### Markdown

- 富文本编辑器使用维护良好的 Lexical 框架构建，它解决了 Netlify/Decap CMS 中基于 Slate 的编辑器的各种问题，¹⁷⁹ 包括致命应用程序崩溃，¹⁸⁰¹⁸¹¹⁸²¹⁸³ 粘贴时丢失格式，¹⁸⁴ 粘贴时额外换行，¹⁸⁵ 粘贴时额外 HTML 注释，¹⁸⁶ 反斜杠注入，¹⁸⁷ 下拉可见性，¹⁸⁸ 和 IME 文本输入困难。⁸⁸
- 可以通过更改模式选项的顺序来设置默认编辑器模式。¹⁸⁹ 如果您想默认使用纯文本编辑器，请将 modes: [raw, rich_text] 添加到字段配置。
- Markdown 字段与变量类型 List 字段配合良好。¹⁹⁰
- 粗体和斜体的组合不会创建令人困惑的 3 星号标记。¹⁹¹ 在我们的编辑器中，粗体是 2 个星号，斜体是下划线。
- 可以一键插入内置图像组件。
- 内置图像组件允许用户在图像上添加、编辑或删除链接。¹⁹² 要禁用此功能，请将 linked_images: false 添加到 Markdown 字段选项。
- 可以将本地/远程图像粘贴/拖放到富文本编辑器中，以按预期插入它们。注意：Firefox 不支持粘贴多个图像。在 Netlify/Decap CMS 中，粘贴图像可能导致应用程序崩溃。
- 内置代码块组件的实现就像块引用一样。您可以简单地将普通段落转换为代码块，而不是添加组件。
- 编辑器中代码块中的代码可以按预期复制。¹⁹³
- 语言注释的代码块不会触发未保存的更改。¹⁹⁴
- 在预览面板中，软换行呈现为硬换行。

#### Number

如果 value_type 选项是 int（默认）或 float，required 选项是 false，且未输入值，字段将保存为 null 而不是空字符串。¹⁴⁹ 如果 value_type 是其他任何值，数据类型将保持字符串。

#### Object

Sveltia CMS 提供两种在集合中拥有条件字段的方法：¹⁹⁵

- Object 组件支持变量类型（types 和 typeKey 选项），就像 List 组件一样。¹⁹⁶
- 可选的 Object 字段（required: false）可以使用复选框手动添加或删除。¹⁹⁷ 如果未添加或删除，必填子字段不会触发验证错误，¹⁹⁸ 字段将保存为 null。

#### Relation

- 字段选项显示时无需额外的 API 请求。²⁸ 因此忽略了令人困惑的 options_length 选项，该选项默认为 20。¹⁹⁹
- 组件可靠地在摘要中显示选定的选项，在下拉列表中显示所有可用选项。²⁰⁰
- slug 可以用于 value_field 以在某些情况下显示所有可用选项而不是仅一个。²⁰¹
- 像 {{cities.*.name}} 这样带有通配符的模板字符串也可以用于 value_field。²⁰²
- display_fields 在预览面板中显示，而不是 value_field。
- 冗余的 search_fields 选项在 Sveltia CMS 中是可选的，因为它默认为 display_fields、value_field 或集合的 identifier_field，默认为 title。
- value_field 选项在 Sveltia CMS 中也是可选的，因为它默认为 {{slug}}（条目别名）。
- 在引用集合中创建的新项目立即可在选项中使用。²⁰³
- 引用的 DateTime 字段值以指定格式显示。²⁰⁴
- 可以使用字段选项引用 List 字段，这会产生单个子字段但不在数据中输出子字段名称，使用 value_field: cities.*.name 语法。（讨论）

#### Select

- 可以选择值为 0 的选项。²⁰⁵
- 标签在预览面板中显示，而不是值。

#### String

- 当在 String 字段中输入 YouTube 视频 URL 时，它在预览面板中显示为嵌入视频。如果预览不起作用，请检查您站点的 CSP。
- 当在 String 字段中输入常规 URL 时，它显示为可以在新浏览器标签中打开的链接。
- 支持接受 url 或 email 作为值的 type 选项，这将验证值为 URL 或电子邮件。
- 支持 prefix 和 suffix 字符串选项，如果用户输入值不为空，它们会自动在用户输入值前和/或后添加开发者定义的值。

#### Boolean、Number 和 String

支持 before_input 和 after_input 字符串选项，允许开发者在输入 UI 之前和/或之后显示自定义标签。²⁰⁶ 值中支持 Markdown。

> **兼容性注意：** 在 Static CMS 中，这些选项分别实现为 prefix 和 suffix，它们在 Sveltia CMS 中有不同的含义。

#### File 和 Image

- 为 File 和 Image 字段提供重新设计的一体化资产选择对话框。²⁰⁷
- 条目、文件、集合和全局资产在单独的标签上列出，便于选择。²⁰⁸
- 可以通过将新资产拖放到对话框中来上传。⁴⁰
- 也可以在对话框中输入 URL。
- 与 Pexels、Pixabay 和 Unsplash 的集成使选择和插入免费库存照片变得容易。²⁰⁹ 未来将添加更多库存照片提供商。
- 用户还可以简单地将文件拖放到 File/Image 字段上来附加它，而无需打开选择文件对话框。
- 大图像自动适应预览面板，而不是以原始大小显示，这很容易超过面板的宽度。
- 新的 accept 选项允许通过唯一文件类型说明符的逗号分隔列表过滤文件，与 `<input type="file">` 的 HTML accept 属性相同。²¹⁰
- 默认情况下，Image 组件只接受 AVIF、GIF、JPEG、PNG、WebP 或 SVG 图像。排除 BMP、HEIC、JPEG XL、PSD、TIFF 和其他不太常见或非标准文件。²¹¹
- File 组件没有默认限制。
- 如果 public_folder 包含 {{slug}} 并且您在上传资产后编辑了新条目的别名字段（例如标题），更新的别名将用于保存的资产路径。²¹² 其他动态模板标签如 {{filename}} 也将按预期填充。²¹³
- CMS 防止两次上传同一文件。它比较哈希并选择现有资产。

#### List 和 Object

- 当摘要引用关系字段²¹⁴或简单 List 字段时，摘要正确显示。
- 摘要模板标签支持转换，例如 {{fields.date | date('YYYY-MM-DD')}}。
- collapsed 选项接受值 auto，如果任何子字段被填充，则自动折叠组件。这同样适用于 List 组件的 minimize_collapsed 选项。

#### Markdown、String 和 Text

仅包含空格或换行符的必填字段将导致验证错误，就像没有输入字符一样。

#### Relation 和 Select

- 如果下拉列表有带有长换行标签的选项，它们不会与下一个选项重叠。²¹⁵
- 当有 5 个或更少选项时，UI 自动从下拉列表切换到单选按钮（单选）或复选框（多选），以便更快的数据输入。²¹⁶ 可以使用关系和选择组件的 dropdown_threshold 选项更改此数字。

#### String 和 Text

支持 minlength 和 maxlength 选项，允许开发者指定输入所需的最小和最大字符数，而无需使用模式选项编写自定义正则表达式。当给出其中一个选项时，有字符计数器可用，如果不满足条件，则显示用户友好的验证错误。

### 新组件

#### Compute

实验性计算组件允许引用同一集合中其他字段的值，类似于 List 和 Object 组件的摘要属性。²¹⁷ 使用 value 属性定义值模板，例如 posts-{{fields.slug}}。（示例）

value 属性还支持 {{index}} 的值，它可以保存列表项的索引。（示例）

#### KeyValue（Dictionary）

新的 keyvalue 组件允许用户向字段添加任意键值字符串对。²¹⁸

虽然实现与 Static CMS 兼容，但我们提供了更直观的 UI。您可以按 Enter 移动焦点或在编辑时添加新行，预览以干净的表格显示。

#### UUID

除了为条目别名生成 UUID 外，Sveltia CMS 还支持建议的 uuid 组件，具有以下属性：¹⁶⁵

- prefix：要添加到值前面的字符串。默认：空字符串。
- use_b32_encoding：是否使用 Base32 编码值。默认：false。
- read_only：是否使字段只读。默认：true。

### 更好的资产管理

- 全新的、功能齐全的资产库，与图像选择对话框分开构建，使管理所有文件（包括图像、视频和文档）变得容易。²¹⁹
- 在全局媒体文件夹和集合媒体文件夹之间导航。²²⁰
- 预览图像、音频、视频、文本和 PDF 文件。如果预览不起作用，请检查您站点的 CSP。
- 将选定资产的公共 URL、²²¹ 文件路径、文本数据或图像数据复制到剪贴板。文件路径按预期以 / 开头。²²²
- 编辑纯文本资产，包括 SVG 图像。
- 重命名现有资产。如果资产在任何条目中使用，File/Image 字段将自动使用新文件路径更新。
- 替换现有资产。
- 一次下载一个或多个选定的资产。
- 一次删除一个或多个选定的资产。
- 通过浏览或将多个资产（包括嵌套文件夹中的文件）拖放到库中，一次上传多个资产。
- 按名称或文件类型排序或过滤资产。
- 查看资产详细信息，包括大小、尺寸、提交作者/日期和使用选定资产的条目列表。
- 查看一些 Exif 元数据（如果可用），包括创建日期和在地图上显示的 GPS 坐标。

**媒体库的增强：**
- 支持新的 media_libraries 选项的多个媒体库。²²³

#### 默认媒体库

- 它带有内置图像优化器。通过几行配置，用户选择上传的图像会自动转换为 WebP 格式以减小大小，²²⁴ 还可以指定最大宽度和/或高度。²²⁵ SVG 图像也可以优化。
- File/Image 组件的 max_file_size 选项可以在全局 media_library 选项中定义，使用 default 作为库名称。它适用于所有 File/Image 条目字段，以及直接上传到资产库。该选项也可以是新 media_libraries 选项的一部分。
- 与 Netlify/Decap CMS 不同，文件以其原始名称上传。大写字母和空格不会转换为小写字母和连字符。²²⁶ 如果您想根据 slug 选项对文件名进行 slug 化，请使用 slugify_filename 默认媒体库选项。

#### 其他集成

- 集成库存照片提供商，包括 Pexels、Pixabay 和 Unsplash。²⁰⁹ 如果需要，开发者可以禁用它们。
- 未来将添加更多集成选项，包括 Amazon S3 和 Cloudflare R2/Images/Stream。
- media_folder 子文件夹中存储的资产会递归扫描并显示在资产库中。²²⁷
- 如果您想将资产存储在根文件夹中，全局 media_folder 可以是空字符串（或 . 或 /）。
- PDF 文档在资产库和选择文件对话框中都显示缩略图，使查找所需文件更容易。³⁰
- 存储在条目相对媒体文件夹中的资产显示在资产库中。²²⁸
- 删除关联条目时会自动删除这些条目相对资产，因为这些资产不适用于其他条目。²²⁹ 当您使用本地仓库时，空的封闭文件夹也会被删除。
- 隐藏文件（点文件）不会出现在资产库中。²³⁰
- 用户可以使用应用程序右上角的快速添加按钮添加资产。

### 更好的自定义

- 如果存在，应用程序在自定义挂载元素的尺寸内呈现。²³¹
- 使用 logo_url 属性定义的自定义徽标显示在全局应用程序标题和浏览器标签（favicon）上。²³² 较小的徽标也在身份验证页面上正确定位。²³³
- CMS.registerCustomFormat() 支持异步解析器/格式化器函数。²³⁴
- CMS.registerEditorComponent() 的组件定义接受 icon 属性。开发者可以指定 Material Symbols 图标名称，就像自定义集合图标一样。

### 更好的本地化

- 应用程序 UI 语言环境根据浏览器设置的首选语言自动选择。²³⁵ 用户还可以在应用程序设置中更改语言环境。因此，语言环境配置选项被忽略，不需要 CMS.registerLocale()。
- List 组件的 label 和 label_singular 不会转换为小写，这在德语中特别有问题，因为所有名词都大写。²³⁶
- 长菜单项标签，特别是在非英语语言环境中，不会溢出下拉容器。²³⁷

## 兼容性

我们正在努力让 Sveltia CMS 在可能的情况下与 Netlify/Decap CMS 兼容，以便更多用户可以无缝切换到我们的现代替代方案。在某些简单的用例场景中，它已经准备好作为 Netlify/Decap CMS 的直接替代品使用，只需更新一行代码。

但是，从未计划 100% 的功能对等，由于性能、弃用和其他因素，一些功能仍然缺失或不会添加。查看下面的兼容性信息，看看您是否可以现在或在不久的将来迁移。

### 不会实现的功能

- **Azure 和 Bitbucket 后端**：出于性能原因。如果这些平台的 API 改进允许 CMS 一次获取多个条目，我们将支持这些平台。
- **Git Gateway 后端**：也是出于性能原因。Git Gateway 自 Netlify CMS 被放弃以来一直没有积极维护，已知速度慢且容易违反速率限制。我们计划在未来开发基于 GraphQL 的高性能替代方案。
- **Netlify Identity Widget**：没有 Git Gateway 就没有用，Netlify Identity 服务本身现在已被弃用。我们计划在未来开发具有角色支持的替代解决方案，很可能使用 Cloudflare Workers 和 Auth.js。
- **GitLab 后端已弃用的客户端隐式授权**：它已从 GitLab 15.0 中删除。请改用客户端 PKCE 授权。
- **已弃用的 Netlify Large Media 服务**：考虑其他存储提供商。
- **已弃用的驼峰命名法配置选项**：根据当前的 Decap CMS 文档，请改用下划线命名法。
  - Collection：sortableFields
  - DateTime 组件：dateFormat、timeFormat、pickerUtc
  - Markdown 组件：editorComponents
  - Number 组件：valueType
  - Relation 组件：displayFields、searchFields、valueField
  - 注意：一些其他驼峰命名法选项（包括 Color 组件选项）并未弃用。
- **已弃用的 Date 组件**：它已从 Decap CMS 3.0 和 Sveltia CMS 0.10 中删除。请改用带有 time_format: false 选项的 DateTime 组件。
- **一些日期/时间格式标记**：Decap CMS 3.1.1 用 Day.js 替换了 Moment.js，Sveltia CMS 很快也会效仿。由于 Day.js 标记与 Moment.js 标记不是 100% 兼容的，在某些情况下这可能是破坏性更改。
- **Code 组件的主题和键映射内联设置，以及对某些语言的支持**：我们使用 Lexical 中的 Prism 驱动的代码块功能，而不是 CodeMirror。Prism 可能在未来被 Shiki 替换。
- **Markdown 组件的 Remark 插件**：与我们基于 Lexical 的富文本编辑器不兼容。
- **public_folder 选项中的绝对 URL**：如 Netlify/Decap CMS 文档中所述，不建议这种配置。
- **性能相关选项**：Sveltia CMS 默认启用 GraphQL 大幅改善了性能，因此这些不再相关：
  - 全局：search
  - 后端：use_graphql
  - Relation 组件：options_length
- **全局 locale 选项和 CMS.registerLocale() 方法**：如上所述，Sveltia CMS 自动检测用户的首选语言并更改 UI 语言环境。
- **CMS 对象上暴露的未记录方法**：这包括自定义后端和自定义媒体库（如果有的话）。我们将来可能支持这些功能，但我们的实现可能与 Netlify/Decap CMS 不兼容。
- **任何其他未记录的选项/功能**。有例外情况。

### 当前限制

这些 Netlify/Decap CMS 功能尚未在 Sveltia CMS 中实现。我们正在努力在预计于 2025 年底发布的 1.0 版本之前添加它们。请查看我们的发布说明和 Bluesky 以获取更新。

- 全面的站点配置验证
- 除英语和日语之外的本地化
- Cloudinary 和 Uploadcare 媒体库（#4）
- Map 组件的 LineString 和 Polygon 类型
- 自定义组件
- 自定义编辑器组件：支持预览、Object/List 组件和默认字段选项
- 自定义预览模板（#51）
- 事件钩子（#167）

由于复杂性，我们决定将以下功能推迟到预计于 2026 年初发布的 2.0 版本。Netlify/Decap CMS 在这些协作和测试功能方面有许多未解决的问题 — 我们希望以正确的方式实现它们。

- 带有部署预览链接的编辑工作流
- 开放创作
- 嵌套集合（测试版）
- File 和 Image 组件的字段特定媒体文件夹（测试版）

发现兼容性问题或其他缺失功能？请告诉我们。请记住，未记录的行为很容易被忽略。

### 与 Static CMS 的兼容性

Sveltia CMS 提供与 Static CMS（现已停止维护的 Netlify CMS 分支）的部分兼容性。由于 Static CMS 在一段时间前已被归档，我们不计划实现超出下面列出内容的其他兼容性。但是，我们仍可能采用一些我们认为有用的功能。

#### 配置选项

Static CMS 对视图过滤器/组、List 组件等进行了一些破坏性更改，而 Sveltia CMS 遵循 Netlify/Decap CMS，因此您应该仔细审查您的配置。

- 在 Sveltia CMS 中实现了可排序字段的默认选项。
- Sveltia CMS 部分支持资产库中的目录导航。如果您定义特定于集合的 media_folders，这些文件夹将显示在资产库和选择文件/图像对话框中。配置文件夹内子文件夹的显示将在正式版之前实现。我们不计划支持 media_library 的 folder_support 和 display_in_navigation 选项；子文件夹将无需配置即可显示。（#301）
- 不支持 logo_link 全局选项。请改用 display_url 或 site_url。
- 不支持 yaml 全局选项，因为 Sveltia CMS 出于前向兼容性原因不暴露底层 yaml 库选项。但是，我们确实有一些数据输出选项，包括 YAML 缩进和引号。

#### 国际化支持

不支持 enforce_required_non_default i18n 选项。Sveltia CMS 默认在所有语言环境中强制必填字段。但是，save_all_locales 或 initial_locales i18n 选项允许用户在需要时禁用非默认语言环境。开发者还可以使用必填字段选项指定语言环境子集，例如 required: [en]。

#### 组件

- DateTime 组件的日期/时间格式选项不兼容，因为 Static CMS 切换到 date-fns，而 Sveltia CMS 继续使用 Moment.js（并将很快切换到 Day.js）。请相应更新您的格式。
- KeyValue 组件在 Sveltia CMS 中以相同选项实现。
- UUID 组件也已实现，但选项不同。
- Boolean、Number 和 String 组件的 prefix 和 suffix 选项在 Sveltia CMS 中分别实现为 before_input 和 after_input。我们的 String 组件的 prefix 和 suffix 选项实际上是值的前缀和后缀。
- File 和 Image 组件的 multiple 选项将在 Sveltia CMS 正式版之前实现。（#10）

#### 自定义

不支持 CMS.registerIcon()，因为 Sveltia CMS 包含用于自定义集合图标的 Material Symbols 字体，不需要手动注册。

## 框架支持

虽然 Sveltia CMS 是用 Svelte 构建的，但应用程序是框架无关的。它是一个小的、编译的、原生 JavaScript 包，直接通过 API 管理 Git 仓库中的内容。它不与构建您站点的框架交互。

与 Netlify/Decap CMS 一样，您可以将 Sveltia CMS 与任何在构建过程中加载静态文件的框架或静态站点生成器（SSG）一起使用。这包括 Astro、Eleventy、Hugo、Jekyll、Next.js、SvelteKit、VitePress 等。

我们已经添加了对某些框架和 i18n 库中使用的功能和文件结构的支持，例如 Hugo 的索引文件包含和别名本地化、Astro 和 Zola 的 i18n 支持，以及 VitePress 的一些增强。如果您的框架有特定要求，请告诉我们。

## 后端支持

- GitLab 后端需要 GitLab 16.3 或更高版本。
- Gitea/Forgejo 后端需要 Gitea 1.24、Forgejo 12.0 或更高版本。base_url 和 api_root 后端选项的默认来源设置为 https://gitea.com（公共免费服务）而不是 https://try.gitea.io（测试实例）。

## 浏览器支持

Sveltia CMS 适用于所有现代浏览器，但由于它利用了一些新的 Web 技术，存在一些限制：

- 本地仓库工作流需要基于 Chromium 的浏览器，包括 Chrome、Edge 和 Brave。
- Safari：Test 后端不会在本地保存更改；图像优化比其他浏览器慢。
- Firefox 扩展支持版本（ESR）及其衍生版本，包括 Tor Browser 和 Mullvad Browser，不受官方支持，尽管它们可能仍然可以工作。

## 其他说明

- Sveltia CMS 需要安全上下文，这意味着它只能在 HTTPS、localhost 或 127.0.0.1 URL 上工作。如果您自己运行远程服务器且内容通过 HTTP 提供，请从 Let's Encrypt 获取 TLS 证书。
- 在测试期间添加的一些选项在产品达到正式版时可能会更改或删除。虽然我们会尽量减少破坏性更改，但请注意您的某些配置可能需要更新。

# 快速开始

## 安装和设置

目前，Sveltia CMS 主要面向现有的 Netlify/Decap CMS 用户。如果您还没有安装，请先按照他们的文档将其添加到您的站点并创建配置文件。跳过选择后端页面，改为选择 GitHub、GitLab 或 Gitea/Forgejo 后端。然后按照下面描述的方式迁移到 Sveltia CMS。

或者尝试社区成员为流行框架创建的入门套件之一：

**Astro**
- astros by @zanhk
- Astro i18n Starter by @yacosta738

**Eleventy (11ty)**
- Eleventy starter template by @danurbanowicz

**Hugo**
- Hugo module by @privatemaker
- hugolify-admin by @sebousan

Netlify/Decap CMS 网站有更多模板和示例。您可以使用其中之一并切换到 Sveltia CMS。（注意：这些第三方资源不一定经过 Sveltia CMS 团队审查。）

不幸的是，我们目前无法提供免费的安装和设置支持。随着产品的发展，我们将提供内置配置编辑器、全面的文档和官方入门套件，让每个人都更容易开始使用 Sveltia CMS。

## 迁移

首先查看上面的兼容性信息。如果您已经在使用 GitHub、GitLab 或 Gitea/Forgejo 后端的 Netlify/Decap CMS，并且没有任何不支持的功能（如自定义组件或嵌套集合），迁移到 Sveltia CMS 非常简单 — 它可以作为直接替代品使用。

使用 VS Code 等编辑器在本地打开 `/admin/index.html`，并将 CMS `<script>` 标签替换为新的：

```html
<script src="https://unpkg.com/@sveltia/cms/dist/sveltia-cms.js"></script>
```

**从 Netlify CMS 迁移：**

```diff
-<script src="https://unpkg.com/netlify-cms@^2.0.0/dist/netlify-cms.js"></script>
+<script src="https://unpkg.com/@sveltia/cms/dist/sveltia-cms.js"></script>
```

**从 Decap CMS 迁移：**

```diff
-<script src="https://unpkg.com/decap-cms@^3.0.0/dist/decap-cms.js"></script>
+<script src="https://unpkg.com/@sveltia/cms/dist/sveltia-cms.js"></script>
```

接下来，让我们在您的本地机器上测试 Sveltia CMS。如果一切正常，请将更改推送到您的仓库。

您现在可以像往常一样打开 https://[hostname]/admin/ 开始编辑。如果您已经在 Netlify/Decap CMS 上使用 GitHub 或 GitLab 登录，甚至没有身份验证过程，因为 Sveltia CMS 使用浏览器中存储的身份验证令牌。够简单！

## 编辑配置文件

为了获得更好的开发体验，我们建议在代码编辑器中为站点配置文件设置 JSON 架构。如果您安装了 YAML 扩展，VS Code 可能会自动将过时的 Netlify CMS 配置架构应用于 config.yml。要改用最新的 Sveltia CMS 配置架构，您需要指定其 URL。

## 从 Git Gateway 后端迁移

由于性能限制，Sveltia CMS 不支持 Git Gateway 后端。如果您不关心使用 Netlify Identity 的用户管理，可以改用 GitHub 或 GitLab 后端。确保除了更新配置文件外，还在 GitHub 或 GitLab 上安装 OAuth 客户端。如文档中所述，Netlify 仍然能够促进身份验证流程。

要允许其他人编辑内容，只需邀请他们到您的 GitHub 仓库并分配写入角色。但是请注意，Sveltia CMS 尚未实现任何防止多用户场景中冲突的机制。

一旦您从 Git Gateway 和 Netlify Identity 组合迁移，您可以从 HTML 中删除 Netlify Identity Widget 脚本标签：

```diff
-<script src="https://identity.netlify.com/v1/netlify-identity-widget.js"></script>
```

如果您想继续使用 Netlify Identity，不幸的是您现在无法迁移到 Sveltia CMS。我们计划在未来开发 Git Gateway 和 Netlify Identity Widget 的替代方案。

## 通过 npm 安装

对于高级用户，我们还将包作为 npm 包提供。您可以通过在项目上运行 `npm i @sveltia/cms` 或 `pnpm add @sveltia/cms` 来安装它。使用 init 方法的手动初始化流程与 Netlify/Decap CMS 相同。

## 更新

更新 Sveltia CMS 是透明的，除非您在 `<script>` 源 URL 中包含特定版本或使用 npm 包。每当您（重新）加载 CMS 时，都会通过 UNPKG 提供最新版本。CMS 还会定期检查更新，并在有新版本可用时通知您。产品达到正式版后，您可以像 Netlify/Decap CMS 一样使用语义版本范围（^1.0.0）。

如果您选择使用 npm 安装，更新包是您的责任。我们强烈建议使用 ncu 或 Dependabot 等服务来保持依赖项最新。否则，您将错过重要的错误修复和新功能。（专业提示：我们使用 `ncu -u && pnpm up` 更新依赖项。）

# 使用技巧

## 将站点从 Netlify 迁移到其他托管服务

您可以将 Sveltia CMS 管理的站点托管在任何地方，如 Cloudflare Pages 或 GitHub Pages。但从 Netlify 迁移意味着您无法再通过 Netlify 使用 GitHub 或 GitLab 登录。相反，您可以使用我们自己的 OAuth 客户端（可以轻松部署到 Cloudflare Workers），或任何其他为 Netlify/Decap CMS 制作的第三方客户端。

您还可以在 GitHub 或 GitLab 上生成个人访问令牌（PAT），并使用它登录。不需要 OAuth 客户端。虽然这种方法对开发者来说很方便，但如果您的 CMS 实例被非技术用户使用，最好设置 OAuth 客户端，因为它更用户友好且安全。

## 为配置文件启用自动完成和验证

Sveltia CMS 为配置文件提供完整的 JSON 架构，因此您可以在编辑站点配置时在喜爱的代码编辑器中获得自动完成和验证。该架构从源代码生成，始终与最新的 CMS 版本保持同步。

如果您使用 VS Code，可以通过安装 YAML 扩展并将以下内容添加到项目的 VS Code 设置文件 `.vscode/settings.json` 中来为 YAML 配置文件启用它：

```json
{
  "yaml.schemas": {
    "https://unpkg.com/@sveltia/cms/schema/sveltia-cms.json": ["/static/admin/config.yml"]
  }
}
```

如果您的配置是 JSON 格式（请参阅下一节），则不需要扩展。只需将以下内容添加到同一个 VS Code 设置文件中：

```json
{
  "json.schemas": [
    {
      "fileMatch": ["/static/admin/config.json"],
      "url": "https://unpkg.com/@sveltia/cms/schema/sveltia-cms.json"
    }
  ]
}
```

配置文件位置因框架和项目结构而异，因此请相应调整路径。例如，如果您使用 Astro，文件通常位于 `/public/admin/` 目录中。

如果您使用其他代码编辑器，请查看其文档以了解如何为 YAML 或 JSON 文件启用 JSON 架构支持。架构 URL 是 https://unpkg.com/@sveltia/cms/schema/sveltia-cms.json。

## 提供 JSON 配置文件

除了标准的 YAML 格式外，Sveltia CMS 还支持用 JSON 格式编写的配置文件。这允许开发者以编程方式生成 CMS 配置以启用批量或复杂集合。为此，只需像自定义 YAML 配置链接一样向 HTML 添加 `<link>` 标签，但类型为 application/json：

```html
<link href="path/to/config.json" type="application/json" rel="cms-config-url" />
```

或者，您可以使用 JavaScript 配置对象手动初始化 CMS。

## 提供多个配置文件

使用 Sveltia CMS，开发者可以模块化站点配置。只需提供多个配置链接，CMS 将按照 `<link>` 标签出现的顺序自动合并它们。可以使用 YAML、JSON 或两者。

```html
<link href="/admin/config.yml" type="application/yaml" rel="cms-config-url" />
<link href="/admin/collections/authors.yml" type="application/yaml" rel="cms-config-url" />
<link href="/admin/collections/pages.yml" type="application/yaml" rel="cms-config-url" />
<link href="/admin/collections/posts.yml" type="application/yaml" rel="cms-config-url" />
```

YAML 配置链接类型接受标准的 application/yaml 和非标准的 text/yaml。

> **限制：** YAML 锚点、别名和合并键只有在同一文件中才能工作，因为文件在解析为单独的 JavaScript 对象后使用 deepmerge 库合并。

## 解决身份验证错误

如果您在尝试使用授权码流程登录 GitHub、GitLab 或 Gitea/Forgejo 时遇到"身份验证中止"错误，您可能需要检查站点的跨域打开策略。COOP 标头使用不广泛，但已知会破坏弹出窗口的 OAuth 流程。如果是这种情况，将 same-origin 更改为 same-origin-allow-popups 可以解决问题。（讨论）

## 使用本地 Git 仓库

Sveltia CMS 通过移除对额外配置（local_backend 属性）和代理服务器（netlify-cms-proxy-server 或 decap-server）的需要，简化了本地仓库工作流，这要归功于某些现代浏览器中可用的文件系统访问 API。

以下是工作流步骤和提示：

1. 确保您已配置 GitHub、GitLab 或 Gitea/Forgejo 后端。
   - Netlify/Decap CMS 本地 Git 仓库文档中提到的 Git Gateway 后端在 Sveltia CMS 中不受支持，因此 name: git-gateway 不起作用。使用 github、gitlab 或 gitea 作为名称以及仓库定义。如果您还没有确定仓库名称，只需使用临时名称。
2. 启动前端框架的本地开发服务器，通常使用 `npm run dev` 或 `pnpm dev`。
3. 使用 Chrome 或 Edge 打开 http://localhost:[port]/admin/index.html。
   - 端口号因框架而异。检查前一步的终端输出。
   - 也可以使用 127.0.0.1 地址代替 localhost。
   - 如果您的 CMS 实例不在 /admin/ 下，请使用适当的路径。
   - 其他基于 Chromium 的浏览器也可能工作。Brave 用户？请参见下文。
4. 单击"使用本地仓库"，并在提示时选择项目的根目录。
   - 如果您收到错误消息"不是仓库根目录"，请确保您已使用 CUI（git init）或 GUI 将文件夹转换为仓库，并且隐藏的 .git 文件夹存在。
   - 如果您使用 Windows Linux 子系统（WSL），您可能会收到错误消息"无法打开此文件夹，因为它包含系统文件。" 这是由于浏览器的限制，您可以尝试此问题和此线程中提到的一些解决方法。
5. 使用 CMS 编辑您的内容。所有更改都对本地文件进行。
6. 在 http://localhost:[port]/ 打开开发站点以检查渲染的页面。
   - 根据您的框架，您可能需要手动重建站点以反映您所做的更改。
7. 使用 git diff 或 GitHub Desktop 等 GUI 查看产生的更改是否良好。
8. 如果满意则提交并推送更改，如果只是测试则丢弃它们。

请注意，与 Netlify/Decap CMS 一样，Sveltia CMS 中的本地仓库支持不执行任何 Git 操作。您必须使用 Git 客户端手动获取、拉取、提交和推送所有更改。将来，我们将找出是否有在浏览器中提交的方法，因为代理服务器实际上具有未记录的实验性 git 模式，可以创建对本地仓库的提交。（讨论）

您还需要在更改配置文件或检索远程更新后重新加载 CMS。我们计划使用新可用的文件系统观察器 API 消除这种手动工作。

如果您已从 Netlify/Decap CMS 迁移并对 Sveltia CMS 的本地仓库工作流感到满意，可以从配置中删除 local_backend 属性并卸载代理服务器。如果您已使用 .env 文件配置自定义端口号，也可以删除它。

## 在 Brave 浏览器中启用本地开发

在 Brave 浏览器中，您必须使用实验标志启用文件系统访问 API 才能利用本地仓库工作流。

1. 在新浏览器标签中打开 brave://flags/#file-system-access-api。
2. 单击文件系统访问 API 旁边的默认（禁用），然后选择启用。
3. 重新启动浏览器。

## 为集合使用自定义图标

您可以为每个集合指定图标，以便在集合列表中轻松识别。您不需要安装自定义图标集，因为应用程序 UI 已加载 Material Symbols 字体文件。只需从 2,500 多个图标中选择一个：

1. 访问 Google Fonts 上的 Material Symbols 页面。
2. 浏览并选择图标，复制出现在右窗格底部的图标名称。
3. 将其作为新的 icon 属性添加到 config.yml 中的集合定义之一，如下例所示。
4. 如果需要，对所有集合重复相同的步骤。
5. 提交并推送更改到您的 Git 仓库。
6. 部署更新的配置文件后重新加载 Sveltia CMS。

```yaml
fields:
  - name: tags
    label: Tags
    icon: sell # 或任何图标名称
    create: true
    folder: content/tags
```

## 在集合列表中添加分隔符

使用 Sveltia CMS，开发者可以向集合列表添加分隔符以区分不同类型的集合。为此，插入一个将 divider 选项设置为 true 的新项目。在 VS Code 中，如果 config.yml 被视为 Netlify CMS 配置文件，您可能会收到验证错误。您可以通过使用我们的 JSON 架构来解决此问题。

```yaml
collections:
  - name: products
    ...
  - divider: true
  - name: pages
    ...
```

单例集合也支持分隔符。

## 为集合使用自定义媒体文件夹

这实际上不是 Sveltia CMS 中的新功能，而是 Netlify/Decap CMS 中的未记录功能。您可以为覆盖全局媒体文件夹的每个集合指定媒体和公共文件夹。好吧，它已记录，但这可能不是您想要的。

相反，如果您想将集合的所有媒体文件添加到一个文件夹中，请指定 media_folder 和 public_folder，而不是将它们留空。诀窍是为 media_folder 使用以斜杠开头的项目相对路径，如下例所示。如果您愿意，可以先使用 Netlify/Decap CMS 尝试此操作。

```yaml
media_folder: static/media # 前导斜杠是可选的
public_folder: /media

collections:
  - name: products
    label: Products
    folder: content/products
    media_folder: /static/media/products # 确保添加斜杠
    public_folder: /media/products
```

在 Sveltia CMS 中，那些集合媒体文件夹显著显示，以便更轻松地进行资产管理。如果集合包含一个或多个 File/Image 字段，我们建议为每个集合设置 media_folder 和 public_folder。

## 指定默认排序字段和方向

Sveltia CMS 扩展了 sortable_fields 集合选项，允许开发者定义默认用于排序条目的字段名称和方向。我们的实现与 Static CMS 兼容。如果您想显示按日期从新到旧排序的条目，这特别有用：

```yaml
collections:
  - name: posts
    sortable_fields:
      fields: [title, published_date, author]
      default:
        field: published_date
        direction: descending # 默认：ascending
```

为了与 Netlify/Decap CMS 向后兼容，带有字段列表（数组）的 sortable_fields 将继续工作。

为了与 Static CMS 向后兼容，direction 选项接受标题大小写值：Ascending 和 Descending。但是，不支持 None，其效果与 ascending 相同。

## 在文件夹集合中包含 Hugo 的特殊索引文件

在此功能之前，Hugo 的特殊 _index.md 文件在文件夹集合中被隐藏，您必须创建文件集合来管理该文件，因为它通常具有与常规条目字段不同的字段集。现在，使用新的 index_file 选项，您可以将索引文件添加到相应的文件夹集合中，位于常规条目上方，以便更轻松地编辑：

```yaml
collections:
  - name: posts
    label: Blog posts
    folder: content/posts
    fields: # 常规条目的字段
      - { name: title, label: Title }
      - { name: date, label: Published Date, widget: datetime }
      - { name: description, label: Description }
      - { name: body, label: Body, widget: markdown }
    index_file:
      fields: # 索引文件的字段
        - { name: title, label: Title }
        - { name: body, label: Body, widget: markdown }
```

这是完全自定义的示例。所有选项都是可选的。

```yaml
index_file:
  name: _index # 不带语言环境或扩展名的文件名。默认：_index
  label: Index File # 人类可读的文件标签。默认：Index File
  icon: home # Material Symbols 图标名称。默认：home
  fields: # 索引文件的字段。如果省略，使用常规条目字段
    ...
  editor:
    preview: false # 如果需要隐藏预览窗格。默认：true
```

如果您的常规条目字段和索引文件字段相同且不需要任何选项，只需写：

```yaml
index_file: true
```

请注意，特殊索引文件直接放在文件夹下，不管集合的 path 选项如何。例如，如果路径是 {{year}}/{{slug}}，常规条目将保存为 content/posts/2025/title.md，但索引文件保持在 content/posts/_index.md。

## 使用单例

单例集合是文件集合的未命名、非嵌套变体，可用于管理一组预定义的数据文件。单例文件出现在内容库侧边栏的 Files 组下，用户可以直接打开内容编辑器而无需导航到文件列表。

要创建此特殊文件集合，请将新的 singletons 选项以及文件定义数组添加到站点配置的根级别。

这是传统的文件集合：

```yaml
collections:
  - name: data
    label: Data
    files:
      - name: home
        label: Home Page
        file: content/home.yaml
        icon: home
        fields: ...
      - name: settings
        label: Site Settings
        file: content/settings.yaml
        icon: settings
        fields: ...
```

它可以转换为单例集合，如下所示：

```yaml
singletons:
  - name: home
    label: Home Page
    file: content/home.yaml
    icon: home
    fields: ...
  - divider: true # 您可以添加分隔符
  - name: settings
    label: Site Settings
    file: content/settings.yaml
    icon: settings
    fields: ...
```

如果您想使用关系字段引用单例文件，请使用 _singletons（注意下划线前缀）作为集合名称。

## 使用键盘快捷键

- 查看内容库：Alt+1
- 查看资产库：Alt+2
- 搜索条目和资产：Ctrl+F（Windows/Linux）或 Command+F（macOS）
- 创建新条目：Ctrl+E（Windows/Linux）或 Command+E（macOS）
- 保存条目：Ctrl+S（Windows/Linux）或 Command+S（macOS）
- 取消条目编辑：Escape

标准键盘快捷键在 Markdown 编辑器中也可用，包括 Ctrl+B/Command+B 用于粗体文本，Ctrl+I/Command+I 用于斜体，以及 Tab 缩进列表项。

## 一键翻译条目字段

Sveltia CMS 带有便捷的 Google Cloud Translation API 集成，因此您可以从另一种语言环境翻译任何文本字段，而无需离开内容编辑器。要启用快速翻译功能：

1. 更新您的配置文件以启用具有多个语言环境的 i18n 支持。
2. 登录或注册 Google Cloud 并创建新项目。
3. 启用 Cloud Translation API。每月最多 500,000 个字符免费。
4. 创建新的 API 密钥并复制它。
5. 在 Sveltia CMS 中打开条目。
6. 单击窗格标题上的翻译按钮或每个字段的翻译按钮，就在 3 点菜单旁边。
7. 出现提示时粘贴您的 API 密钥。
8. 字段将自动翻译。

请注意，窗格标题上的翻译按钮仅翻译空字段，而字段内的翻译按钮会覆盖任何填充的文本。

早期版本的 Sveltia CMS 包含 DeepL 集成，但由于 API 限制已被禁用。将来会添加更多翻译服务。

## 本地化条目别名

在 Sveltia CMS 中，如果 i18n 结构是 multiple_files 或 multiple_folders，可以本地化条目别名（文件名）。您所需要的只是别名模板标签的 localize 过滤器：

```yaml
i18n:
  structure: multiple_folders
  locales: [en, fr]

slug:
  encoding: ascii
  clean_accents: true

collections:
  - name: posts
    label: Blog posts
    create: true
    folder: content/posts
    slug: '{{title | localize}}' # 这就是诀窍
    format: yaml
    i18n: true
    fields:
      - name: title
        label: Title
        widget: string
        i18n: true
```

使用此配置，条目保存时具有本地化文件名，而默认语言环境的别名作为额外的 translationKey 属性存储在每个文件中，这在 Hugo 的多语言支持中使用。Sveltia CMS 和 Hugo 读取此属性以链接本地化文件。

```yaml
# content/posts/en/my-trip-to-new-york.yaml
translationKey: my-trip-to-new-york
title: My trip to New York
```

```yaml
# content/posts/fr/mon-voyage-a-new-york.yaml
translationKey: my-trip-to-new-york
title: Mon voyage à New York
```

您可以通过向顶级或集合级 i18n 配置添加 canonical_slug 选项来为不同框架或 i18n 库自定义属性名称和值。下面的示例适用于 @astrolicious/i18n，它需要值中的语言环境前缀（讨论）：

```yaml
i18n:
  canonical_slug:
    key: defaultLocaleVersion # 默认：translationKey
    value: 'en/{{slug}}' # 默认：{{slug}}
```

对于 Jekyll，您可能想使用 ref 属性：

```yaml
i18n:
  canonical_slug:
    key: ref
```

## 禁用非默认语言内容

您可以通过向顶级或集合级 i18n 配置添加 save_all_locales 属性来禁用所选非默认语言环境中的内容输出。然后您会在内容编辑器右上角的三点菜单中找到"禁用（语言环境名称）"。如果翻译尚未准备好，但您想先发布默认语言环境内容，这很有用。

使用以下配置，您可以在用英语写作时禁用法语和/或德语翻译。

```yaml
i18n:
  structure: multiple_files
  locales: [en, fr, de]
  default_locale: en
  save_all_locales: false # 默认：true
```

或者，开发者可以使用新的 initial_locales 选项指定用户创建新条目草稿时默认启用的语言环境，该选项接受语言环境列表、default（仅默认语言环境）或 all（所有语言环境）。默认语言环境始终启用，即使从 initial_locales 中排除。使用此选项时，save_all_locales 被视为 false。

以下示例默认禁用德语，但用户可以根据需要手动启用它。用户还可以禁用默认启用的法语。

```yaml
i18n:
  structure: multiple_files
  locales: [en, fr, de]
  default_locale: en
  initial_locales: [en, fr]
```

## 为条目别名使用随机 ID

默认情况下，新条目文件的别名将基于条目的标题字段生成。或者，您可以指定集合的 slug 选项来使用文件创建日期或其他字段。虽然此行为通常是可接受的且对 SEO 友好，但如果标题可能稍后更改或包含中文等非拉丁字符，则不太有用。在 Sveltia CMS 中，您可以轻松为别名生成随机 UUID，而无需自定义组件！

很简单 — 只需在 slug 选项中指定 {{uuid}}（完整的 UUID v4）、{{uuid_short}}（仅最后 12 个字符）或 {{uuid_shorter}}（仅前 8 个字符）。结果看起来分别像 4fc0917c-8aea-4ad5-a476-392bdcf3b642、392bdcf3b642 和 4fc0917c。

```yaml
collections:
  - name: members
    label: Members
    slug: '{{uuid_short}}' # 或 {{uuid}} 或 {{uuid_shorter}}
```

## 配置多个媒体库

传统的 media_library 选项允许开发者仅配置一个媒体库：

```yaml
media_library:
  name: default
  config:
    max_file_size: 1024000
```

Sveltia CMS 增加了对具有新 media_libraries 选项的多个媒体库的支持，因此您可以混合使用默认媒体库（您的仓库）、Cloudinary 和 Uploadcare。新选项可以用作全局选项以及 File/Image 字段选项。

```yaml
media_libraries:
  default:
    config:
      max_file_size: 1024000 # 默认：Infinity
      slugify_filename: true # 默认：false
      transformations:
        # 请参阅下一节
  cloudinary:
    config:
      cloud_name: YOUR_CLOUD_NAME
      api_key: YOUR_API_KEY
    output_filename_only: true
  uploadcare:
    config:
      publicKey: YOUR_PUBLIC_KEY
    settings:
      autoFilename: true
      defaultOperations: '/resize/800x600/'
```

注意：Sveltia CMS 尚不支持 Cloudinary 和 Uploadcare。

## 优化上传图片

曾经想阻止最终用户向您的仓库添加巨大的图像吗？Sveltia CMS 中的内置图像优化器通过简单的配置让开发者的生活更轻松：

```yaml
media_libraries:
  default:
    config:
      transformations:
        raster_image: # 原始格式
          format: webp # 新格式，仅支持 `webp`
          quality: 85 # 默认：85
          width: 2048 # 默认：原始大小
          height: 2048 # 默认：原始大小
        svg:
          optimize: true
```

然后，每当用户选择要上传的图像时，这些图像会在浏览器内自动优化。JPEG 和 PNG 等光栅图像会转换为 WebP 格式，并在必要时调整大小。SVG 图像使用 SVGO 库进行缩小。

如果您不知道，WebP 提供比传统格式更好的压缩，现在在主要浏览器中得到广泛支持。因此没有理由不在网络上使用 WebP。

如上所述，media_libraries 选项可以是 config.yml 根级别的全局选项，适用于条目字段和资产库，也可以是 File/Image 组件的字段特定选项。

- raster_image 适用于任何支持的光栅图像格式：avif、bmp、gif、jpeg、png 和 webp。如果您愿意，可以使用特定格式作为键而不是 raster_image。
- width 和 height 选项分别是最大宽度和高度。如果图像大于指定尺寸，它将被缩小。较小的图像不会调整大小。
- 在 Safari 上文件处理有点慢，因为不支持原生 WebP 编码，而是使用 jSquash 库。
- 不支持 AVIF 转换，因为没有浏览器具有原生 AVIF 编码支持（Chromium 不会修复它），第三方库（和一般的 AVIF 编码）非常慢。
- 此功能不用于创建不同格式和大小的图像变体。应该在构建过程中使用框架完成。Astro、Eleventy、Hugo、Next.js 和 SvelteKit 等流行框架具有内置的图像处理能力。
- 我们将来可能会添加更多转换选项。

## 禁用库存资产

选择文件/图像对话框包含一些库存照片提供商以方便使用，但有时这些可能不相关。开发者可以使用以下配置隐藏它们：

```yaml
media_libraries:
  stock_assets:
    providers: []
```

## 编辑站点部署配置文件

Sveltia CMS 允许用户编辑没有扩展名的文件。示例包括 _headers 和 _redirects，它们被一些静态站点托管提供商（如 Netlify、GitLab Pages 和 Cloudflare Pages）使用。由于当使用默认的 yaml-frontmatter 格式时 body 字段保存时不带字段名称，您可以使用以下配置在内容编辑器中编辑这些文件：

```yaml
collections:
  - name: config
    label: Site Configuration
    editor:
      preview: false
    files:
      - name: headers
        label: Headers
        file: static/_headers # 路径因框架而异
        fields:
          - name: body
            label: Headers
            widget: code # 也可以是 `text`
            output_code_only: true
            allow_language_selection: false
      - name: redirects
        label: Redirects
        file: static/_redirects # 路径因框架而异
        fields:
          - name: body
            label: Redirects
            widget: code # 也可以是 `text`
            output_code_only: true
            allow_language_selection: false
```

## 编辑具有顶级列表的数据文件

Sveltia CMS 允许您编辑和保存数据文件顶级的列表，而不需要字段名称。您需要做的就是创建一个将新的 root 选项设置为 true 的单个 List 字段。下面的配置重现了这个 Jekyll 数据文件示例：

```yaml
collections:
  - name: data
    label: Data Files
    files:
      - name: members
        label: Member List
        file: _data/members.yml
        icon: group
        fields:
          - name: members
            label: Members
            label_singular: Member
            widget: list
            root: true # 这就是诀窍
            fields:
              - name: name
                label: Name
              - name: github
                label: GitHub account
```

它也适用于单例：

```yaml
singletons:
  - name: members
    label: Member List
    file: _data/members.yml
    icon: group
    fields:
      - name: members
        label: Members
        label_singular: Member
        widget: list
        root: true # 这就是诀窍
        fields:
          - name: name
            label: Name
          - name: github
            label: GitHub account
```

注意：如果文件或单例包含多个字段，则忽略 root 选项。您仍然可以在 List 字段下有子字段。

## 更改 DateTime 字段的输入类型

这里值得提及这个主题，因为当前关于 DateTime 组件的 Decap CMS 文档不清楚。默认情况下，DateTime 字段允许用户选择日期和时间，但如果需要，开发者可以更改输入类型。

将 time_format 设置为 false 以隐藏时间选择器并使输入仅为日期：

```yaml
- label: Start Date
  name: startDate
  widget: datetime
  time_format: false
```

将 date_format 设置为 false 以隐藏日期选择器并使输入仅为时间：

```yaml
- label: Start Time
  name: startTime
  widget: datetime
  date_format: false
```

我们理解这种配置可能有点令人困惑，但为了与 Netlify CMS 保持向后兼容是必要的。我们计划向 DateTime 组件添加 type 选项并引入新的输入类型：year、month 和 week。

## 在 Markdown 中将软换行渲染为硬换行

这个提示并不特定于 Sveltia CMS，但一些开发者已向维护者询问过：

在 Markdown 编辑器中，按 Shift+Enter 插入软换行（\n）。我们无法更改行为以添加硬换行（<br>） — 这是底层 Lexical 框架的限制。但是，如果您查看预览，您可能会注意到软换行呈现为硬换行。这是因为预览使用启用了 breaks 选项的 Marked 库，这模仿了 GitHub 上评论的呈现方式。

您用于前端的 Markdown 解析器很可能也可以做同样的事情：

- markdown-it（在 Eleventy 和 VitePress 中使用）也有 breaks 选项
- remarkable 也有 breaks 选项
- Showdown 有 simpleLineBreaks 选项
- goldmark（在 Hugo 中使用）有 html.WithHardWraps 选项
- kramdown（在 Jekyll 中使用）使用 GFM 解析器有 hard_wrap 选项
- remark（在 Astro 中使用）提供插件
- micromark 澄清它没有这样的选项并推荐替代方案

## 控制数据输出

Sveltia CMS 在配置文件的根级别支持一些数据输出选项，包括 JSON/YAML 格式首选项。默认选项如下所示：

```yaml
output:
  omit_empty_optional_fields: false
  encode_file_path: false # true 为 File/Image 字段的文件路径进行 URL 编码
  json:
    indent_style: space # 或 tab
    indent_size: 2
  yaml:
    quote: none # 或 single 或 double
    indent_size: 2
```

## 禁用自动部署

您可能已经在 Git 仓库上设置了 CI/CD 工具以自动将更改部署到生产环境。有时，您对内容进行大量更改以快速达到 CI/CD 提供商的（免费）构建限制，或者您只是不想看到每个小更改都触发构建。

使用 Sveltia CMS，您可以默认禁用自动部署，并在方便时手动触发部署。这是通过向提交消息添加 [skip ci] 前缀来完成的，这是 GitHub Actions、GitLab CI/CD、CircleCI、Travis CI、Netlify、Cloudflare Pages 等支持的约定。以下是使用它的步骤：

1. 将新的 automatic_deployments 属性添加到后端配置，值为 false：

```yaml
backend:
  name: github
  repo: owner/repo
  branch: main
  automatic_deployments: false
```

2. 提交并部署配置文件的更改并重新加载 CMS。
3. 现在，每当您保存条目或资产时，[skip ci] 会自动添加到每个提交消息中。但是，删除始终提交时不带前缀，以避免站点上的意外数据保留。
4. 如果您想部署新的或更新的条目以及任何其他未发布的条目和资产，请单击内容编辑器中保存按钮旁边的箭头，然后选择保存并发布。这将通过省略 [skip ci] 触发 CI/CD。

如果您将 automatic_deployments 设置为 true，行为会相反。默认情况下会触发 CI/CD，而您有一个保存而不发布的选项，该选项仅向关联的提交添加 [skip ci]。

> **注意：** 未发布的条目和资产不是草稿。一旦提交到您的仓库，这些更改可以在任何时候部署，当另一个提交在没有 [skip ci] 的情况下推送时，或者手动触发部署时。

如果定义了 automatic_deployments 属性，您可以通过单击应用程序标题上的发布更改按钮手动触发部署。要使用此功能：

**GitHub Actions：**
无需任何配置，发布更改将触发带有 sveltia-cms-publish 事件类型的 repository_dispatch 事件。更新您的构建工作流以接收此事件：

```yaml
on:
  push:
    branches: [$default-branch]
  repository_dispatch:
    types: [sveltia-cms-publish]
```

**其他 CI/CD 提供商：**
1. 在 CMS 右上角的帐户按钮下选择设置。
2. 选择高级选项卡。
3. 输入您提供商的部署钩子 URL，例如 Netlify 或 Cloudflare Pages。
4. 如有必要，配置 CSP。请参见下文。

## 设置内容安全策略

如果您的站点采用内容安全策略（CSP），请使用以下 Sveltia CMS 策略，否则某些功能可能无法工作。

```
style-src 'self' 'unsafe-inline' https://fonts.googleapis.com;
font-src 'self' https://fonts.gstatic.com;
img-src 'self' blob: data:;
media-src blob:;
frame-src blob:;
script-src 'self' https://unpkg.com;
connect-src 'self' blob: data: https://unpkg.com;
```

（UNPKG 不仅用于下载 CMS 脚本包，还用于检查最新版本和检索 PDF.js 和 Prism 语言定义等其他依赖项）

然后，根据您的 Git 后端和启用的集成添加以下来源。

**GitHub：**（如果您运行 GitHub Enterprise Server，还需要将来源添加到这些指令中。）
- img-src: https://*.githubusercontent.com
- connect-src: https://api.github.com https://www.githubstatus.com

**GitLab：**（如果您运行自托管实例，还需要将来源添加到这些指令中。）
- img-src: https://gitlab.com https://secure.gravatar.com
- connect-src: https://gitlab.com https://status-api.hostedstatus.com

**Gitea/Forgejo：**（如果您运行自托管实例，请改用来源。）
- img-src: https://gitea.com
- connect-src: https://gitea.com

**OpenStreetMap：**（在内置 Map 组件中使用）
- img-src: https://*.openstreetmap.org
- connect-src: https://*.openstreetmap.org

**Pexels：**
- img-src: https://images.pexels.com
- connect-src: https://images.pexels.com https://api.pexels.com

**Pixabay：**
- img-src: https://pixabay.com
- connect-src: https://pixabay.com

**Unsplash：**
- img-src: https://images.unsplash.com
- connect-src: https://images.unsplash.com https://api.unsplash.com

**Google Cloud Translation：**
- connect-src: https://translation.googleapis.com

**YouTube：**
- frame-src: https://www.youtube-nocookie.com

如果您选择禁用自动部署并配置了 webhook URL，您可能需要将来源添加到 connect-src 指令。例如，

**Netlify：**
- connect-src: https://api.netlify.com

**Cloudflare Pages：**
- connect-src: https://api.cloudflare.com

如果您有图像字段并期望图像将作为 URL 插入，您可能希望使用通配符允许任何来源，而不是指定单个来源：

```
img-src 'self' blob: data: https://*;
```

## 显示 CMS 版本

1. 单击应用程序右上角的头像以打开帐户菜单。
2. 单击设置。
3. 单击高级选项卡。
4. 启用开发者模式。
5. 关闭设置对话框。
6. 发布说明链接现在将出现在帐户菜单下，带有当前应用程序版本。

# 支持与反馈

虽然我们没有专门的开发者/用户支持资源，但您可以在我们 GitHub 仓库的“讨论”页面上发布简短问题。我们也欢迎反馈，但在开始新的讨论之前，请查看本 README 的“兼容性”和“路线图”部分——您的想法可能已经被涵盖。

加入我们的 Discord 或在 Bluesky 上联系我们进行非正式聊天。

如本 README 通篇所述，Sveltia CMS 是作为 Netlify/Decap CMS 的替代品而构建的。在这一点上，我们假设大多数开发者和用户都是从其他产品迁移过来的。我们很乐意帮助您迁移，但我们无法通过免费支持渠道帮助您从头开始设置 Sveltia CMS。

计划用 Sveltia CMS 构建网站？正在寻找专业支持？维护者 @kyoshino 可根据您的需求提供有偿服务。请随时联系！

# 贡献

请参阅《为 Sveltia CMS 做贡献》。非常鼓励提交错误报告！

# 路线图

下面的列表让您了解我们目前正在进行的工作以及未来计划实现的内容。它并非所有问题的完整列表，而是最重要的功能和改进的摘要。随着我们的进展，情况可能会发生变化，因此请定期回来查看。

## v1.0

预计 2025 年底发布

- 增强与 Netlify/Decap CMS 的兼容性
- 解决更多 Netlify/Decap CMS 问题：
  - 资产库中的目录导航
  - 使用文件和图像小部件进行多文件选择
  - GitHub 后端的 Git LFS 支持
  - 高级关系字段，包括级联更新/删除和反向引用列表
  - 几个 Cloudinary 和 Uploadcare 媒体库问题，包括选择现有文件
  - 使用模板自动重命名资产文件
  - RTL 本地化支持
  - 全面的站点配置验证
  - 条目预验证/规范化
  - 以及更多一些错误
- 从 Moment.js 迁移到 Day.js
- 可访问性审计
- 本地化
- 开发者文档（实施指南）
- 营销网站
- 实时演示网站

## v2.0

预计 2026 年初发布

- 实现一些推迟的 Netlify/Decap CMS 功能，包括编辑工作流和嵌套集合
- 最终用户文档

## 未来

- 解决许多剩余的 Netlify/Decap CMS 问题，包括：
  - MDX 支持
  - 手动条目排序
  - Markdown 中的表格
  - 配置编辑器
  - 离线支持
  - 以及其他高票功能
  - （其中一些可能包含在 v2.0 中）
- Sveltia CMS 附加功能：提供无法在客户端实现的功能的边缘函数：
  - 用户管理（Netlify Identity 替代品）与角色
  - 无需 Git 服务帐户登录（Git Gateway 替代品）
  - 帖子锁定（类似 WordPress）
  - 定时发布
  - 服务 API 密钥、部署钩子 URL 等的凭据管理
- 对自定义小部件、编辑器组件和预览模板的 Preact+HTM 支持
- 查看、比较和恢复修订（类似 WordPress）
- 更多集成选项：图库照片、视频、云存储提供商、翻译服务、地图、分析工具等。
- 用于图像生成、内容编写、翻译等的 AI 集成
- 搜索增强功能
- 高级数字资产管理（DAM）功能，包括图像编辑和标记
- 自定义小部件等的市场
- 最流行框架的官方入门模板，包括 SvelteKit 和 Next.js
- 贡献者文档
- 以及更多！

# 趣闻

- Netlify CMS 的原始版本是用 Ember 构建的，然后用 React 重写。现在我们正在用 Svelte 完全重写它。所以这实际上是该应用程序第二次进行框架迁移。
- 我们的本地存储库工作流与测试后端共享实现，因为两者都利用文件系统 API，这使我们能够降低维护成本。无缝的本地工作流不仅对于改善开发者体验至关重要，而且对于我们的快速应用程序开发也至关重要。

# 相关链接

- 介绍 Sveltia CMS：@kyoshino 在 2023 年 3 月 31 日的 This Week in Svelte 在线聚会上的简短技术演示 — 录音和幻灯片

## 媒体报道

- LogRocket 博客 – 为您的下一个项目选择 9 个最佳的基于 Git 的 CMS 平台
- Jamstack – 无头 CMS
- Hugo – 前端界面
- 用 Svelte 制作

# 免责声明

本软件按“原样”提供，没有任何明示或暗示的保证。我们没有义务为该应用程序提供任何支持。本产品不隶属于 Netlify、Decap CMS 或任何其他集成服务，也未得到其认可。所有产品名称、徽标和品牌均为其各自所有者的财产。