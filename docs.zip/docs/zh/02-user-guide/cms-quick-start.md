# CMS 快速开始指南

## 🚀 快速登录

1. **访问 CMS**：https://vibby.ai/admin
2. **输入 GitHub Personal Access Token**
3. **开始编辑内容**

## 📝 内容管理

### 博客文章
- **位置**：Blog Posts
- **功能**：创建、编辑、删除博客文章
- **支持**：Markdown 编辑、SEO 设置、标签管理

### 页面管理
- **位置**：Pages
- **功能**：管理静态页面内容
- **支持**：多语言内容（中英文）

### 首页内容
- **位置**：Home
- **包含**：
  - Navigation（导航菜单）
  - Hero Section（英雄区域）
  - Features Section（功能介绍）
  - FAQ Section（常见问题）
  - Footer（页脚）

### 界面文本
- **位置**：UI文本
- **功能**：管理网站界面的多语言文本
- **支持**：中英文切换

### 游戏配置
- **位置**：Game Configuration
- **功能**：配置游戏相关内容（当网站模式为游戏时使用）

## 💡 使用技巧

1. **保存草稿**：编辑时会自动保存草稿
2. **预览功能**：可以预览内容效果
3. **媒体管理**：支持图片上传和管理
4. **版本控制**：所有更改都会提交到 GitHub

## 🔧 常见问题

**Q: 如何上传图片？**
A: 在编辑器中点击图片图标，选择文件上传

**Q: 如何添加新的博客文章？**
A: 进入 Blog Posts，点击 "New Blog Posts"

**Q: 修改后多久生效？**
A: 保存后会自动触发网站重新部署，通常 1-2 分钟生效

**Q: 如何退出登录？**
A: 清除浏览器数据或使用隐身模式

## 📚 更多帮助

- [完整认证指南](./cms-authentication-guide.md)
- [Sveltia CMS 官方文档](https://github.com/sveltia/sveltia-cms)
