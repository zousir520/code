# 内容管理指南

掌握 **Vibby.ai** 强大的内容管理系统。本指南涵盖从基础内容编辑到高级内容策略的所有内容。

## 📝 内容管理概述

Vibby.ai 使用**基于文件的 CMS** 方法配合 **Sveltia CMS** 界面，提供：

- **基于文件存储** - 内容作为文件存储在您的仓库中
- **Git 集成** - 所有内容更改的版本控制
- **可视化编辑器** - 非技术用户友好的界面
- **Markdown 支持** - 富文本编辑与 Markdown
- **媒体管理** - 图片和文件上传
- **多语言支持** - 多种语言的内容

## 🎛️ 访问 CMS

### CMS 界面

1. **导航到管理**：在浏览器中访问 `/vibbyai`
2. **访问 CMS**：点击"内容管理"或访问 `/vibbyai/cms`
3. **登录**（如果需要）：使用您的管理员凭据

### CMS 仪表板概览

```
┌─────────────────────────────────────────┐
│ 📊 Sveltia CMS 仪表板                   │
├─────────────────────────────────────────┤
│ 📄 集合：                              │
│   • 博客文章                           │
│   • 页面                               │
│   • 主页内容                           │
│   • 导航                               │
│   • 网站设置                           │
│                                         │
│ 📁 媒体库                              │
│ ⚙️ 工作流                              │
│ 👤 身份                                │
└─────────────────────────────────────────┘
```

## 📄 内容类型

### 1. 博客文章

**位置**：`src/content/blog/`

#### 创建新博客文章

1. **打开 CMS**：导航到 `/vibbyai/cms`
2. **选择集合**：点击"博客文章"
3. **创建新文章**：点击"新博客文章"
4. **填写详情**：
   - **标题**：您的文章标题
   - **URL 标识**：URL 友好版本（自动生成）
   - **日期**：发布日期
   - **作者**：文章作者
   - **内容**：主要文章内容（Markdown）
   - **摘要**：简要描述
   - **特色图片**：可选的英雄图片
   - **标签**：逗号分隔的标签
   - **SEO 设置**：元描述、关键词

#### 博客文章结构

```markdown
---
title: "您的精彩博客文章"
slug: "your-amazing-blog-post"
date: "2024-01-15"
author: "您的姓名"
excerpt: "文章的简要描述"
image: "/images/blog/your-post-image.jpg"
tags: ["AI", "创业", "技术"]
published: true
---

# 您的博客文章内容

在这里使用 **Markdown** 格式编写您的内容。

## 子标题

- 项目符号
- **粗体文字**
- *斜体文字*
- [链接](https://example.com)

### 代码示例

\`\`\`javascript
console.log("你好，世界！");
\`\`\`

![图片](/images/example.jpg)
```

#### 博客文章 SEO

**自动 SEO 功能**：
- 自动生成元描述
- Open Graph 标签
- Twitter 卡片
- JSON-LD 结构化数据
- 站点地图包含

**手动 SEO 设置**：
```yaml
seo:
  title: "自定义 SEO 标题"
  description: "自定义元描述"
  keywords: "关键词1, 关键词2, 关键词3"
  ogImage: "/images/custom-og-image.jpg"
```

### 2. 静态页面

**位置**：`src/content/pages/`

#### 创建静态页面

1. **访问页面集合**：在 CMS 中，选择"页面"
2. **创建新页面**：点击"新页面"
3. **页面配置**：
   - **标题**：页面标题
   - **URL 标识**：URL 路径
   - **内容**：页面内容
   - **模板**：页面布局
   - **元设置**：SEO 配置

#### 页面模板

可用的页面模板：
- **默认**：标准页面布局
- **着陆页**：营销着陆页
- **联系**：联系表单页面
- **关于**：包含团队部分的关于页面
- **定价**：定价表页面

### 3. 主页内容

**位置**：`src/content/home/`

#### 主页部分

##### 英雄部分 (`hero.json`)
```json
{
  "title": "快速构建您的 AI 创业公司",
  "subtitle": "启动您的 AI 创业公司所需的一切",
  "description": "获取 CMS、博客、管理仪表板等",
  "cta": {
    "primary": {
      "label": "开始使用",
      "url": "/signup"
    },
    "secondary": {
      "label": "了解更多",
      "url": "/about"
    }
  },
  "image": "/images/hero-image.jpg",
  "features": [
    "🚀 快速设置",
    "🎨 美丽设计", 
    "🔧 易于自定义"
  ]
}
```

##### 功能部分 (`features.json`)
```json
{
  "title": "强大功能",
  "subtitle": "一个平台上的所有需求",
  "features": [
    {
      "icon": "⚡",
      "title": "闪电般快速",
      "description": "使用 SvelteKit 构建，性能最佳",
      "link": "/features/performance"
    },
    {
      "icon": "🎨", 
      "title": "美丽设计",
      "description": "开箱即用的现代响应式设计",
      "link": "/features/design"
    }
  ]
}
```

##### FAQ 部分 (`faq.json`)
```json
{
  "title": "常见问题",
  "faqs": [
    {
      "question": "我能多快开始使用？",
      "answer": "通过我们的快速开始指南，您可以在 5 分钟内让您的网站运行起来。"
    },
    {
      "question": "我需要编程经验吗？",
      "answer": "不需要！我们的 CMS 界面允许您在没有任何编程知识的情况下管理内容。"
    }
  ]
}
```

### 4. 导航管理

**位置**：`src/content/home/navigation.json`

#### 头部导航
```json
{
  "header": {
    "logo": {
      "text": "Vibby.ai",
      "image": "/images/logo.svg"
    },
    "menu": [
      {
        "label": "首页",
        "url": "/",
        "children": []
      },
      {
        "label": "产品",
        "url": "/products",
        "children": [
          {
            "label": "AI 工具",
            "url": "/products/ai-tools"
          },
          {
            "label": "分析",
            "url": "/products/analytics"
          }
        ]
      }
    ]
  }
}
```

#### 底部导航
```json
{
  "footer": {
    "sections": [
      {
        "title": "产品",
        "links": [
          { "label": "功能", "url": "/features" },
          { "label": "定价", "url": "/pricing" }
        ]
      }
    ],
    "social": [
      {
        "platform": "twitter",
        "url": "https://twitter.com/yourhandle",
        "icon": "twitter"
      }
    ]
  }
}
```

## 🌍 多语言内容

### 语言结构

```
src/content/
├── blog/
│   ├── 2024-01-15-post-title.md        # 英语（默认）
│   └── 2024-01-15-post-title.zh.md     # 中文
├── pages/
│   ├── about.md                        # 英语
│   └── about.zh.md                     # 中文
└── home/
    ├── hero.json                       # 英语
    └── hero.zh.json                    # 中文
```

### 创建多语言内容

#### 方法 1：语言后缀
```
post-title.md      # 英语版本
post-title.zh.md   # 中文版本
```

#### 方法 2：语言目录
```
en/
  ├── blog/
  └── pages/
zh/
  ├── blog/
  └── pages/
```

#### 语言配置

在您的内容前言中：
```yaml
---
title: "英语标题"
lang: "en"
translations:
  zh: "chinese-title-slug"
---
```

### 语言切换

系统自动：
- 检测用户语言偏好
- 显示合适的内容版本
- 在导航中提供语言切换器
- 如果翻译不可用则回退到默认语言

## 📁 媒体管理

### 上传媒体

1. **访问媒体库**：在 CMS 中，点击"媒体"
2. **上传文件**：拖放或点击浏览
3. **组织**：创建文件夹并组织文件
4. **插入**：在您的内容中使用媒体

### 媒体组织

```
static/uploads/
├── images/
│   ├── blog/
│   ├── pages/
│   └── gallery/
├── documents/
└── downloads/
```

### 图片优化

**自动优化**：
- 支持浏览器的 WebP 转换
- 响应式图片大小
- 懒加载
- 必需的 Alt 文本

**手动优化**：
```markdown
![Alt 文本](/images/example.jpg)

<!-- 自定义大小 -->
<img src="/images/example.jpg" alt="Alt 文本" width="800" height="600" />

<!-- 响应式图片 -->
<picture>
  <source srcset="/images/example.webp" type="image/webp">
  <img src="/images/example.jpg" alt="Alt 文本">
</picture>
```

## 🔧 高级内容功能

### 自定义字段

在 `static/admin/config.yml` 中为集合添加自定义字段：

```yaml
collections:
  - name: "blog"
    fields:
      - { label: "标题", name: "title", widget: "string" }
      - { label: "自定义字段", name: "customField", widget: "text" }
      - {
          label: "精选",
          name: "featured",
          widget: "boolean",
          default: false
        }
      - {
          label: "分类",
          name: "category",
          widget: "select",
          options: ["技术", "商业", "设计"]
        }
```

### 内容关系

链接相关内容：

```yaml
# 在博客文章前言中
related_posts:
  - "相关文章1的标识"
  - "相关文章2的标识"

# 在页面前言中
featured_products:
  - "产品1"
  - "产品2"
```

### 内容计划

计划内容发布：

```yaml
---
title: "未来文章"
date: "2024-06-01"  # 未来日期
published: false    # 手动控制
scheduledFor: "2024-06-01T09:00:00Z"
---
```

### 动态内容

在内容中使用变量：

```markdown
欢迎来到 {{site.name}}！ 

请通过 {{site.contact.email}} 联系我们。

当前年份：{{date.year}}
```

## 📊 内容分析

### 内置分析

跟踪内容表现：
- 页面浏览量
- 阅读时间
- 热门内容
- 搜索查询
- 用户参与度

### 内容洞察

在管理仪表板中访问：
- 最受查看的文章
- 内容参与度指标
- SEO 表现
- 搜索排名位置

## 🔍 内容 SEO

### 自动 SEO 功能

**自动生成**：
- 元标题和描述
- Open Graph 标签
- Twitter 卡片
- JSON-LD 结构化数据
- XML 站点地图
- Robots.txt

### SEO 最佳实践

#### 内容优化
- **标题长度**：50-60 个字符
- **元描述**：150-160 个字符
- **标题结构**：适当的 H1、H2、H3 层次
- **图片 Alt 文本**：描述性的 alt 属性
- **内部链接**：链接到相关内容

#### 技术 SEO
```markdown
---
title: "SEO 优化的标题"
description: "160 字符以下的吸引人元描述"
keywords: "主要关键词, 次要关键词"
canonical: "https://yourdomain.com/canonical-url"
robots: "index, follow"
---
```

## 🚀 内容工作流

### 编辑工作流

1. **草稿**：创建和编辑内容
2. **审核**：内部审核过程
3. **批准**：最终批准
4. **发布**：内容上线
5. **更新**：定期内容更新

### 版本控制

所有内容更改都被跟踪：
- **Git 历史**：完整版本历史
- **更改跟踪**：查看谁更改了什么
- **回滚**：恢复到之前的版本
- **分支**：在分支中处理内容

### 内容备份

**自动备份**：
- Git 仓库备份
- 媒体文件备份
- 数据库备份（如果使用）

**手动备份**：
```bash
# 备份内容
git add .
git commit -m "内容备份"
git push origin main

# 备份媒体
rsync -av static/uploads/ backup/uploads/
```

## 🆘 内容故障排除

### 常见问题

#### 内容不显示
- 检查文件命名约定
- 验证前言语法
- 确保 published: true
- 检查文件权限

#### 图片不加载
- 验证文件路径
- 检查图片文件大小
- 确保适当的上传位置
- 验证图片格式

#### CMS 访问问题
- 清除浏览器缓存
- 检查管理员凭据
- 验证 CMS 配置
- 检查网络连接

### 获取帮助

- **文档**：[故障排除指南](../06-troubleshooting/common-issues.md)
- **社区**：[内容管理讨论](https://github.com/gstarwd/vibby.ai/discussions)
- **支持**：[报告内容问题](https://github.com/gstarwd/vibby.ai/issues/new)

---

**内容管理掌握完毕！** 🎉  
**下一步**：[学习博客管理](./blog-management.md) 或 [探索管理仪表板](./admin-dashboard.md)