# Site Mode 环境变量控制说明

## 概述

Site Mode 现在完全通过环境变量控制

## 修改内容

### 1. API 端点修改

#### GET /api/site-config
- **仅从环境变量读取**：移除了数据库和文件回退机制
- **验证环境变量**：确保 `PUBLIC_SITE_TYPE` 设置且值有效
- **错误处理**：缺失或无效环境变量时返回明确错误信息

#### POST /api/site-config
- **完全禁用**：返回 405 状态码和说明信息
- **只读模式**：明确告知用户配置为只读模式

### 2. 前端页面修改

#### /vibbyai/sitemode 页面
- **移除切换功能**：不再允许用户动态切换站点模式
- **只读显示**：展示当前配置和配置来源
- **配置指南**：提供详细的环境变量设置说明

### 3. TypeScript 类型更新

#### src/lib/stores/siteConfig.ts
- **移除写入函数**：删除 `updateSiteConfig` 函数
- **简化接口**：更新 `SiteConfig` 接口
- **添加响应类型**：新增 `SiteConfigResponse` 类型

## 环境变量配置

### 必需变量

```bash
PUBLIC_SITE_TYPE=site-game
```

### 支持的值

- `site-tool` - 工具型网站
- `site-game` - 游戏型网站  
- `site-blog` - 博客型网站

### 本地开发

创建或编辑 `.env.local` 文件：

```bash
# Site Type Configuration
PUBLIC_SITE_TYPE=site-game
```

重启开发服务器：
```bash
npm run dev
```

### 生产环境（Vercel）

1. 登录 Vercel Dashboard
2. 进入项目设置 → Environment Variables
3. 添加变量：
   - Name: `PUBLIC_SITE_TYPE`
   - Value: `site-game` (或其他支持的值)
   - Environment: All environments
4. 重新部署应用

## 错误处理

### 缺失环境变量

```json
{
  "error": "MISSING_SITE_TYPE",
  "message": "必须设置 PUBLIC_SITE_TYPE 环境变量",
  "instruction": "请在环境变量中设置 PUBLIC_SITE_TYPE，支持的值：site-tool, site-game, site-blog"
}
```

### 无效环境变量

```json
{
  "error": "INVALID_SITE_TYPE", 
  "message": "无效的站点类型: invalid-type",
  "instruction": "支持的值：site-tool, site-game, site-blog"
}
```

### 尝试写入配置

```json
{
  "error": "READONLY_CONFIG",
  "message": "Site mode 配置为只读模式，仅通过环境变量控制",
  "instruction": "请设置 PUBLIC_SITE_TYPE 环境变量来修改站点模式..."
}
```

## 配置验证

### API 测试

```bash
# 测试 API 端点
curl -s http://localhost:5173/api/site-config

# 预期响应
{
  "type": "site-game",
  "source": "environment"
}
```

### 前端测试

访问 `/vibbyai/sitemode` 页面确认：
1. 显示当前站点模式
2. 显示配置来源为"环境变量"
3. 提供正确的配置指南

## 安全优势

1. **防止运行时修改**：配置无法在应用运行时被修改
2. **环境隔离**：不同环境可以有不同的配置
3. **版本控制安全**：敏感配置不会进入代码库
4. **部署一致性**：确保部署后配置符合预期

## 数据清理

### 已删除的文件和配置

1. **配置文件**：`src/content/site-config.json` 已删除
2. **数据库表**：通过迁移脚本清理 `site_config` 相关表和函数
3. **数据库函数**：清理 `get_site_config` 和 `set_site_config` 函数

### 数据库清理迁移

运行以下迁移脚本清理数据库：

```sql
-- 执行清理迁移
supabase db push

-- 或手动执行 SQL 文件
psql -f supabase/migrations/999_cleanup_site_config.sql
```

清理内容包括：
- 删除 `public.site_config` 表
- 删除 `site_config` 表（来自 004_create_game_config_table.sql）
- 删除相关存储函数
- 记录变更日志

## 迁移指南

### 从旧版本迁移

1. **设置环境变量**：在部署环境中设置 `PUBLIC_SITE_TYPE`
2. **运行清理迁移**：执行 `999_cleanup_site_config.sql` 清理数据库
3. **删除配置文件**：移除 `src/content/site-config.json`（已自动删除）
4. **更新部署流程**：确保环境变量在 CI/CD 中正确设置
5. **测试验证**：确认配置正确加载

### 回滚计划

如需回滚到支持数据库配置的版本：
1. 恢复 `src/routes/api/site-config/+server.ts` 的 POST 方法
2. 恢复 `src/routes/vibbyai/sitemode/+page.svelte` 的切换功能
3. 恢复 `src/lib/stores/siteConfig.ts` 的写入函数

## 常见问题

### Q: 如何在不同环境使用不同配置？
A: 在各环境的环境变量中设置不同的 `PUBLIC_SITE_TYPE` 值。

### Q: 本地开发时如何快速切换模式？
A: 修改 `.env.local` 文件中的 `PUBLIC_SITE_TYPE` 值并重启服务器。

### Q: 生产环境忘记设置环境变量怎么办？
A: API 会返回错误信息，在 Vercel Dashboard 中添加环境变量后重新部署。

### Q: 可以恢复动态切换功能吗？
A: 可以，但不推荐。参考回滚计划或联系开发团队。