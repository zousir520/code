# CMS 认证配置指南

## 概述

本项目使用 Sveltia CMS 进行内容管理，支持 GitHub Personal Access Token (PAT) 认证方式，无需复杂的 OAuth 配置。

## 认证方式

我们使用 **GitHub Personal Access Token** 进行认证，这种方式：
- 🚀 **简单快速**：无需复杂的 OAuth 设置
- 🔒 **安全可控**：可以随时撤销 token
- 🛠️ **开发者友好**：适合个人或小团队使用
- 💾 **自动保存**：浏览器会记住 token，无需每次输入

## 配置步骤

### 1. 生成 GitHub Personal Access Token

1. **访问 GitHub Settings**：
   - 去 https://github.com/settings/tokens
   - 点击 "Generate new token" → "Generate new token (classic)"

2. **配置 Token**：
   - **Note**: `Sveltia CMS for vibby.ai`
   - **Expiration**: 建议选择 90 days 或 No expiration
   - **Scopes**: 勾选以下权限：
     - ✅ `repo` (Full control of private repositories)
     - ✅ `user` (Read user profile data)

3. **生成并保存 Token**：
   - 点击 "Generate token"
   - **重要**：立即复制并保存 token，因为它只会显示一次

### 2. CMS 配置

确保 `static/admin/config.yml` 配置如下：

```yaml
backend:
  name: github
  repo: gstarwd/vibby.ai
  branch: main
  # 禁用 OAuth，强制使用 Personal Access Token
  base_url: null

media_folder: static/uploads
public_folder: /uploads
# ... 其他配置
```

### 3. 登录 CMS

1. **访问 CMS**：
   ```
   https://vibby.ai/admin
   ```

2. **输入 Personal Access Token**：
   - 在登录界面的输入框中粘贴你的 GitHub PAT
   - 点击登录

3. **自动保存**：
   - 浏览器会自动保存 token
   - 下次访问无需重新输入（除非清除浏览器数据）

## 优势

1. **无需 OAuth 配置**：不需要设置复杂的 OAuth 应用和回调 URL
2. **简单安全**：直接使用 GitHub 的 Personal Access Token
3. **开发者友好**：适合个人项目和小团队
4. **自动保存**：浏览器会记住认证状态，无需重复登录

## 安全注意事项

1. **Token 权限**：只授予必要的权限（repo, user）
2. **Token 过期**：定期更新 token，建议设置合理的过期时间
3. **Token 保护**：不要在代码中硬编码 token
4. **撤销 Token**：如果怀疑 token 泄露，立即在 GitHub 设置中撤销

## 故障排除

### 问题：还是显示 "Sign In with GitHub" 按钮
**解决方案**：
1. 清除浏览器缓存并强制刷新 (Ctrl+Shift+R)
2. 检查 `config.yml` 中是否有 `base_url: null` 配置
3. 等待部署完成后重试

### 问题：输入 Token 后登录失败
**解决方案**：
1. 检查 Token 是否有正确的权限（repo, user）
2. 确认 Token 没有过期
3. 验证仓库名称是否正确

### 问题：需要重新输入 Token
**原因**：
- 清除了浏览器数据
- 使用了不同的浏览器或设备
- Token 已过期

## 文件结构

```
static/admin/
├── config.yml              # CMS 配置文件
src/content/                 # 内容文件
├── blog/                    # 博客文章
├── pages/                   # 静态页面
├── home/                    # 首页内容
└── ui-text.json            # 界面文本
```
