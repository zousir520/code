# 管理后台指南

完整的 Vibby.ai 管理后台使用指南，包含所有功能模块和操作说明。

## 访问管理后台

### 登录方式

1. **直接访问**
   ```
   https://yourdomain.com/admin
   ```

2. **从主站导航**
   - 点击页面右上角的"管理"按钮
   - 或在用户菜单中选择"管理后台"

### 认证流程

```typescript
// 支持多种登录方式
- 邮箱密码登录
- GitHub OAuth
- Google OAuth
- 魔法链接（无密码登录）
```

## 仪表板概览

### 主要指标

管理后台首页显示关键业务指标：

- **访问统计**: 今日/本周/本月访问量
- **内容统计**: 文章数量、页面浏览量
- **用户活动**: 注册用户、活跃用户
- **SEO 表现**: 搜索排名、点击率

### 快速操作

```bash
# 常用快速操作
- 创建新文章
- 查看最新评论
- 检查系统状态
- 查看错误日志
```

## 内容管理

### 文章管理

#### 创建新文章

1. **基础信息**
   ```yaml
   标题: "你的文章标题"
   摘要: "文章简介，用于SEO和社交分享"
   作者: "选择或输入作者信息"
   发布日期: "选择发布时间"
   ```

2. **内容编辑**
   - 使用 Markdown 编辑器
   - 支持实时预览
   - 支持图片拖拽上传
   - 代码语法高亮

3. **SEO 设置**
   ```yaml
   SEO标题: "针对搜索引擎优化的标题"
   Meta描述: "搜索结果中显示的描述"
   关键词: "相关关键词，逗号分隔"
   社交图片: "分享时显示的图片"
   ```

4. **发布选项**
   - 立即发布
   - 定时发布
   - 保存为草稿
   - 密码保护

#### 文章列表管理

**筛选和搜索**
```bash
# 按状态筛选
- 已发布
- 草稿
- 已删除
- 定时发布

# 按分类筛选
- 技术文章
- 产品更新
- 公司新闻

# 搜索功能
- 按标题搜索
- 按内容搜索
- 按作者搜索
- 按标签搜索
```

**批量操作**
- 批量发布/取消发布
- 批量删除
- 批量修改分类
- 批量导出

### 页面管理

#### 静态页面

创建和管理网站的静态页面：

```yaml
# 常见页面类型
- 关于我们
- 联系方式
- 隐私政策
- 服务条款
- 产品介绍
- 团队介绍
```

#### 动态页面

管理基于数据的动态页面：

```typescript
// 页面配置示例
{
  "slug": "products",
  "template": "product-list",
  "data_source": "supabase",
  "filters": {
    "status": "published",
    "category": "ai-tools"
  },
  "pagination": {
    "per_page": 12,
    "show_numbers": true
  }
}
```

### 媒体库

#### 文件上传

```bash
# 支持的文件类型
图片: JPG, PNG, WebP, SVG, GIF
文档: PDF, DOC, DOCX
视频: MP4, WebM (小于100MB)
音频: MP3, WAV (小于50MB)
```

#### 图片优化

自动进行的优化：
- WebP 格式转换
- 多尺寸响应式版本
- 延迟加载标记
- 压缩和质量优化

#### 媒体组织

```bash
# 文件夹结构
/uploads/
  ├── blog/          # 博客文章图片
  ├── pages/         # 页面图片
  ├── products/      # 产品图片
  ├── team/          # 团队照片
  └── misc/          # 其他文件
```

## 用户管理

### 用户列表

查看和管理所有注册用户：

```typescript
// 用户信息字段
{
  id: string;
  email: string;
  username: string;
  full_name: string;
  avatar_url: string;
  role: 'admin' | 'editor' | 'user';
  status: 'active' | 'suspended' | 'pending';
  last_login: Date;
  created_at: Date;
}
```

### 角色和权限

#### 角色定义

**管理员 (Admin)**
- 完全访问权限
- 用户管理
- 系统设置
- 数据导入/导出

**编辑者 (Editor)**
- 内容创建和编辑
- 媒体库管理
- 评论管理
- SEO 设置

**用户 (User)**
- 基础内容查看
- 个人资料编辑
- 评论和互动

#### 权限矩阵

| 功能 | 管理员 | 编辑者 | 用户 |
|------|--------|--------|------|
| 创建文章 | ✅ | ✅ | ❌ |
| 发布文章 | ✅ | ✅ | ❌ |
| 删除文章 | ✅ | ❌ | ❌ |
| 用户管理 | ✅ | ❌ | ❌ |
| 系统设置 | ✅ | ❌ | ❌ |
| 数据分析 | ✅ | ✅ | ❌ |

### 用户操作

```bash
# 常见用户操作
- 重置密码
- 修改角色
- 暂停/激活账户
- 发送通知邮件
- 查看活动日志
```

## 分析和报告

### 流量分析

#### 访问统计

```typescript
// 关键指标
{
  page_views: number;        // 页面浏览量
  unique_visitors: number;   // 独立访客
  bounce_rate: number;       // 跳出率
  avg_session_duration: number; // 平均会话时长
  traffic_sources: {         // 流量来源
    direct: number;
    search: number;
    social: number;
    referral: number;
  }
}
```

#### 内容表现

- 最受欢迎的文章
- 搜索关键词排名
- 社交媒体分享数据
- 用户参与度指标

### SEO 报告

#### 搜索表现

```yaml
# SEO 关键指标
- 关键词排名变化
- 搜索点击率
- 搜索展示次数
- 平均排名位置
```

#### 技术 SEO

- 页面加载速度
- 移动端适配性
- 内部链接分析
- Meta 标签完整性

### 自定义报告

创建和导出自定义分析报告：

```typescript
// 报告配置
{
  name: "月度流量报告",
  date_range: "last_30_days",
  metrics: ["page_views", "unique_visitors", "conversion_rate"],
  filters: {
    source: "organic",
    device: "mobile"
  },
  export_format: "pdf" | "csv" | "xlsx"
}
```

## 系统设置

### 站点配置

#### 基础设置

```yaml
站点名称: "我的AI创业平台"
站点描述: "基于AI技术的创新创业平台"
主域名: "https://yourdomain.com"
联系邮箱: "contact@yourdomain.com"
时区: "Asia/Shanghai"
语言: "zh-CN"
```

#### SEO 设置

```yaml
默认标题模板: "{页面标题} | {站点名称}"
默认描述: "使用AI技术助力您的创业之路"
关键词: "AI, 创业, 科技, 创新"
社交图片: "/og-image.jpg"
Google Analytics: "G-XXXXXXXXXX"
Google Search Console: "已验证"
```

### 性能优化

#### 缓存设置

```typescript
// 缓存配置
{
  static_files: "7d",      // 静态文件缓存
  api_responses: "1h",     // API 响应缓存
  database_queries: "5m",  // 数据库查询缓存
  image_optimization: true, // 图片优化
  minification: true       // 代码压缩
}
```

#### CDN 配置

```yaml
CDN提供商: "Cloudflare"
图片CDN: "启用"
JS/CSS压缩: "启用"
Gzip压缩: "启用"
HTTP/2推送: "启用"
```

### 安全设置

#### 访问控制

```yaml
# 安全选项
双因素认证: "可选"
密码强度: "中等"
会话超时: "24小时"
登录尝试限制: "5次/小时"
IP白名单: "启用"
```

#### 数据备份

```bash
# 自动备份设置
数据库备份: "每日 03:00"
文件备份: "每周"
备份保留: "30天"
备份位置: "AWS S3"
```

## 通知和邮件

### 邮件模板

管理系统邮件模板：

```html
<!-- 欢迎邮件模板 -->
<h2>欢迎加入 {{site_name}}！</h2>
<p>感谢您注册我们的平台。</p>
<a href="{{verification_link}}">验证您的邮箱</a>
```

### 通知设置

```yaml
# 通知类型
新用户注册: "立即通知管理员"
新评论: "每小时汇总"
系统错误: "立即通知"
备份完成: "每日报告"
```

## 插件和扩展

### 已安装插件

查看和管理已安装的插件：

```typescript
// 插件列表示例
{
  name: "SEO优化器",
  version: "1.2.0",
  status: "active",
  description: "自动优化页面SEO",
  settings_url: "/admin/plugins/seo-optimizer"
}
```

### 插件市场

浏览和安装新插件：

- 分析工具插件
- 社交媒体集成
- 支付系统集成
- 客服聊天工具

## 故障排除

### 常见问题

#### 登录问题

```bash
# 问题：无法登录管理后台
# 解决方案：
1. 检查用户角色权限
2. 清除浏览器缓存
3. 验证邮箱地址
4. 重置密码
```

#### 性能问题

```bash
# 问题：后台加载缓慢
# 解决方案：
1. 检查数据库查询性能
2. 优化图片大小
3. 启用缓存
4. 检查服务器资源
```

#### 权限错误

```bash
# 问题：权限不足错误
# 解决方案：
1. 验证用户角色
2. 检查权限配置
3. 联系管理员
4. 查看错误日志
```

### 调试工具

内置调试功能：

```typescript
// 调试信息
{
  query_time: "125ms",
  memory_usage: "45MB",
  cache_hits: 23,
  cache_misses: 2,
  errors: []
}
```

## 高级功能

### API 管理

管理和监控 API 使用：

```typescript
// API 密钥管理
{
  key_name: "移动应用",
  permissions: ["read:posts", "write:comments"],
  rate_limit: "1000/hour",
  last_used: "2024-01-15T10:30:00Z"
}
```

### 数据导入/导出

```bash
# 支持的格式
导入: JSON, CSV, WordPress XML
导出: JSON, CSV, PDF报告
```

### 自动化工具

设置自动化任务：

```yaml
# 定时任务示例
发布定时文章: "每分钟检查"
清理临时文件: "每日 02:00"
生成SEO报告: "每周一 09:00"
数据库优化: "每月第一天"
```

## 下一步

掌握管理后台后，建议学习：
- [内容管理](./content-management.md) - 深入了解内容创建
- [博客管理](./blog-management.md) - 专业的博客运营
- [SEO优化](./seo-optimization.md) - 提升搜索排名
- [技术架构](../03-developer-guide/technical-architecture.md) - 了解系统架构