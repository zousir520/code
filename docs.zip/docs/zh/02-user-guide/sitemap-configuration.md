# Sitemap 配置指南

## 概述

本项目使用结构化的 sitemap 系统，将不同类型的内容组织到单独的 XML 文件中，以获得更好的 SEO 性能和更容易的维护。

## Sitemap 结构

### 主 Sitemap 索引 - `/sitemap-index.xml`
引用所有其他 sitemap 的主索引文件：

```xml
<?xml version="1.0" encoding="UTF-8"?>
<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <sitemap>
    <loc>https://vibby.ai/home-sitemap.xml</loc>
    <lastmod>2025-07-19</lastmod>
  </sitemap>
  <sitemap>
    <loc>https://vibby.ai/page-sitemap.xml</loc>
    <lastmod>2025-07-19</lastmod>
  </sitemap>
  <sitemap>
    <loc>https://vibby.ai/blog-sitemap.xml</loc>
    <lastmod>2025-07-19</lastmod>
  </sitemap>
</sitemapindex>
```

### 各个 Sitemap 文件

#### 1. 主页 Sitemap - `/home-sitemap.xml`
包含多语言主页 URL：
- 英文主页：`https://vibby.ai/`
- 中文主页：`https://vibby.ai/zh/`
- 优先级：1.0（最高）
- 更新频率：每周
- 包含多语言 SEO 的 hreflang 标签

#### 2. 页面 Sitemap - `/page-sitemap.xml`
包含所有静态页面和 CMS 页面（不包括主页）：
- 关于、联系、隐私、条款页面
- 中英文版本
- 优先级：0.6-0.8
- 更新频率：每月到每年
- 包含 hreflang 标签

#### 3. 博客 Sitemap - `/blog-sitemap.xml`
包含博客相关的 URL：
- 博客索引页面（`/blog`、`/zh/blog`）
- 所有博客文章的中英文 URL
- 优先级：0.7-0.9
- 更新频率：每日（索引），每月（文章）
- 使用文章发布日期作为 lastmod

### 向后兼容性
- `/sitemap.xml` 重定向到 `/sitemap-index.xml`（301 重定向）
- 与现有 SEO 工具和搜索引擎保持兼容

## 技术实现

### 文件结构
```
src/routes/
├── sitemap-index.xml/+server.ts    # 主 sitemap 索引
├── home-sitemap.xml/+server.ts     # 主页 sitemap
├── page-sitemap.xml/+server.ts     # 静态页面 sitemap
├── blog-sitemap.xml/+server.ts     # 博客 sitemap
└── sitemap.xml/+server.ts          # 重定向到索引
```

### 主要功能

#### 1. 动态内容生成
- 自动包含所有博客文章
- 动态获取 CMS 页面
- 自动更新 lastmod 日期

#### 2. 多语言支持
- 生成中英文 URL
- 包含正确的 hreflang 属性
- 遵循 Google 多语言 SEO 指南

#### 3. 错误处理
- 内容加载失败时的备用 sitemap
- 全面的错误日志记录
- 优雅降级

#### 4. 性能优化
- 缓存响应（1小时）
- 正确的 XML 格式
- 高效的内容生成

### 环境配置

sitemap 系统使用以下环境变量：
```env
PUBLIC_SITE_URL=https://vibby.ai
```

如果未设置，将回退到：
- 生产环境：`https://vibby.ai`
- 开发环境：`http://localhost:5173`

## SEO 优势

### 1. 更好的组织结构
- 搜索引擎可以高效抓取不同类型的内容
- 不同内容类型的独立更新频率
- 更清晰的内容分类

### 2. 多语言 SEO
- 正确的 hreflang 实现
- 特定语言的 URL 结构
- 改善国际搜索可见性

### 3. 性能
- 更小的单个 sitemap 文件
- 搜索引擎更快的解析速度
- 更好的缓存策略

### 4. 维护性
- 易于更新特定内容类型
- 清晰的关注点分离
- 便于调试的结构

## 使用方法

### 提交到搜索引擎

将主 sitemap 索引提交到搜索引擎：
```
https://vibby.ai/sitemap-index.xml
```

### Google Search Console
1. 进入 Google Search Console
2. 导航到 Sitemaps 部分
3. 添加：`sitemap-index.xml`

### Robots.txt 集成
sitemap 自动在 `/robots.txt` 中引用：
```
Sitemap: https://vibby.ai/sitemap-index.xml
```

## 监控和维护

### 定期检查
- 验证所有 sitemap URL 可访问
- 检查正确的 XML 格式
- 监控搜索引擎索引状态

### 内容更新
- 添加新文章时博客 sitemap 自动更新
- CMS 内容更改时页面 sitemap 更新
- 网站结构更改时主页 sitemap 更新

### 故障排除

#### 常见问题
1. **空 sitemap**：检查内容加载函数
2. **格式错误**：在浏览器中验证 XML 结构
3. **缺少页面**：检查内容过滤逻辑

#### 调试信息
通过检查 Vercel 函数日志启用调试日志记录：
- 内容加载状态
- 页面计数信息
- 错误消息

## 最佳实践

1. **定期监控**：每月检查 sitemap 可访问性
2. **内容验证**：确保 sitemap 中的所有 URL 有效
3. **性能**：监控 sitemap 加载时间
4. **SEO 影响**：跟踪搜索引擎索引改进情况

## 相关文档

- [CMS 认证指南](./cms-authentication-guide.md)
- [CMS 快速开始](./cms-quick-start.md)
- [多语言设置指南](./multilingual-setup.md)
