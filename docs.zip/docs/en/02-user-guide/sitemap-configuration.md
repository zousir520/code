# Sitemap Configuration Guide

## Overview

This project uses a structured sitemap system that organizes different types of content into separate XML files for better SEO performance and easier maintenance.

## Sitemap Structure

### Main Sitemap Index - `/sitemap-index.xml`
The master sitemap that references all other sitemaps:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <sitemap>
    <loc>https://vibby.ai/home-sitemap.xml</loc>
    <lastmod>2025-07-19</lastmod>
  </sitemap>
  <sitemap>
    <loc>https://vibby.ai/page-sitemap.xml</loc>
    <lastmod>2025-07-19</lastmod>
  </sitemap>
  <sitemap>
    <loc>https://vibby.ai/blog-sitemap.xml</loc>
    <lastmod>2025-07-19</lastmod>
  </sitemap>
</sitemapindex>
```

### Individual Sitemaps

#### 1. Home Sitemap - `/home-sitemap.xml`
Contains homepage URLs in multiple languages:
- English homepage: `https://vibby.ai/`
- Chinese homepage: `https://vibby.ai/zh/`
- Priority: 1.0 (highest)
- Change frequency: weekly
- Includes hreflang tags for multilingual SEO

#### 2. Page Sitemap - `/page-sitemap.xml`
Contains all static and CMS pages (excluding homepage):
- About, Contact, Privacy, Terms pages
- Both English and Chinese versions
- Priority: 0.6-0.8
- Change frequency: monthly to yearly
- Includes hreflang tags

#### 3. Blog Sitemap - `/blog-sitemap.xml`
Contains blog-related URLs:
- Blog index pages (`/blog`, `/zh/blog`)
- All blog post URLs in both languages
- Priority: 0.7-0.9
- Change frequency: daily (index), monthly (posts)
- Uses post publication date as lastmod

### Backward Compatibility
- `/sitemap.xml` redirects to `/sitemap-index.xml` (301 redirect)
- Maintains compatibility with existing SEO tools and search engines

## Technical Implementation

### File Structure
```
src/routes/
├── sitemap-index.xml/+server.ts    # Main sitemap index
├── home-sitemap.xml/+server.ts     # Homepage sitemap
├── page-sitemap.xml/+server.ts     # Static pages sitemap
├── blog-sitemap.xml/+server.ts     # Blog sitemap
└── sitemap.xml/+server.ts          # Redirect to index
```

### Key Features

#### 1. Dynamic Content Generation
- Automatically includes all blog posts
- Fetches CMS pages dynamically
- Updates lastmod dates automatically

#### 2. Multilingual Support
- Generates URLs for both English and Chinese
- Includes proper hreflang attributes
- Follows Google's multilingual SEO guidelines

#### 3. Error Handling
- Fallback sitemaps if content loading fails
- Comprehensive error logging
- Graceful degradation

#### 4. Performance Optimization
- Cached responses (1 hour)
- Proper XML formatting
- Efficient content generation

### Environment Configuration

The sitemap system uses the following environment variable:
```env
PUBLIC_SITE_URL=https://vibby.ai
```

If not set, it falls back to:
- Production: `https://vibby.ai`
- Development: `http://localhost:5173`

## SEO Benefits

### 1. Better Organization
- Search engines can crawl different content types efficiently
- Separate update frequencies for different content types
- Clearer content categorization

### 2. Multilingual SEO
- Proper hreflang implementation
- Language-specific URL structure
- Improved international search visibility

### 3. Performance
- Smaller individual sitemap files
- Faster parsing by search engines
- Better caching strategies

### 4. Maintenance
- Easy to update specific content types
- Clear separation of concerns
- Debugging-friendly structure

## Usage

### Submitting to Search Engines

Submit the main sitemap index to search engines:
```
https://vibby.ai/sitemap-index.xml
```

### Google Search Console
1. Go to Google Search Console
2. Navigate to Sitemaps section
3. Add: `sitemap-index.xml`

### Robots.txt Integration
The sitemap is automatically referenced in `/robots.txt`:
```
Sitemap: https://vibby.ai/sitemap-index.xml
```

## Monitoring and Maintenance

### Regular Checks
- Verify all sitemap URLs are accessible
- Check for proper XML formatting
- Monitor search engine indexing status

### Content Updates
- Blog sitemaps update automatically when new posts are added
- Page sitemaps update when CMS content changes
- Homepage sitemap updates with site structure changes

### Troubleshooting

#### Common Issues
1. **Empty sitemap**: Check content loading functions
2. **Format errors**: Verify XML structure in browser
3. **Missing pages**: Check content filtering logic

#### Debug Information
Enable debug logging by checking Vercel function logs for:
- Content loading status
- Page count information
- Error messages

## Best Practices

1. **Regular Monitoring**: Check sitemap accessibility monthly
2. **Content Validation**: Ensure all URLs in sitemaps are valid
3. **Performance**: Monitor sitemap loading times
4. **SEO Impact**: Track search engine indexing improvements

## Related Documentation

- [CMS Authentication Guide](./cms-authentication-guide.md)
- [CMS Quick Start](./cms-quick-start.md)
- [Multilingual Setup Guide](./multilingual-setup.md)
