# Content Management Guide

Master **Vibby.ai's** powerful content management system. This guide covers everything from basic content editing to advanced content strategies.

## 📝 Content Management Overview

Vibby.ai uses a **file-based CMS** approach with **Sveltia CMS** interface, providing:

- **File-based Storage** - Content stored as files in your repository
- **Git Integration** - Version control for all content changes
- **Visual Editor** - User-friendly interface for non-technical users
- **Markdown Support** - Rich text editing with markdown
- **Media Management** - Image and file uploads
- **Multilingual Support** - Content in multiple languages

## 🎛️ Accessing the CMS

### CMS Interface

1. **Navigate to Admin**: Go to `/vibbyai` in your browser
2. **Access CMS**: Click "Content Management" or go to `/vibbyai/cms`
3. **Login** (if required): Use your admin credentials

### CMS Dashboard Overview

```
┌─────────────────────────────────────────┐
│ 📊 Sveltia CMS Dashboard                │
├─────────────────────────────────────────┤
│ 📄 Collections:                        │
│   • Blog Posts                         │
│   • Pages                              │
│   • Homepage Content                   │
│   • Navigation                         │
│   • Site Settings                      │
│                                         │
│ 📁 Media Library                       │
│ ⚙️ Workflow                           │
│ 👤 Identity                           │
└─────────────────────────────────────────┘
```

## 📄 Content Types

### 1. Blog Posts

**Location**: `src/content/blog/`

#### Creating a New Blog Post

1. **Open CMS**: Navigate to `/vibbyai/cms`
2. **Select Collection**: Click "Blog Posts"
3. **Create New**: Click "New Blog Post"
4. **Fill Details**:
   - **Title**: Your post title
   - **Slug**: URL-friendly version (auto-generated)
   - **Date**: Publication date
   - **Author**: Post author
   - **Content**: Main post content (Markdown)
   - **Excerpt**: Brief description
   - **Featured Image**: Optional hero image
   - **Tags**: Comma-separated tags
   - **SEO Settings**: Meta description, keywords

#### Blog Post Structure

```markdown
---
title: "Your Amazing Blog Post"
slug: "your-amazing-blog-post"
date: "2024-01-15"
author: "Your Name"
excerpt: "A brief description of your post"
image: "/images/blog/your-post-image.jpg"
tags: ["AI", "Startup", "Technology"]
published: true
---

# Your Blog Post Content

Write your content here using **Markdown** formatting.

## Subheadings

- Bullet points
- **Bold text**
- *Italic text*
- [Links](https://example.com)

### Code Examples

\`\`\`javascript
console.log("Hello, World!");
\`\`\`

![Image](/images/example.jpg)
```

#### Blog Post SEO

**Automatic SEO Features**:
- Auto-generated meta descriptions
- Open Graph tags
- Twitter cards
- JSON-LD structured data
- Sitemap inclusion

**Manual SEO Settings**:
```yaml
seo:
  title: "Custom SEO Title"
  description: "Custom meta description"
  keywords: "keyword1, keyword2, keyword3"
  ogImage: "/images/custom-og-image.jpg"
```

### 2. Static Pages

**Location**: `src/content/pages/`

#### Creating Static Pages

1. **Access Pages Collection**: In CMS, select "Pages"
2. **Create New Page**: Click "New Page"
3. **Page Configuration**:
   - **Title**: Page title
   - **Slug**: URL path
   - **Content**: Page content
   - **Template**: Page layout
   - **Meta Settings**: SEO configuration

#### Page Templates

Available page templates:
- **Default**: Standard page layout
- **Landing**: Marketing landing page
- **Contact**: Contact form page
- **About**: About page with team section
- **Pricing**: Pricing table page

### 3. Homepage Content

**Location**: `src/content/home/`

#### Homepage Sections

##### Hero Section (`hero.json`)
```json
{
  "title": "Build Your AI Startup Fast",
  "subtitle": "Everything you need to launch your AI startup",
  "description": "Get CMS, blog, admin dashboard, and more",
  "cta": {
    "primary": {
      "label": "Get Started",
      "url": "/signup"
    },
    "secondary": {
      "label": "Learn More",
      "url": "/about"
    }
  },
  "image": "/images/hero-image.jpg",
  "features": [
    "🚀 Quick Setup",
    "🎨 Beautiful Design", 
    "🔧 Easy Customization"
  ]
}
```

##### Features Section (`features.json`)
```json
{
  "title": "Powerful Features",
  "subtitle": "Everything you need in one platform",
  "features": [
    {
      "icon": "⚡",
      "title": "Lightning Fast",
      "description": "Built with SvelteKit for optimal performance",
      "link": "/features/performance"
    },
    {
      "icon": "🎨", 
      "title": "Beautiful Design",
      "description": "Modern, responsive design out of the box",
      "link": "/features/design"
    }
  ]
}
```

##### FAQ Section (`faq.json`)
```json
{
  "title": "Frequently Asked Questions",
  "faqs": [
    {
      "question": "How quickly can I get started?",
      "answer": "You can have your site running in under 5 minutes with our quick start guide."
    },
    {
      "question": "Do I need coding experience?",
      "answer": "No! Our CMS interface allows you to manage content without any coding knowledge."
    }
  ]
}
```

### 4. Navigation Management

**Location**: `src/content/home/navigation.json`

#### Header Navigation
```json
{
  "header": {
    "logo": {
      "text": "Vibby.ai",
      "image": "/images/logo.svg"
    },
    "menu": [
      {
        "label": "Home",
        "url": "/",
        "children": []
      },
      {
        "label": "Products",
        "url": "/products",
        "children": [
          {
            "label": "AI Tools",
            "url": "/products/ai-tools"
          },
          {
            "label": "Analytics",
            "url": "/products/analytics"
          }
        ]
      }
    ]
  }
}
```

#### Footer Navigation
```json
{
  "footer": {
    "sections": [
      {
        "title": "Product",
        "links": [
          { "label": "Features", "url": "/features" },
          { "label": "Pricing", "url": "/pricing" }
        ]
      }
    ],
    "social": [
      {
        "platform": "twitter",
        "url": "https://twitter.com/yourhandle",
        "icon": "twitter"
      }
    ]
  }
}
```

## 🌍 Multilingual Content

### Language Structure

```
src/content/
├── blog/
│   ├── 2024-01-15-post-title.md        # English (default)
│   └── 2024-01-15-post-title.zh.md     # Chinese
├── pages/
│   ├── about.md                        # English
│   └── about.zh.md                     # Chinese
└── home/
    ├── hero.json                       # English
    └── hero.zh.json                    # Chinese
```

### Creating Multilingual Content

#### Method 1: Language Suffix
```
post-title.md      # English version
post-title.zh.md   # Chinese version
```

#### Method 2: Language Directories
```
en/
  ├── blog/
  └── pages/
zh/
  ├── blog/
  └── pages/
```

#### Language Configuration

In your content frontmatter:
```yaml
---
title: "English Title"
lang: "en"
translations:
  zh: "chinese-title-slug"
---
```

### Language Switching

The system automatically:
- Detects user language preference
- Shows appropriate content version
- Provides language switcher in navigation
- Falls back to default language if translation unavailable

## 📁 Media Management

### Uploading Media

1. **Access Media Library**: In CMS, click "Media"
2. **Upload Files**: Drag and drop or click to browse
3. **Organize**: Create folders and organize files
4. **Insert**: Use media in your content

### Media Organization

```
static/uploads/
├── images/
│   ├── blog/
│   ├── pages/
│   └── gallery/
├── documents/
└── downloads/
```

### Image Optimization

**Automatic Optimizations**:
- WebP conversion for supported browsers
- Responsive image sizing
- Lazy loading
- Alt text requirements

**Manual Optimization**:
```markdown
![Alt text](/images/example.jpg)

<!-- With custom sizing -->
<img src="/images/example.jpg" alt="Alt text" width="800" height="600" />

<!-- Responsive image -->
<picture>
  <source srcset="/images/example.webp" type="image/webp">
  <img src="/images/example.jpg" alt="Alt text">
</picture>
```

## 🔧 Advanced Content Features

### Custom Fields

Add custom fields to collections in `static/admin/config.yml`:

```yaml
collections:
  - name: "blog"
    fields:
      - { label: "Title", name: "title", widget: "string" }
      - { label: "Custom Field", name: "customField", widget: "text" }
      - {
          label: "Featured",
          name: "featured",
          widget: "boolean",
          default: false
        }
      - {
          label: "Category",
          name: "category",
          widget: "select",
          options: ["Technology", "Business", "Design"]
        }
```

### Content Relationships

Link related content:

```yaml
# In blog post frontmatter
related_posts:
  - "slug-of-related-post-1"
  - "slug-of-related-post-2"

# In page frontmatter
featured_products:
  - "product-1"
  - "product-2"
```

### Content Scheduling

Schedule content publication:

```yaml
---
title: "Future Post"
date: "2024-06-01"  # Future date
published: false    # Manual control
scheduledFor: "2024-06-01T09:00:00Z"
---
```

### Dynamic Content

Use variables in content:

```markdown
Welcome to {{site.name}}! 

Contact us at {{site.contact.email}}.

Current year: {{date.year}}
```

## 📊 Content Analytics

### Built-in Analytics

Track content performance:
- Page views
- Reading time
- Popular content
- Search queries
- User engagement

### Content Insights

Access in admin dashboard:
- Most viewed posts
- Content engagement metrics
- SEO performance
- Search ranking positions

## 🔍 Content SEO

### Automatic SEO Features

**Generated Automatically**:
- Meta titles and descriptions
- Open Graph tags
- Twitter cards
- JSON-LD structured data
- XML sitemaps
- Robots.txt

### SEO Best Practices

#### Content Optimization
- **Title Length**: 50-60 characters
- **Meta Description**: 150-160 characters
- **Heading Structure**: Proper H1, H2, H3 hierarchy
- **Image Alt Text**: Descriptive alt attributes
- **Internal Linking**: Link to related content

#### Technical SEO
```markdown
---
title: "SEO-Optimized Title"
description: "Compelling meta description under 160 characters"
keywords: "primary keyword, secondary keyword"
canonical: "https://yourdomain.com/canonical-url"
robots: "index, follow"
---
```

## 🚀 Content Workflow

### Editorial Workflow

1. **Draft**: Create and edit content
2. **Review**: Internal review process
3. **Approval**: Final approval
4. **Publish**: Content goes live
5. **Update**: Regular content updates

### Version Control

All content changes are tracked:
- **Git History**: Full version history
- **Change Tracking**: See who changed what
- **Rollback**: Revert to previous versions
- **Branching**: Work on content in branches

### Content Backup

**Automatic Backups**:
- Git repository backup
- Media file backup
- Database backup (if using)

**Manual Backup**:
```bash
# Backup content
git add .
git commit -m "Content backup"
git push origin main

# Backup media
rsync -av static/uploads/ backup/uploads/
```

## 🆘 Content Troubleshooting

### Common Issues

#### Content Not Showing
- Check file naming conventions
- Verify frontmatter syntax
- Ensure published: true
- Check file permissions

#### Images Not Loading
- Verify file paths
- Check image file sizes
- Ensure proper upload location
- Validate image formats

#### CMS Access Issues
- Clear browser cache
- Check admin credentials
- Verify CMS configuration
- Check network connectivity

### Getting Help

- **Documentation**: [Troubleshooting Guide](../06-troubleshooting/common-issues.md)
- **Community**: [Content Management Discussions](https://github.com/gstarwd/vibby.ai/discussions)
- **Support**: [Report Content Issue](https://github.com/gstarwd/vibby.ai/issues/new)

---

**Content Management Mastered!** 🎉  
**Next Steps**: [Learn blog management](./blog-management.md) or [explore the admin dashboard](./admin-dashboard.md)