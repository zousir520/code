# Complete Installation Guide

This comprehensive guide covers everything you need to install and configure **Vibby.ai** for development and production environments.

## 📋 System Requirements

### Minimum Requirements
- **Node.js**: 18.0 or higher
- **Memory**: 2GB RAM available
- **Storage**: 1GB free disk space
- **OS**: Windows 10+, macOS 10.15+, or Linux

### Recommended Requirements
- **Node.js**: 20.0 or higher
- **Memory**: 4GB RAM available
- **Storage**: 5GB free disk space
- **Package Manager**: pnpm (faster than npm)

### Development Tools
- **Git**: For version control
- **VS Code**: Recommended editor with Svelte extension
- **Modern Browser**: Chrome, Firefox, Safari, or Edge

## 🛠️ Installation Methods

### Method 1: Standard Installation (Recommended)

#### Step 1: Clone Repository
```bash
# Clone the official repository
git clone https://github.com/gstarwd/vibby.ai.git
cd vibby.ai

# Or clone your fork
git clone https://github.com/YOUR_USERNAME/vibby.ai.git
cd vibby.ai
```

#### Step 2: Install Dependencies
```bash
# Using pnpm (recommended - faster)
pnpm install

# Or using npm
npm install

# Or using yarn
yarn install
```

#### Step 3: Environment Setup
```bash
# Copy environment template
cp .env.example .env

# Edit environment variables (optional for basic setup)
nano .env  # or use your preferred editor
```

#### Step 4: Start Development Server
```bash
# Start the development server
pnpm dev

# Server will start at http://localhost:5173
```

### Method 2: One-Command Setup

For the fastest setup experience:

```bash
# Clone, install, and start in one command
git clone https://github.com/gstarwd/vibby.ai.git && cd vibby.ai && pnpm install && pnpm dev
```

### Method 3: Docker Setup (Optional)

```bash
# Using Docker Compose
docker-compose up -d

# Or build manually
docker build -t vibby-ai .
docker run -p 5173:5173 vibby-ai
```

## ⚙️ Configuration Options

### Basic Configuration

The system works out-of-the-box with default settings. For customization:

#### Environment Variables
```bash
# Basic Configuration
NODE_ENV=development
PUBLIC_SITE_URL=http://localhost:5173

# Optional: Database (Supabase)
PUBLIC_SUPABASE_URL=your-supabase-url
PUBLIC_SUPABASE_ANON_KEY=your-supabase-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-supabase-service-key

# Optional: Email Services
SMTP_HOST=your-smtp-host
SMTP_USER=your-smtp-user
SMTP_PASS=your-smtp-password

# Security (Auto-generated if not provided)
ENCRYPTION_SECRET=your-48-character-secret-key
```

### Site Configuration

Edit `src/content/site-config.json`:
```json
{
  "siteName": "Your AI Startup",
  "siteDescription": "Building the future with AI",
  "siteUrl": "https://yourdomain.com",
  "language": "en",
  "theme": "light",
  "features": {
    "blog": true,
    "multilingual": true,
    "analytics": false
  }
}
```

## 🔧 Development Setup

### IDE Configuration

#### VS Code Setup
Install recommended extensions:
```bash
# Install VS Code extensions
code --install-extension svelte.svelte-vscode
code --install-extension bradlc.vscode-tailwindcss
code --install-extension ms-vscode.vscode-typescript-next
```

#### VS Code Settings (`.vscode/settings.json`)
```json
{
  "typescript.preferences.importModuleSpecifier": "relative",
  "typescript.suggest.includeCompletionsForImportStatements": true,
  "svelte.enable-ts-plugin": true,
  "tailwindCSS.includeLanguages": {
    "svelte": "html"
  }
}
```

### Git Configuration

#### Pre-commit Hooks
```bash
# Install pre-commit hooks
pnpm add -D husky lint-staged

# Setup husky
npx husky install
```

#### Git Ignore
Key patterns already included in `.gitignore`:
```
node_modules/
.env
.env.local
.vercel/
build/
dist/
.svelte-kit/
```

## 🔐 Security Setup

### Automatic Security

The system automatically generates secure defaults:

- **Encryption Keys**: Auto-generated 48-character secrets
- **Session Security**: Secure cookie settings
- **CSP Headers**: Content Security Policy protection
- **HTTPS Redirect**: Automatic in production

### Manual Security Configuration

```bash
# Generate secure encryption key
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"

# Add to .env
ENCRYPTION_SECRET=your-generated-key
```

## 📂 Project Structure

After installation, your project structure:

```
vibby.ai/
├── 📁 src/
│   ├── 📁 routes/           # SvelteKit routes
│   ├── 📁 lib/              # Components and utilities
│   ├── 📁 content/          # CMS content files
│   └── 📄 app.html          # HTML template
├── 📁 static/               # Static assets
├── 📁 docs/                 # Documentation
├── 📄 package.json          # Dependencies
├── 📄 svelte.config.js      # Svelte configuration
├── 📄 tailwind.config.js    # Tailwind CSS config
└── 📄 tsconfig.json         # TypeScript config
```

## 🧪 Verification & Testing

### Basic Functionality Test

```bash
# Check if server starts
pnpm dev

# Test build process
pnpm build

# Test build output
pnpm preview

# Run type checking
pnpm check
```

### Access Testing

Verify these URLs work:

- **Homepage**: `http://localhost:5173`
- **Admin Dashboard**: `http://localhost:5173/vibbyai`
- **CMS Interface**: `http://localhost:5173/vibbyai/cms`
- **Blog**: `http://localhost:5173/blog`
- **API Health**: `http://localhost:5173/api/ping`

### Console Verification

Check browser console (F12) for:
- ✅ No JavaScript errors
- ✅ No network failures
- ✅ Proper page loading

## 🚀 Production Preparation

### Build Optimization

```bash
# Create production build
pnpm build

# Test production build locally
pnpm preview

# Analyze bundle size
pnpm exec vite build --analyze
```

### Environment Variables for Production

```bash
# Production Environment
NODE_ENV=production
PUBLIC_SITE_URL=https://yourdomain.com

# Database Configuration
PUBLIC_SUPABASE_URL=your-production-supabase-url
PUBLIC_SUPABASE_ANON_KEY=your-production-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-production-service-key

# Email Configuration
SMTP_HOST=your-production-smtp
SMTP_USER=your-production-email
SMTP_PASS=your-production-password

# Security
ENCRYPTION_SECRET=your-secure-production-key
```

## 🆘 Troubleshooting Installation

### Common Issues

#### Node.js Version Conflicts
```bash
# Check Node.js version
node --version

# Using nvm to switch versions
nvm install 18
nvm use 18
```

#### Port Already in Use
```bash
# Find process using port 5173
lsof -i :5173

# Kill the process
kill -9 PID

# Or use different port
pnpm dev --port 3000
```

#### Permission Errors
```bash
# Fix npm permissions (Unix/Linux)
sudo chown -R $(whoami) ~/.npm

# Clear npm cache
npm cache clean --force
```

#### Memory Issues
```bash
# Increase Node.js memory limit
export NODE_OPTIONS="--max-old-space-size=4096"
pnpm dev
```

### Platform-Specific Issues

#### Windows
```cmd
# Use Windows PowerShell or Command Prompt
# Ensure Git Bash is available for Unix-style commands

# If facing path issues:
set PATH=%PATH%;C:\Program Files\nodejs\
```

#### macOS
```bash
# Install Xcode Command Line Tools if needed
xcode-select --install

# Install Homebrew if needed
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
```

#### Linux
```bash
# Ubuntu/Debian: Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Fedora: Install Node.js
sudo dnf install nodejs pnpm
```

## 📚 Next Steps

After successful installation:

### For Immediate Use
➡️ **[Quick Start Guide](./quick-start.md)** - Get running in 5 minutes

### For Configuration
➡️ **[Configuration Guide](./configuration.md)** - Detailed setup options

### For Development
➡️ **[Technical Architecture](../03-developer-guide/technical-architecture.md)** - Understand the system

### For Production
➡️ **[Deployment Guide](../04-deployment/deployment-guide.md)** - Deploy to production

## 📞 Support

If you encounter issues during installation:

- **Check**: [Common Issues](../06-troubleshooting/common-issues.md)
- **Search**: [GitHub Issues](https://github.com/gstarwd/vibby.ai/issues)
- **Ask**: [Community Discussions](https://github.com/gstarwd/vibby.ai/discussions)
- **Report**: [New Issue](https://github.com/gstarwd/vibby.ai/issues/new)

---

**Installation Complete!** 🎉  
**Next**: [Configure your system](./configuration.md) or [start customizing](../02-user-guide/content-management.md)