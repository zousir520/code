# Quick Start Guide

Get **Vibby.ai** up and running in just **5 minutes**! This guide will have you viewing your first AI startup platform in no time.

## ⚡ Prerequisites Check

Before starting, ensure you have:

- **Node.js 18+** or **pnpm** installed
- **Git** for cloning the repository
- **5 minutes** of your time

## 🚀 Lightning Setup

### Step 1: Clone and Install (2 minutes)

```bash
# Clone the repository
git clone https://github.com/gstarwd/vibby.ai.git
cd vibby.ai

# Install dependencies (this is fast!)
pnpm install

# Start development server
pnpm dev
```

### Step 2: Open Your Site (30 seconds)

Open your browser and navigate to:
```
http://localhost:5173
```

🎉 **Congratulations!** You should see your Vibby.ai homepage.

### Step 3: Access Admin Dashboard (30 seconds)

Visit the admin interface:
```
http://localhost:5173/vibbyai
```

### Step 4: Quick Configuration (2 minutes)

1. **Visit Setup Wizard**: `http://localhost:5173/vibbyai/init`
2. **Basic Settings**: Enter your site name and URL
3. **Skip Optional**: Skip database/email setup for now
4. **Complete Setup**: Click "Finish Setup"

## ✅ Verification Checklist

After setup, verify these work:

- [ ] **Homepage** loads at `http://localhost:5173`
- [ ] **Admin Dashboard** accessible at `/vibbyai`
- [ ] **Blog Section** displays sample posts
- [ ] **CMS Interface** loads at `/vibbyai/cms`

## 🎯 What You Just Created

Your Vibby.ai installation includes:

### 🏠 **Frontend Features**
- **Dynamic Homepage** with customizable sections
- **Blog System** with markdown support
- **Multilingual Support** (English/Chinese)
- **SEO Optimization** built-in

### 🛠️ **Admin Features**
- **Admin Dashboard** at `/vibbyai`
- **Content Management** via Sveltia CMS
- **Configuration Wizard** for easy setup
- **Environment Management** tools

### 🔧 **Technical Stack**
- **SvelteKit** - Modern web framework
- **TypeScript** - Type-safe development
- **TailwindCSS** - Utility-first styling
- **File-based CMS** - No database required for content

## 🎉 Success! What's Next?

### For Content Creators
➡️ **[Content Management Guide](../02-user-guide/content-management.md)** - Learn to edit your content

### For Developers
➡️ **[Technical Architecture](../03-developer-guide/technical-architecture.md)** - Understand the system

### For Production Deployment
➡️ **[Deployment Guide](../04-deployment/deployment-guide.md)** - Deploy to the web

### For Complete Setup
➡️ **[Installation Guide](./installation.md)** - Full configuration options

## 🔧 Quick Customization

### Change Site Title
Edit `src/content/site-config.json`:
```json
{
  "siteName": "Your Amazing AI Startup",
  "siteDescription": "Building the future with AI"
}
```

### Update Homepage Hero
Edit `src/content/home/hero.json`:
```json
{
  "title": "Welcome to Your AI Startup",
  "subtitle": "Transform your ideas into reality"
}
```

### Add Your First Blog Post
1. Go to `/vibbyai/cms`
2. Click "New Post"
3. Write your content
4. Publish!

## 🆘 Quick Troubleshooting

### Port Already in Use?
```bash
# Try a different port
pnpm dev --port 3000
```

### Installation Issues?
```bash
# Clear cache and reinstall
rm -rf node_modules pnpm-lock.yaml
pnpm install
```

### Admin Page Not Loading?
- Check console for errors: `F12 → Console`
- Ensure development server is running
- Try refreshing the page

## 📞 Need Help?

- **Common Issues**: [Troubleshooting Guide](../06-troubleshooting/common-issues.md)
- **Detailed Setup**: [Installation Guide](./installation.md)
- **Community**: [GitHub Discussions](https://github.com/gstarwd/vibby.ai/discussions)

---

**⚡ Total Time**: ~5 minutes  
**✅ Result**: Fully functional Vibby.ai platform  
**🎯 Next Step**: [Explore your admin dashboard](../02-user-guide/admin-dashboard.md)