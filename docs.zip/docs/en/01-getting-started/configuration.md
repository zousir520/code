# Configuration Guide

Configure **Vibby.ai** to match your specific needs. This guide covers all configuration options from basic setup to advanced customization.

## 🎯 Configuration Overview

Vibby.ai uses a layered configuration system:

1. **Environment Variables** - System-level settings
2. **Site Configuration** - Content and appearance
3. **Content Configuration** - Page-specific settings
4. **Runtime Configuration** - Dynamic settings via admin

## 🔧 Environment Configuration

### Basic Environment Setup

Create or edit your `.env` file:

```bash
# Copy the example file
cp .env.example .env

# Edit with your preferred editor
nano .env
```

### Essential Environment Variables

```bash
# === BASIC CONFIGURATION ===
NODE_ENV=development                    # development | production
PUBLIC_SITE_URL=http://localhost:5173   # Your site URL

# === DATABASE (OPTIONAL) ===
PUBLIC_SUPABASE_URL=                    # Supabase project URL
PUBLIC_SUPABASE_ANON_KEY=              # Supabase anonymous key
SUPABASE_SERVICE_ROLE_KEY=             # Supabase service role key

# === EMAIL SERVICES (OPTIONAL) ===
SMTP_HOST=                             # SMTP server host
SMTP_PORT=587                          # SMTP port (usually 587)
SMTP_USER=                             # SMTP username
SMTP_PASS=                             # SMTP password
SMTP_FROM=noreply@yourdomain.com       # From email address

# === SECURITY ===
ENCRYPTION_SECRET=                     # 48-character secret (auto-generated)

# === ANALYTICS (OPTIONAL) ===
PUBLIC_CLARITY_PROJECT_ID=             # Microsoft Clarity project ID
PUBLIC_GA_MEASUREMENT_ID=              # Google Analytics measurement ID
```

### Environment-Specific Configurations

#### Development Environment
```bash
NODE_ENV=development
PUBLIC_SITE_URL=http://localhost:5173
DEBUG=true
LOG_LEVEL=debug
```

#### Production Environment
```bash
NODE_ENV=production
PUBLIC_SITE_URL=https://yourdomain.com
DEBUG=false
LOG_LEVEL=info
```

#### Staging Environment
```bash
NODE_ENV=staging
PUBLIC_SITE_URL=https://staging.yourdomain.com
DEBUG=true
LOG_LEVEL=warn
```

## ⚙️ Site Configuration

### Main Site Configuration

Edit `src/content/site-config.json`:

```json
{
  "siteName": "Your AI Startup",
  "siteDescription": "Building the future with AI technology",
  "siteUrl": "https://yourdomain.com",
  "defaultLanguage": "en",
  "supportedLanguages": ["en", "zh"],
  "theme": {
    "defaultMode": "light",
    "allowDarkMode": true,
    "primaryColor": "#3b82f6",
    "accentColor": "#10b981"
  },
  "features": {
    "blog": true,
    "multilingual": true,
    "analytics": true,
    "comments": false,
    "newsletter": false,
    "search": true
  },
  "seo": {
    "enableSitemap": true,
    "enableRobots": true,
    "enableStructuredData": true,
    "defaultOgImage": "/images/og-default.jpg"
  },
  "contact": {
    "email": "contact@yourdomain.com",
    "phone": "+1-555-0123",
    "address": "123 AI Street, Tech City, TC 12345"
  },
  "social": {
    "twitter": "https://twitter.com/yourhandle",
    "linkedin": "https://linkedin.com/company/yourcompany",
    "github": "https://github.com/yourusername"
  }
}
```

### Navigation Configuration

Edit `src/content/home/navigation.json`:

```json
{
  "header": {
    "logo": {
      "text": "Vibby.ai",
      "image": "/images/logo.svg",
      "url": "/"
    },
    "menu": [
      {
        "label": "Home",
        "url": "/",
        "active": true
      },
      {
        "label": "About",
        "url": "/about"
      },
      {
        "label": "Blog",
        "url": "/blog"
      },
      {
        "label": "Contact",
        "url": "/contact"
      }
    ],
    "cta": {
      "label": "Get Started",
      "url": "/signup",
      "style": "primary"
    }
  },
  "footer": {
    "sections": [
      {
        "title": "Product",
        "links": [
          { "label": "Features", "url": "/features" },
          { "label": "Pricing", "url": "/pricing" },
          { "label": "API", "url": "/api" }
        ]
      },
      {
        "title": "Company",
        "links": [
          { "label": "About", "url": "/about" },
          { "label": "Blog", "url": "/blog" },
          { "label": "Careers", "url": "/careers" }
        ]
      },
      {
        "title": "Support",
        "links": [
          { "label": "Documentation", "url": "/docs" },
          { "label": "Help Center", "url": "/help" },
          { "label": "Contact", "url": "/contact" }
        ]
      }
    ]
  }
}
```

## 🏠 Homepage Configuration

### Hero Section

Edit `src/content/home/hero.json`:

```json
{
  "title": "Build Your AI Startup in Minutes",
  "subtitle": "The fastest way to launch your AI-powered startup with our comprehensive SvelteKit platform",
  "description": "Get everything you need: CMS, blog, admin dashboard, and more - all optimized for AI startups.",
  "cta": {
    "primary": {
      "label": "Start Building",
      "url": "/signup"
    },
    "secondary": {
      "label": "View Demo",
      "url": "/demo"
    }
  },
  "features": [
    "🚀 Quick Setup",
    "🎨 Beautiful Design",
    "🔧 Easy Customization"
  ],
  "image": {
    "src": "/images/hero-dashboard.jpg",
    "alt": "Vibby.ai Dashboard Preview"
  }
}
```

### Features Section

Edit `src/content/home/features.json`:

```json
{
  "title": "Everything You Need",
  "subtitle": "Built for AI startups who want to focus on their product",
  "features": [
    {
      "icon": "⚡",
      "title": "Lightning Fast",
      "description": "Built with SvelteKit for optimal performance and user experience",
      "details": ["Server-side rendering", "Optimal bundling", "Fast navigation"]
    },
    {
      "icon": "🎨",
      "title": "Beautiful Design",
      "description": "Modern, responsive design that looks great on all devices",
      "details": ["Mobile-first", "Dark mode", "Accessible"]
    },
    {
      "icon": "🔧",
      "title": "Easy to Customize",
      "description": "Modify colors, fonts, layout, and functionality with ease",
      "details": ["Theme system", "Component library", "Plugin architecture"]
    }
  ]
}
```

## 📝 Content Configuration

### Blog Configuration

Edit `src/content/blog/config.json`:

```json
{
  "postsPerPage": 10,
  "enableComments": false,
  "enableSearch": true,
  "enableCategories": true,
  "enableTags": true,
  "enableReadingTime": true,
  "enableTableOfContents": true,
  "defaultAuthor": {
    "name": "Your Name",
    "bio": "AI Startup Founder",
    "avatar": "/images/authors/default.jpg",
    "social": {
      "twitter": "@yourhandle",
      "linkedin": "yourprofile"
    }
  },
  "seo": {
    "enableOpenGraph": true,
    "enableTwitterCards": true,
    "defaultImage": "/images/blog-default.jpg"
  }
}
```

### Multilingual Configuration

Edit language-specific content:

```bash
# English content
src/content/en/

# Chinese content  
src/content/zh/
```

## 🔐 Security Configuration

### Authentication Setup

```bash
# Generate secure encryption key
ENCRYPTION_SECRET=$(node -e "console.log(require('crypto').randomBytes(32).toString('hex'))")
echo "ENCRYPTION_SECRET=$ENCRYPTION_SECRET" >> .env
```

### Supabase Database Setup

If using Supabase for user management:

```bash
# 1. Create Supabase project at https://supabase.com
# 2. Get your project URL and keys
# 3. Add to .env:
PUBLIC_SUPABASE_URL=https://your-project.supabase.co
PUBLIC_SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-key

# 4. Run database migrations
pnpm run db:migrate
```

### Email Service Setup

#### Using Gmail SMTP
```bash
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password  # Use app password, not regular password
```

#### Using SendGrid
```bash
SMTP_HOST=smtp.sendgrid.net
SMTP_PORT=587
SMTP_USER=apikey
SMTP_PASS=your-sendgrid-api-key
```

## 📊 Analytics Configuration

### Microsoft Clarity

```bash
# Get project ID from https://clarity.microsoft.com
PUBLIC_CLARITY_PROJECT_ID=your-project-id
```

### Google Analytics

```bash
# Get measurement ID from Google Analytics
PUBLIC_GA_MEASUREMENT_ID=G-XXXXXXXXXX
```

## 🎨 Theme Configuration

### Custom Color Scheme

Edit `tailwind.config.js`:

```javascript
module.exports = {
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#eff6ff',
          500: '#3b82f6',
          900: '#1e3a8a'
        },
        accent: {
          50: '#ecfdf5',
          500: '#10b981',
          900: '#064e3b'
        }
      }
    }
  }
}
```

### Custom Fonts

Add to `app.css`:

```css
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');

:root {
  --font-family: 'Inter', sans-serif;
}
```

## 🔧 Advanced Configuration

### Plugin Configuration

Enable/disable plugins in `src/lib/plugins/index.ts`:

```typescript
export const PLUGIN_CONFIG = {
  gamePlugin: {
    enabled: true,
    settings: {
      showRecommendations: true,
      maxRecommendations: 5
    }
  },
  analyticsPlugin: {
    enabled: true,
    settings: {
      trackPageViews: true,
      trackEvents: true
    }
  }
}
```

### API Configuration

Configure API endpoints in `src/lib/config/api-providers.ts`:

```typescript
export const API_CONFIG = {
  baseUrl: process.env.PUBLIC_SITE_URL,
  timeout: 10000,
  retries: 3,
  endpoints: {
    auth: '/api/auth',
    content: '/api/content',
    admin: '/api/admin'
  }
}
```

## ✅ Configuration Validation

### Environment Validation Script

Create `scripts/validate-config.js`:

```javascript
const requiredEnvVars = [
  'NODE_ENV',
  'PUBLIC_SITE_URL'
];

const optionalEnvVars = [
  'PUBLIC_SUPABASE_URL',
  'SMTP_HOST',
  'PUBLIC_CLARITY_PROJECT_ID'
];

// Validation logic
requiredEnvVars.forEach(envVar => {
  if (!process.env[envVar]) {
    console.error(`❌ Missing required environment variable: ${envVar}`);
    process.exit(1);
  }
});

console.log('✅ Configuration validation passed');
```

Run validation:
```bash
node scripts/validate-config.js
```

### Configuration Test

```bash
# Test configuration
pnpm run config:test

# Validate environment
pnpm run env:validate

# Check all systems
pnpm run health:check
```

## 🚀 Production Configuration

### Production Checklist

- [ ] Set `NODE_ENV=production`
- [ ] Configure production site URL
- [ ] Set up production database
- [ ] Configure email service
- [ ] Enable analytics
- [ ] Set secure encryption keys
- [ ] Configure CDN (optional)
- [ ] Set up monitoring
- [ ] Configure backup system

### Performance Configuration

```bash
# Production optimizations
PUBLIC_SITE_URL=https://yourdomain.com
NODE_ENV=production
ENABLE_COMPRESSION=true
ENABLE_CACHING=true
CDN_URL=https://cdn.yourdomain.com
```

## 📞 Configuration Help

### Common Configuration Issues

- **Environment variables not loading**: Check `.env` file location and syntax
- **Database connection fails**: Verify Supabase credentials and network access
- **Email not sending**: Check SMTP settings and authentication
- **Analytics not tracking**: Verify tracking IDs and script loading

### Getting Support

- **Documentation**: [Troubleshooting Guide](../06-troubleshooting/common-issues.md)
- **Community**: [GitHub Discussions](https://github.com/gstarwd/vibby.ai/discussions)
- **Issues**: [Report Configuration Problem](https://github.com/gstarwd/vibby.ai/issues/new)

---

**Configuration Complete!** 🎉  
**Next Steps**: [Create your first project](./first-project.md) or [explore the admin dashboard](../02-user-guide/admin-dashboard.md)