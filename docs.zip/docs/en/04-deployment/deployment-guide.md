# Deployment Guide

Deploy your **Vibby.ai** platform to production with confidence using this comprehensive deployment guide covering multiple hosting platforms and best practices.

## 🚀 Deployment Overview

Vibby.ai supports multiple deployment options, from simple static hosting to full-featured cloud platforms with server-side rendering and databases.

### Deployment Options

**Static Site Generation (SSG)**
- **Platforms**: Vercel, Netlify, GitHub Pages, Cloudflare Pages
- **Best for**: Content sites, blogs, marketing pages
- **Features**: Fast loading, CDN distribution, automatic builds
- **Limitations**: No server-side features, no real-time data

**Server-Side Rendering (SSR)**
- **Platforms**: Vercel, Netlify Functions, Railway, DigitalOcean
- **Best for**: Dynamic content, user authentication, APIs
- **Features**: Full SvelteKit features, server-side logic, real-time data
- **Requirements**: Node.js runtime, database connection

**Hybrid Deployment**
- **Platforms**: Vercel (recommended), Netlify
- **Best for**: Most use cases
- **Features**: Static + dynamic pages, edge functions, optimal performance

## 🔧 Pre-Deployment Preparation

### 1. Environment Configuration

#### Production Environment Variables

Create a production `.env` file:

```bash
# Basic Configuration
NODE_ENV=production
PUBLIC_SITE_URL=https://yourdomain.com

# Database (if using Supabase)
PUBLIC_SUPABASE_URL=https://your-project.supabase.co
PUBLIC_SUPABASE_ANON_KEY=your-production-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-production-service-key

# Email Configuration
SMTP_HOST=smtp.your-provider.com
SMTP_PORT=587
SMTP_USER=your-email@yourdomain.com
SMTP_PASS=your-app-password
SMTP_FROM=noreply@yourdomain.com

# Security
ENCRYPTION_SECRET=your-secure-48-character-production-key

# Analytics
PUBLIC_CLARITY_PROJECT_ID=your-clarity-id
PUBLIC_GA_MEASUREMENT_ID=G-XXXXXXXXXX

# Optional Services
SENTRY_DSN=your-sentry-dsn
REDIS_URL=redis://your-redis-instance
```

#### Environment Validation

```bash
# Validate required environment variables
node -e "
const required = ['NODE_ENV', 'PUBLIC_SITE_URL'];
const missing = required.filter(key => !process.env[key]);
if (missing.length) {
  console.error('Missing required env vars:', missing);
  process.exit(1);
}
console.log('✅ Environment validation passed');
"
```

### 2. Build Optimization

#### Production Build Configuration

Update `vite.config.ts` for production:

```typescript
import { sveltekit } from '@sveltejs/kit/vite';
import { defineConfig } from 'vite';

export default defineConfig(({ mode }) => ({
  plugins: [sveltekit()],
  
  build: {
    target: 'es2022',
    minify: 'terser',
    rollupOptions: {
      output: {
        manualChunks: {
          vendor: ['svelte'],
          ui: ['lucide-svelte', 'bits-ui'],
          utils: ['marked', 'gray-matter']
        }
      }
    }
  },
  
  define: {
    __BUILD_TIME__: JSON.stringify(new Date().toISOString()),
    __VERSION__: JSON.stringify(process.env.npm_package_version)
  },
  
  optimizeDeps: {
    include: ['marked', 'gray-matter', 'nodemailer']
  }
}));
```

#### Build Performance

```bash
# Clean previous builds
rm -rf .svelte-kit dist

# Build with performance analysis
npm run build -- --analyze

# Test production build locally
npm run preview
```

### 3. Content Preparation

#### Content Audit Checklist

- [ ] **Blog Posts**: All published posts have correct metadata
- [ ] **Images**: Optimized for web (WebP format, compressed)
- [ ] **Media**: All referenced files exist in `static/` directory
- [ ] **Links**: Internal links use relative paths
- [ ] **SEO**: All pages have proper meta tags
- [ ] **Sitemap**: XML sitemap is generated
- [ ] **Robots.txt**: Search engine directives are set

## 🌐 Platform-Specific Deployment

### Vercel Deployment (Recommended)

#### Why Vercel?
- **SvelteKit Native Support**: Built for SvelteKit applications
- **Edge Functions**: Fast serverless functions worldwide
- **Automatic SSL**: Free SSL certificates
- **Preview Deployments**: Every push gets a preview URL
- **Analytics**: Built-in performance monitoring

#### Step-by-Step Vercel Deployment

**1. Install Vercel CLI**

```bash
npm install -g vercel
```

**2. Initialize Vercel Project**

```bash
# In your project directory
vercel

# Follow the prompts:
# - Set up and deploy? Yes
# - Which scope? Select your account
# - Link to existing project? No
# - Project name: your-project-name
# - Directory: ./
# - Override settings? No
```

**3. Configure Environment Variables**

```bash
# Set production environment variables
vercel env add NODE_ENV production
vercel env add PUBLIC_SITE_URL https://yourdomain.com
vercel env add PUBLIC_SUPABASE_URL https://your-project.supabase.co
vercel env add ENCRYPTION_SECRET your-48-char-secret

# Import from local .env file
vercel env pull .env.production
```

**4. Custom Domain Setup**

```bash
# Add your custom domain
vercel domains add yourdomain.com

# Configure DNS (add these records to your domain provider):
# Type: CNAME, Name: www, Value: cname.vercel-dns.com
# Type: A, Name: @, Value: 76.76.19.61
```

**5. Deployment Configuration**

Create `vercel.json`:

```json
{
  "framework": "sveltekit",
  "buildCommand": "npm run build",
  "outputDirectory": "build",
  "installCommand": "npm install",
  "devCommand": "npm run dev",
  "functions": {
    "src/routes/api/**/*.ts": {
      "maxDuration": 30
    }
  },
  "headers": [
    {
      "source": "/(.*)",
      "headers": [
        {
          "key": "X-Frame-Options",
          "value": "DENY"
        },
        {
          "key": "X-Content-Type-Options",
          "value": "nosniff"
        },
        {
          "key": "X-XSS-Protection",
          "value": "1; mode=block"
        }
      ]
    },
    {
      "source": "/static/(.*)",
      "headers": [
        {
          "key": "Cache-Control",
          "value": "public, max-age=31536000, immutable"
        }
      ]
    }
  ],
  "redirects": [
    {
      "source": "/admin",
      "destination": "/vibbyai",
      "permanent": false
    }
  ],
  "rewrites": [
    {
      "source": "/sitemap.xml",
      "destination": "/api/sitemap"
    }
  ]
}
```

**6. Deploy**

```bash
# Deploy to production
vercel --prod

# Your site will be available at https://your-project.vercel.app
# and https://yourdomain.com (if custom domain configured)
```

### Netlify Deployment

#### Step-by-Step Netlify Deployment

**1. Install Netlify CLI**

```bash
npm install -g netlify-cli
```

**2. Build Configuration**

Create `netlify.toml`:

```toml
[build]
  command = "npm run build"
  functions = "netlify/functions"
  publish = "build"

[build.environment]
  NODE_VERSION = "18"
  NPM_FLAGS = "--prefix=/dev/null"

[[headers]]
  for = "/*"
  [headers.values]
    X-Frame-Options = "DENY"
    X-XSS-Protection = "1; mode=block"
    X-Content-Type-Options = "nosniff"

[[headers]]
  for = "/static/*"
  [headers.values]
    Cache-Control = "public, max-age=31536000, immutable"

[[redirects]]
  from = "/admin"
  to = "/vibbyai"
  status = 302

[[redirects]]
  from = "/api/*"
  to = "/.netlify/functions/:splat"
  status = 200
```

**3. Environment Variables**

```bash
# Login to Netlify
netlify login

# Set environment variables
netlify env:set NODE_ENV production
netlify env:set PUBLIC_SITE_URL https://yourdomain.com
netlify env:set ENCRYPTION_SECRET your-secret-key
```

**4. Deploy**

```bash
# Deploy to production
netlify deploy --prod

# Your site will be available at https://app-name.netlify.app
```

### Self-Hosted Deployment

#### Docker Deployment

**1. Create Dockerfile**

```dockerfile
# Build stage
FROM node:18-alpine AS builder

WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production && npm cache clean --force

COPY . .
RUN npm run build

# Production stage
FROM node:18-alpine AS production

WORKDIR /app

# Install dumb-init for proper signal handling
RUN apk add --no-cache dumb-init

# Create non-root user
RUN addgroup -g 1001 -S nodejs
RUN adduser -S sveltekit -u 1001

# Copy built application
COPY --from=builder --chown=sveltekit:nodejs /app/build build/
COPY --from=builder --chown=sveltekit:nodejs /app/node_modules node_modules/
COPY --from=builder --chown=sveltekit:nodejs /app/package.json package.json

USER sveltekit

EXPOSE 3000

ENV NODE_ENV=production
ENV PORT=3000

ENTRYPOINT ["dumb-init", "--"]
CMD ["node", "build"]
```

**2. Create docker-compose.yml**

```yaml
version: '3.8'

services:
  vibby-ai:
    build: .
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
      - PUBLIC_SITE_URL=https://yourdomain.com
      - ENCRYPTION_SECRET=${ENCRYPTION_SECRET}
    depends_on:
      - redis
    restart: unless-stopped

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    volumes:
      - redis-data:/data
    restart: unless-stopped

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
      - ./ssl:/etc/ssl/certs
    depends_on:
      - vibby-ai
    restart: unless-stopped

volumes:
  redis-data:
```

**3. Deploy with Docker**

```bash
# Build and start services
docker-compose up -d

# View logs
docker-compose logs -f vibby-ai

# Update application
docker-compose pull
docker-compose up -d --build
```

#### VPS Deployment (Ubuntu/Debian)

**1. Server Setup**

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install PM2 for process management
sudo npm install -g pm2

# Install Nginx
sudo apt install nginx

# Install SSL certificate (Let's Encrypt)
sudo apt install certbot python3-certbot-nginx
```

**2. Application Deployment**

```bash
# Clone repository
git clone https://github.com/your-username/vibby.ai.git
cd vibby.ai

# Install dependencies
npm install

# Create production environment file
cp .env.example .env.production
# Edit .env.production with your production values

# Build application
npm run build

# Start with PM2
pm2 start ecosystem.config.js --env production
pm2 save
pm2 startup
```

**3. PM2 Configuration**

Create `ecosystem.config.js`:

```javascript
module.exports = {
  apps: [{
    name: 'vibby-ai',
    script: 'build/index.js',
    instances: 'max',
    exec_mode: 'cluster',
    env: {
      NODE_ENV: 'development'
    },
    env_production: {
      NODE_ENV: 'production',
      PORT: 3000
    },
    error_file: './logs/err.log',
    out_file: './logs/out.log',
    log_file: './logs/combined.log',
    time: true
  }]
};
```

**4. Nginx Configuration**

Create `/etc/nginx/sites-available/vibby-ai`:

```nginx
server {
    listen 80;
    server_name yourdomain.com www.yourdomain.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name yourdomain.com www.yourdomain.com;

    ssl_certificate /etc/letsencrypt/live/yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/yourdomain.com/privkey.pem;

    # Security headers
    add_header X-Frame-Options "DENY" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;

    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }

    # Static files
    location /static/ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
```

**5. Enable and Start Services**

```bash
# Enable Nginx site
sudo ln -s /etc/nginx/sites-available/vibby-ai /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx

# Generate SSL certificate
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com

# Set up automatic certificate renewal
sudo crontab -e
# Add: 0 12 * * * /usr/bin/certbot renew --quiet
```

## 📊 Post-Deployment Configuration

### 1. Domain and SSL Setup

#### DNS Configuration

Configure these DNS records with your domain provider:

```
Type: A     Name: @     Value: [Your server IP]
Type: A     Name: www   Value: [Your server IP]
Type: CNAME Name: www   Value: yourdomain.com (alternative to A record)

# For Vercel/Netlify:
Type: CNAME Name: @     Value: [platform-specific-domain]
Type: CNAME Name: www   Value: [platform-specific-domain]
```

#### SSL Certificate Verification

```bash
# Test SSL configuration
curl -I https://yourdomain.com

# Check SSL rating
# Visit: https://www.ssllabs.com/ssltest/analyze.html?d=yourdomain.com
```

### 2. Performance Optimization

#### CDN Configuration

**Cloudflare Setup**
1. Sign up for Cloudflare
2. Add your domain
3. Update nameservers at your domain provider
4. Configure caching rules:

```
Cache Everything: ON
Browser Cache TTL: 1 year
Edge Cache TTL: 1 month
```

#### Image Optimization

```bash
# Optimize existing images
npm install -g imagemin-cli imagemin-webp imagemin-mozjpeg

# Convert and optimize images
imagemin static/images/*.jpg --out-dir=static/images/optimized --plugin=mozjpeg
imagemin static/images/*.png --out-dir=static/images/optimized --plugin=webp
```

### 3. Monitoring and Analytics

#### Application Monitoring

**Error Tracking with Sentry**

```bash
npm install @sentry/sveltekit
```

```typescript
// src/hooks.client.ts
import * as Sentry from '@sentry/sveltekit';

Sentry.init({
  dsn: 'YOUR_SENTRY_DSN',
  environment: 'production'
});
```

**Performance Monitoring**

```typescript
// src/lib/monitoring.ts
export class PerformanceMonitor {
  static trackPageLoad(pageName: string) {
    if (typeof window !== 'undefined') {
      const loadTime = performance.timing.loadEventEnd - performance.timing.navigationStart;
      
      // Send to analytics
      gtag('event', 'page_load_time', {
        page_name: pageName,
        value: loadTime
      });
    }
  }
}
```

#### Health Checks

```typescript
// src/routes/api/health/+server.ts
export async function GET() {
  const checks = {
    database: await checkDatabase(),
    email: await checkEmailService(),
    storage: await checkStorage()
  };
  
  const allHealthy = Object.values(checks).every(check => check === 'ok');
  
  return new Response(JSON.stringify({
    status: allHealthy ? 'healthy' : 'degraded',
    checks,
    timestamp: new Date().toISOString()
  }), {
    status: allHealthy ? 200 : 503,
    headers: { 'Content-Type': 'application/json' }
  });
}
```

### 4. Backup and Recovery

#### Automated Backups

```bash
#!/bin/bash
# backup.sh - Automated backup script

DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/backups/vibby-ai"

# Create backup directory
mkdir -p $BACKUP_DIR

# Backup application files
tar -czf $BACKUP_DIR/app_$DATE.tar.gz /var/www/vibby-ai

# Backup database (if using)
pg_dump $DATABASE_URL > $BACKUP_DIR/db_$DATE.sql

# Upload to cloud storage (optional)
aws s3 cp $BACKUP_DIR/ s3://your-backup-bucket/ --recursive

# Clean old backups (keep last 30 days)
find $BACKUP_DIR -name "*.tar.gz" -mtime +30 -delete
find $BACKUP_DIR -name "*.sql" -mtime +30 -delete

echo "Backup completed: $DATE"
```

```bash
# Add to crontab for daily backups
0 2 * * * /home/user/backup.sh >> /var/log/backup.log 2>&1
```

#### Disaster Recovery Plan

```markdown
# Disaster Recovery Checklist

## Immediate Response (0-1 hour)
- [ ] Identify the issue scope and impact
- [ ] Check system status and error logs
- [ ] Notify team and stakeholders
- [ ] Switch to maintenance mode if needed

## Recovery Actions (1-4 hours)
- [ ] Restore from latest backup if needed
- [ ] Fix identified issues
- [ ] Test critical functionality
- [ ] Monitor system stability

## Post-Recovery (4+ hours)
- [ ] Full system verification
- [ ] Update monitoring and alerts
- [ ] Document incident and lessons learned
- [ ] Update disaster recovery procedures
```

## 🔍 Deployment Troubleshooting

### Common Issues

#### Build Failures

```bash
# Check build logs
npm run build 2>&1 | tee build.log

# Common solutions:
# 1. Clear node_modules and reinstall
rm -rf node_modules package-lock.json
npm install

# 2. Check TypeScript errors
npm run check

# 3. Verify environment variables
node -e "console.log(process.env.NODE_ENV)"
```

#### Runtime Errors

```bash
# Check application logs
pm2 logs vibby-ai

# Check system resources
htop
df -h

# Restart application
pm2 restart vibby-ai
```

#### Performance Issues

```bash
# Monitor real-time performance
npm install -g clinic
clinic doctor -- node build/index.js

# Analyze bundle size
npm run build -- --analyze
```

### Rollback Procedures

```bash
# Git-based rollback
git log --oneline -10
git checkout [previous-commit-hash]
npm run build
pm2 restart vibby-ai

# Backup-based rollback
tar -xzf /backups/vibby-ai/app_20240115_120000.tar.gz -C /var/www/
pm2 restart vibby-ai
```

## ✅ Deployment Checklist

### Pre-Deployment
- [ ] Environment variables configured
- [ ] Build successful locally
- [ ] All tests passing
- [ ] Content audit completed
- [ ] Performance optimized

### Deployment
- [ ] DNS records configured
- [ ] SSL certificate installed
- [ ] Application deployed
- [ ] Database migrated (if applicable)
- [ ] Environment variables set

### Post-Deployment
- [ ] Site accessible via HTTPS
- [ ] All pages loading correctly
- [ ] Contact forms working
- [ ] Admin dashboard accessible
- [ ] Analytics tracking active
- [ ] Monitoring and alerts set up
- [ ] Backup system configured

---

**🚀 Deployment Complete!** Your Vibby.ai platform is now live and ready to serve users worldwide with optimal performance, security, and reliability.

**Next Steps**: [Set up monitoring](./monitoring.md) or [Configure security](./security.md)