# Roo Code Rules Guide

This guide explains how to use `.roo-rules` files to standardize your Vibby.ai project development.

## 📖 Quick Start

### 1. Check Project Compliance

```bash
# Check Roo Rules compliance
pnpm check:roo

# Check original project rules
pnpm check:rules

# Check all rules together
pnpm check:all
```

### 2. Understanding Check Results

The check script outputs detailed compliance reports:

```
🔍 Checking Roo Rules Compliance...
=====================================

1. Checking required files...
✅ Required file: .roo-rules
✅ Required file: CLAUDE.md
❌ Required file: some-file.json
   → File does not exist

...

📊 Check Statistics:
   Total checks: 45
   Passed: 40
   Failed: 5
   Pass rate: 89%

🎯 Compliance Rating:
   🥈 Good (80-89%) - Code generally complies with standards, with minor improvement areas
```

## 🎯 Core Standards

### Svelte 5 Syntax Requirements

#### ✅ Correct Usage

```svelte
<!-- New props syntax -->
<script lang="ts">
  interface Props {
    title: string;
    count?: number;
  }
  
  let { title, count = 0 }: Props = $props();
  let doubled = $derived(count * 2);
  let message = $state('Hello');
</script>

<!-- New event handling syntax -->
<button onclick={() => count++}>
  {title}: {count}
</button>
```

#### ❌ Deprecated Usage (Forbidden)

```svelte
<!-- Deprecated props syntax -->
<script lang="ts">
  export let title: string;  // ❌ Forbidden
  export let count = 0;      // ❌ Forbidden
  
  $: doubled = count * 2;    // ❌ Forbidden
</script>

<!-- Deprecated event syntax -->
<button on:click={() => count++}>  <!-- ❌ Forbidden -->
  {title}: {count}
</button>
```

### TypeScript Type Definitions

#### ✅ Recommended Type Definition Patterns

```typescript
// 1. Component Props Interface
interface ComponentProps {
  data: SiteConfig;
  currentLang: 'en' | 'zh';
  variant?: 'default' | 'secondary';
  className?: string;
}

// 2. API Response Types
interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
}

// 3. Site Configuration Types
interface SiteConfig {
  type: 'site-tool' | 'site-blog' | 'site-game';
  title: string;
  description: string;
  features?: FeatureConfig[];
}

// 4. Strictly typed functions
function processApiData(response: ApiResponse<SiteConfig>): SiteConfig {
  if (!response.success || !response.data) {
    throw new Error(response.error || 'Invalid response');
  }
  return response.data;
}
```

### Component Design System

#### shadcn/ui Component Usage Example

```svelte
<script lang="ts">
  import { Button } from '$lib/components/ui/button';
  import { Card, CardContent, CardHeader, CardTitle } from '$lib/components/ui/card';
  import { Badge } from '$lib/components/ui/badge';
  import { cn } from '$lib/utils';
  
  interface Props {
    title: string;
    description: string;
    variant?: 'default' | 'secondary';
    className?: string;
  }
  
  let { title, description, variant = 'default', className }: Props = $props();
</script>

<Card class={cn('w-full max-w-md', className)}>
  <CardHeader>
    <CardTitle class="flex items-center gap-2">
      {title}
      <Badge {variant}>{variant}</Badge>
    </CardTitle>
  </CardHeader>
  <CardContent>
    <p class="text-muted-foreground mb-4">{description}</p>
    <Button variant="default" size="lg" onclick={() => console.log('clicked')}>
      Action Button
    </Button>
  </CardContent>
</Card>
```

## 🔧 Development Workflow

### 1. New Component Development Process

```bash
# 1. Create component file (use PascalCase)
touch src/lib/components/ui/MyNewComponent.svelte

# 2. Write component code (follow Svelte 5 syntax)
# 3. Add TypeScript type definitions
# 4. Use tailwind-variants for style variants
# 5. Run checks
pnpm check:roo

# 6. Fix discovered issues
# 7. Re-check until passing
```

### 2. API Development Process

```bash
# 1. Create API route
touch src/routes/api/my-endpoint/+server.ts

# 2. Implement standard error handling and response format
# 3. Add TypeScript type definitions
# 4. Test API endpoint
curl http://localhost:5174/api/my-endpoint

# 5. Run full checks
pnpm check:all
```

## ❌ Common Mistakes and Solutions

### 1. Svelte 5 Syntax Errors

**Error**: Using deprecated `export let` syntax
```svelte
<!-- ❌ Wrong -->
<script>
  export let title: string;
</script>
```

**Solution**: Use new `$props()` syntax
```svelte
<!-- ✅ Correct -->
<script lang="ts">
  interface Props {
    title: string;
  }
  let { title }: Props = $props();
</script>
```

### 2. Missing TypeScript Types

**Error**: Missing type definitions
```typescript
// ❌ Wrong
let data: any = await response.json();
```

**Solution**: Define explicit types
```typescript
// ✅ Correct
interface ApiData {
  id: string;
  name: string;
}
let data: ApiData = await response.json();
```

## 📚 Further Learning

- [Svelte 5 Official Documentation](https://svelte.dev/docs/svelte/overview)
- [SvelteKit Documentation](https://kit.svelte.dev/docs)
- [shadcn/ui Component Library](https://ui.shadcn.com/)
- [Tailwind CSS Documentation](https://tailwindcss.com/docs)
- [TypeScript Best Practices](https://www.typescriptlang.org/docs/)

By following these standards and best practices, you'll be able to build high-quality, maintainable Vibby.ai applications.