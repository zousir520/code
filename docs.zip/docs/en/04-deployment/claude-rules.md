# Claude.md Rules Configuration

This guide explains how to configure and use the `CLAUDE.md` file to provide context and guidelines for Claude Code when working with your Vibby.ai project.

## 📖 Overview

The `CLAUDE.md` file serves as a comprehensive reference for Claude Code, containing:
- Essential development commands
- Project architecture overview
- Critical rules and constraints
- Development guidelines
- Common troubleshooting information

## 📁 File Location

The `CLAUDE.md` file should be placed in your project root:

```
vibby.ai/
├── CLAUDE.md          # ← Main Claude instructions
├── package.json
├── src/
└── docs/
```

## 🏗️ CLAUDE.md Structure

### 1. Essential Commands Section

Always include the most frequently used development commands:

```markdown
## Essential Commands

### Development
```bash
# Start development server
pnpm dev

# Build for production
pnpm build

# Preview production build
pnpm preview

# Type checking
pnpm check

# Database migration
pnpm db:migrate
```

### Testing and Validation
```bash
# Check project rules compliance
pnpm check:rules

# Verify Svelte components
pnpm check:watch
```
```

### 2. Critical Project Rules

Define non-negotiable project constraints:

```markdown
## Critical Project Rules

**⚠️ MUST READ PROJECT_RULES.md BEFORE ANY CHANGES**

### Core Design Principles
1. **CMS Page Design**: `/vibbyai/cms` MUST use iframe embedding to Sveltia CMS
2. **Data Source Strategy**: CONTENT_STRATEGY is `CMS_ONLY` - no GitHub API fallback
3. **Svelte 5 Only**: Use `$state`, `$derived`, `onclick` syntax
4. **Documentation**: ALL documentation goes in `docs/` directory only

### Forbidden Actions
- Changing CMS iframe to independent page or card layout
- Re-enabling GitHub API or adding multiple data source fallbacks
- Using Svelte 4 syntax or deprecated features
- Creating documentation directories other than `docs/`
```

### 3. Architecture Overview

Provide clear architectural context:

```markdown
## Architecture Overview

### Multi-Site Platform
This is a **unified platform that can operate as 3 different site types**:
- **site-tool**: Tools/SaaS landing page
- **site-blog**: Blog-focused site
- **site-game**: Gaming platform

Site type is determined by `PUBLIC_SITE_TYPE` environment variable.

### Data Storage Strategy
**Hybrid approach with clear separation**:
- **Static Content** (CMS): `src/content/` → Blog posts, pages, settings
- **Dynamic Data** (Database): Supabase → User data, backlinks, SEO progress
- **Priority Order**: Environment Variables → Database → Local Files → Defaults
```

### 4. Directory Structure

Include key directory mappings:

```markdown
### Key Directory Structure
```
src/
├── routes/
│   ├── vibbyai/          # Admin dashboard (protected)
│   ├── api/              # API endpoints
│   ├── [lang]/           # Multilingual routes (en, zh)
│   └── blog/             # Blog system
├── lib/
│   ├── components/       # Reusable UI components
│   │   ├── site-*/       # Site-type specific components
│   │   └── ui/           # shadcn/ui components
│   ├── services/         # Business logic
│   ├── stores/           # Svelte stores
│   └── types/            # TypeScript definitions
├── content/              # CMS content files
└── static/admin/         # Sveltia CMS configuration
```
```

### 5. Development Guidelines

Specify coding standards and patterns:

```markdown
## Development Guidelines

### Svelte 5 Syntax
```svelte
<!-- Correct -->
<script>
  let count = $state(0);
  let doubled = $derived(count * 2);
</script>

<button onclick={() => count++}>

<!-- Incorrect (deprecated) -->
<script>
  let count = 0;
  $: doubled = count * 2;
</script>

<button on:click={() => count++}>
```

### API Patterns
```typescript
// Success
return json({ success: true, data: result });

// Error
return json({ error: 'Error message' }, { status: 500 });
```
```

### 6. Environment Configuration

Document required environment variables:

```markdown
## Deployment (Vercel)

### Environment Variables
Required for production:
```env
PUBLIC_SUPABASE_URL=your_supabase_url
PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
PUBLIC_SITE_TYPE=site-tool  # or site-blog, site-game
```
```

### 7. Common Issues

Include troubleshooting information:

```markdown
## Common Issues

### Database Connection
If Supabase connection fails, APIs gracefully fall back to file system in development. Check environment variables and network connectivity.

### Content Not Loading
Verify content files exist in `src/content/` and follow proper naming conventions. Check console for file system errors.

### Build Failures
Run `pnpm check` locally to catch TypeScript errors. Ensure all imports use correct paths and types are properly defined.
```

## 🎯 Claude.md Best Practices

### 1. Keep It Concise

- Focus on essential information Claude Code needs
- Avoid duplicating documentation that exists elsewhere
- Use clear, actionable language

### 2. Update Regularly

- Keep commands and scripts current
- Update architecture changes immediately
- Reflect current project constraints

### 3. Use Examples

Always provide code examples for:
- API response formats
- Component structures
- Common patterns
- Error handling

### 4. Prioritize Critical Information

Place the most important constraints and patterns at the top:
- Forbidden actions
- Required syntax
- Breaking changes

## 🔧 Integration with Development Workflow

### 1. Onboarding New Developers

The CLAUDE.md serves as the first reference point:

```bash
# New developer workflow
1. Read CLAUDE.md
2. Run pnpm check:rules
3. Set up environment variables
4. Start development with pnpm dev
```

### 2. Code Review Process

Reference CLAUDE.md during reviews:
- Verify adherence to stated rules
- Check if new patterns need documentation
- Ensure consistency with architectural principles

### 3. Automated Compliance

Use CLAUDE.md rules in automated checks:

```bash
# Add to CI/CD pipeline
pnpm check:rules
pnpm check:claude-compliance
```

## 📋 CLAUDE.md Template

Here's a complete template for your project:

```markdown
# CLAUDE.md

This file provides guidance to Claude Code when working with this repository.

## Essential Commands

### Development
```bash
pnpm dev          # Start development server
pnpm build        # Build for production
pnpm check        # Type checking
```

## Critical Project Rules

### Core Principles
1. [Your specific rule 1]
2. [Your specific rule 2]
3. [Your specific rule 3]

### Forbidden Actions
- [Forbidden action 1]
- [Forbidden action 2]

## Architecture Overview

[Brief description of your architecture]

### Key Components
- [Component 1]: [Description]
- [Component 2]: [Description]

## Development Guidelines

### [Technology] Standards
[Specific coding standards]

### API Patterns
[Standard API patterns]

## Common Issues

### [Issue Category]
[Solution approach]
```

## 🎯 Advanced CLAUDE.md Features

### 1. Context-Aware Instructions

Provide different instructions based on file types:

```markdown
## File-Type Specific Guidelines

### When working with `.svelte` files:
- Always use Svelte 5 syntax
- Include TypeScript interfaces for props
- Use shadcn/ui components when possible

### When working with API routes (`+server.ts`):
- Implement proper error handling
- Use standard response format
- Include request/response type definitions

### When working with content files:
- Follow multi-language naming conventions
- Validate frontmatter structure
- Maintain consistent formatting
```

### 2. Decision Trees

Help Claude make architectural decisions:

```markdown
## Component Decision Tree

When creating new components:

1. **Is it UI-related?**
   - Yes → Use `src/lib/components/ui/`
   - No → Continue to #2

2. **Is it site-type specific?**
   - Yes → Use `src/lib/components/site-{type}/`
   - No → Use `src/lib/components/common/`

3. **Does it handle data?**
   - Yes → Consider if it needs a service in `src/lib/services/`
   - No → Component only
```

### 3. Performance Guidelines

Include performance considerations:

```markdown
## Performance Considerations

### Loading Strategies
- Use dynamic imports for large components
- Implement proper loading states
- Optimize images with Vercel optimization

### State Management
- Prefer local component state when possible
- Use stores for shared state across components
- Implement proper cleanup in effects
```

By maintaining a comprehensive and up-to-date CLAUDE.md file, you ensure that Claude Code has all the context needed to provide accurate, consistent assistance with your Vibby.ai project development.