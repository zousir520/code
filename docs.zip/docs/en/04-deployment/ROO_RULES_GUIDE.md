# Roo Rules 使用指南

本指南详细说明如何使用 `.roo-rules` 文件来规范您的 Vibby.ai 项目开发。

## 📖 快速开始

### 1. 检查项目规范合规性

```bash
# 检查 Roo Rules 规范
pnpm check:roo

# 检查原有项目规则
pnpm check:rules

# 同时检查所有规则
pnpm check:all
```

### 2. 理解检查结果

检查脚本会输出详细的合规性报告：

```
🔍 Checking Roo Rules Compliance...
=====================================

1. 检查必需文件...
✅ 必需文件: .roo-rules
✅ 必需文件: CLAUDE.md
❌ 必需文件: some-file.json
   → 文件不存在

...

📊 检查统计:
   总检查项: 45
   通过: 40
   失败: 5
   通过率: 89%

🎯 规范遵循度评级:
   🥈 良好 (80-89%) - 代码基本符合规范，有少量改进空间
```

## 🎯 核心规范说明

### Svelte 5 语法要求

#### ✅ 正确用法

```svelte
<!-- 新的 props 语法 -->
<script lang="ts">
  interface Props {
    title: string;
    count?: number;
  }
  
  let { title, count = 0 }: Props = $props();
  let doubled = $derived(count * 2);
  let message = $state('Hello');
</script>

<!-- 新的事件处理语法 -->
<button onclick={() => count++}>
  {title}: {count}
</button>
```

#### ❌ 过时用法（禁止）

```svelte
<!-- 过时的 props 语法 -->
<script lang="ts">
  export let title: string;  // ❌ 禁止
  export let count = 0;      // ❌ 禁止
  
  $: doubled = count * 2;    // ❌ 禁止
</script>

<!-- 过时的事件语法 -->
<button on:click={() => count++}>  <!-- ❌ 禁止 -->
  {title}: {count}
</button>
```

### TypeScript 类型定义

#### ✅ 推荐的类型定义模式

```typescript
// 1. 组件 Props 接口
interface ComponentProps {
  data: SiteConfig;
  currentLang: 'en' | 'zh';
  variant?: 'default' | 'secondary';
  className?: string;
}

// 2. API 响应类型
interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
}

// 3. 站点配置类型
interface SiteConfig {
  type: 'site-tool' | 'site-blog' | 'site-game';
  title: string;
  description: string;
  features?: FeatureConfig[];
}

// 4. 使用严格类型的函数
function processApiData(response: ApiResponse<SiteConfig>): SiteConfig {
  if (!response.success || !response.data) {
    throw new Error(response.error || 'Invalid response');
  }
  return response.data;
}
```

### 组件设计系统

#### shadcn/ui 组件使用示例

```svelte
<script lang="ts">
  import { Button } from '$lib/components/ui/button';
  import { Card, CardContent, CardHeader, CardTitle } from '$lib/components/ui/card';
  import { Badge } from '$lib/components/ui/badge';
  import { cn } from '$lib/utils';
  
  interface Props {
    title: string;
    description: string;
    variant?: 'default' | 'secondary';
    className?: string;
  }
  
  let { title, description, variant = 'default', className }: Props = $props();
</script>

<Card class={cn('w-full max-w-md', className)}>
  <CardHeader>
    <CardTitle class="flex items-center gap-2">
      {title}
      <Badge {variant}>{variant}</Badge>
    </CardTitle>
  </CardHeader>
  <CardContent>
    <p class="text-muted-foreground mb-4">{description}</p>
    <Button variant="default" size="lg" onclick={() => console.log('clicked')}>
      Action Button
    </Button>
  </CardContent>
</Card>
```

#### 自定义组件使用 tailwind-variants

```svelte
<script lang="ts" module>
  import { tv, type VariantProps } from 'tailwind-variants';
  import { cn } from '$lib/utils';
  
  export const alertVariants = tv({
    base: 'relative w-full rounded-lg border p-4',
    variants: {
      variant: {
        default: 'bg-background text-foreground',
        destructive: 'border-destructive/50 text-destructive dark:border-destructive',
        success: 'border-green-500/50 text-green-700 dark:border-green-500',
      },
    },
    defaultVariants: {
      variant: 'default',
    },
  });
  
  export type AlertVariant = VariantProps<typeof alertVariants>['variant'];
</script>

<script lang="ts">
  interface Props {
    variant?: AlertVariant;
    className?: string;
    children?: Snippet;
  }
  
  let { variant = 'default', className, children }: Props = $props();
</script>

<div class={cn(alertVariants({ variant }), className)}>
  {@render children?.()}
</div>
```

### API 接口标准实现

#### 标准 API 端点模式

```typescript
// src/routes/api/example/+server.ts
import { json, type RequestEvent } from '@sveltejs/kit';
import type { ApiResponse } from '$lib/types';

interface RequestBody {
  name: string;
  email: string;
}

interface ResponseData {
  id: string;
  message: string;
}

export async function GET(): Promise<Response> {
  try {
    const data = await getExampleData();
    
    const response: ApiResponse<ResponseData> = {
      success: true,
      data
    };
    
    return json(response);
  } catch (error) {
    console.error('[API Error]', 'Failed to get example data:', error);
    
    const response: ApiResponse = {
      success: false,
      error: 'Failed to retrieve data'
    };
    
    return json(response, { status: 500 });
  }
}

export async function POST({ request }: RequestEvent): Promise<Response> {
  try {
    const body: RequestBody = await request.json();
    
    // 验证请求数据
    if (!body.name || !body.email) {
      const response: ApiResponse = {
        success: false,
        error: 'Name and email are required'
      };
      return json(response, { status: 400 });
    }
    
    const result = await createExample(body);
    
    const response: ApiResponse<ResponseData> = {
      success: true,
      data: result
    };
    
    return json(response, { status: 201 });
  } catch (error) {
    console.error('[API Error]', 'Failed to create example:', error);
    
    const response: ApiResponse = {
      success: false,
      error: 'Failed to create resource'
    };
    
    return json(response, { status: 500 });
  }
}
```

### 多站点架构实现

#### 主页组件动态渲染

```svelte
<!-- src/routes/+page.svelte -->
<script lang="ts">
  import ToolHomePage from '$lib/components/site-tool/ToolHomePage.svelte';
  import BlogHomePage from '$lib/components/site-blog/BlogHomePage.svelte';
  import GameHomePage from '$lib/components/site-game/GameHomePage.svelte';
  import type { PageData } from './$types';
  
  let { data }: { data: PageData } = $props();
  
  // 根据站点类型选择组件
  const siteComponents = {
    'site-tool': ToolHomePage,
    'site-blog': BlogHomePage,
    'site-game': GameHomePage
  } as const;
  
  const CurrentComponent = siteComponents[data.siteConfig.type] || ToolHomePage;
</script>

<svelte:component 
  this={CurrentComponent} 
  {data} 
  currentLocale={data.currentLang || 'en'} 
/>
```

#### 环境配置获取

```typescript
// src/lib/config/site-config.ts
import type { SiteConfig } from '$lib/types';

export async function getSiteConfig(): Promise<SiteConfig> {
  // 1. 环境变量优先级最高
  if (process.env.PUBLIC_SITE_TYPE) {
    return {
      type: process.env.PUBLIC_SITE_TYPE as SiteConfig['type'],
      title: process.env.PUBLIC_SITE_TITLE || 'Vibby.ai',
      description: process.env.PUBLIC_SITE_DESCRIPTION || 'AI SaaS Platform'
    };
  }
  
  // 2. 尝试从数据库获取
  try {
    const response = await fetch('/api/site-config');
    if (response.ok) {
      const result = await response.json();
      if (result.success && result.data) {
        return result.data;
      }
    }
  } catch (error) {
    console.error('[CONFIG]', 'Database config failed:', error);
  }
  
  // 3. 后备到本地文件
  try {
    const fileConfig = await import('$lib/config/default.json');
    return fileConfig.default;
  } catch (error) {
    console.error('[CONFIG]', 'File config failed:', error);
  }
  
  // 4. 使用默认配置
  return {
    type: 'site-tool',
    title: 'Vibby.ai',
    description: 'AI SaaS Platform'
  };
}
```

### 国际化和内容管理

#### 本地化文本处理

```typescript
// src/lib/utils/i18n.ts
export interface LocalizedText {
  en: string;
  zh: string;
}

export function getLocalizedText(
  text: LocalizedText | string, 
  lang: string
): string {
  if (typeof text === 'string') {
    return text;
  }
  
  return text[lang as keyof LocalizedText] || text.en || '';
}

// 使用示例
export function useLocalizedContent(content: any, currentLang: string) {
  return {
    title: getLocalizedText(content.title, currentLang),
    description: getLocalizedText(content.description, currentLang),
    features: content.features?.map((feature: any) => ({
      ...feature,
      title: getLocalizedText(feature.title, currentLang),
      description: getLocalizedText(feature.description, currentLang)
    })) || []
  };
}
```

#### 内容文件结构

```
src/content/
├── blog/
│   ├── welcome-post.md           # 英文版本
│   ├── welcome-post.zh.md        # 中文版本
│   ├── tech-guide.md
│   └── tech-guide.zh.md
├── pages/
│   ├── about.json
│   └── contact.json
├── settings/
│   ├── general.json              # 通用设置
│   ├── footer.json              # 页脚配置
│   └── features.json            # 功能配置
└── ui-text.json                 # UI 界面文本
```

## 🔧 开发工作流

### 1. 新组件开发流程

```bash
# 1. 创建组件文件（使用 PascalCase）
touch src/lib/components/ui/MyNewComponent.svelte

# 2. 编写组件代码（遵循 Svelte 5 语法）
# 3. 添加 TypeScript 类型定义
# 4. 使用 tailwind-variants 定义样式变体
# 5. 运行检查
pnpm check:roo

# 6. 修复发现的问题
# 7. 再次检查直到通过
```

### 2. API 开发流程

```bash
# 1. 创建 API 路由
touch src/routes/api/my-endpoint/+server.ts

# 2. 实现标准的错误处理和响应格式
# 3. 添加 TypeScript 类型定义
# 4. 测试 API 端点
curl http://localhost:5174/api/my-endpoint

# 5. 运行完整检查
pnpm check:all
```

### 3. 代码审查清单

在提交代码前，请检查：

- [ ] 使用了 Svelte 5 新语法（`$props()`, `$state()`, `$derived()`）
- [ ] 没有使用过时的语法（`export let`, `on:click`, `$:`）
- [ ] 所有 TypeScript 类型都有明确定义
- [ ] API 端点包含适当的错误处理
- [ ] 组件遵循 shadcn/ui 设计系统
- [ ] 文件命名符合约定（PascalCase/kebab-case）
- [ ] 多语言文本使用了 `getLocalizedText`
- [ ] 站点类型特定的组件放在正确目录
- [ ] 运行 `pnpm check:roo` 并通过所有检查

## ❌ 常见错误和解决方案

### 1. Svelte 5 语法错误

**错误**：使用过时的 `export let` 语法
```svelte
<!-- ❌ 错误 -->
<script>
  export let title: string;
</script>
```

**解决**：使用新的 `$props()` 语法
```svelte
<!-- ✅ 正确 -->
<script lang="ts">
  interface Props {
    title: string;
  }
  let { title }: Props = $props();
</script>
```

### 2. TypeScript 类型缺失

**错误**：缺少类型定义
```typescript
// ❌ 错误
let data: any = await response.json();
```

**解决**：定义明确的类型
```typescript
// ✅ 正确
interface ApiData {
  id: string;
  name: string;
}
let data: ApiData = await response.json();
```

### 3. API 错误处理缺失

**错误**：没有错误处理
```typescript
// ❌ 错误
export async function GET() {
  const data = await getUser();
  return json(data);
}
```

**解决**：添加完整的错误处理
```typescript
// ✅ 正确
export async function GET() {
  try {
    const data = await getUser();
    return json({ success: true, data });
  } catch (error) {
    console.error('API Error:', error);
    return json({ success: false, error: 'Failed to get user' }, { status: 500 });
  }
}
```

## 🎯 性能优化建议

### 1. 组件懒加载

对于大型组件，使用动态导入：

```svelte
<script lang="ts">
  import { onMount } from 'svelte';
  
  let HeavyComponent: any = null;
  
  onMount(async () => {
    const module = await import('$lib/components/HeavyComponent.svelte');
    HeavyComponent = module.default;
  });
</script>

{#if HeavyComponent}
  <svelte:component this={HeavyComponent} {props} />
{:else}
  <div class="animate-pulse">Loading...</div>
{/if}
```

### 2. 图片优化

使用适当的图片优化策略：

```svelte
<!-- 使用 Vercel 图片优化 -->
<img 
  src="/api/og-image/{slug}" 
  alt={title}
  loading="lazy"
  class="w-full h-auto rounded-lg" 
/>
```

## 📚 进一步学习

- [Svelte 5 官方文档](https://svelte.dev/docs/svelte/overview)
- [SvelteKit 文档](https://kit.svelte.dev/docs)
- [shadcn/ui 组件库](https://ui.shadcn.com/)
- [Tailwind CSS 文档](https://tailwindcss.com/docs)
- [TypeScript 最佳实践](https://www.typescriptlang.org/docs/)

通过遵循这些规范和最佳实践，您将能够构建高质量、可维护的 Vibby.ai 应用程序。