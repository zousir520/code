# Cursor IDE Rules Configuration

This guide explains how to configure Cursor IDE with proper rules for Vibby.ai development using `.cursorrules` files.

## 📖 Quick Setup

### 1. Create .cursorrules File

Create a `.cursorrules` file in your project root:

```bash
touch .cursorrules
```

### 2. Example .cursorrules Configuration

```markdown
# Vibby.ai Cursor Rules

You are an expert TypeScript, SvelteKit, and Tailwind developer focused on the Vibby.ai multi-site platform.

## Key Principles

- Write concise, technical responses
- Use functional and declarative programming patterns
- Prefer iteration and modularization over duplication
- Use descriptive variable names with auxiliary verbs (e.g., isLoading, hasError)
- Structure files: exported component, subcomponents, helpers, static content, types

## Tech Stack

- **Framework**: SvelteKit with Svelte 5 runes
- **Styling**: Tailwind CSS + shadcn/ui components
- **Database**: Supabase
- **Language**: TypeScript
- **Build**: Vite
- **Deployment**: Vercel

## Svelte 5 Syntax (REQUIRED)

Always use new Svelte 5 syntax:

### ✅ Correct (Use This)
```svelte
<script lang="ts">
  interface Props {
    title: string;
    count?: number;
  }
  
  let { title, count = 0 }: Props = $props();
  let doubled = $derived(count * 2);
  let message = $state('Hello');
</script>

<button onclick={() => count++}>
  {title}: {count}
</button>
```

### ❌ Forbidden (Never Use)
```svelte
<script lang="ts">
  export let title: string;  // ❌ Old syntax
  export let count = 0;      // ❌ Old syntax
  
  $: doubled = count * 2;    // ❌ Old reactive syntax
</script>

<button on:click={() => count++}>  <!-- ❌ Old event syntax -->
  {title}: {count}
</button>
```

## TypeScript Requirements

- Always use strict TypeScript
- Define interfaces for all props and data structures
- Use proper return types for functions
- Avoid `any` type - always define specific types

### Example API Types
```typescript
interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
}

interface SiteConfig {
  type: 'site-tool' | 'site-blog' | 'site-game';
  title: string;
  description: string;
  features?: FeatureConfig[];
}
```

## Component Architecture

### Site-Type Specific Components
- `src/lib/components/site-tool/` - Tool/SaaS components
- `src/lib/components/site-blog/` - Blog components  
- `src/lib/components/site-game/` - Gaming components
- `src/lib/components/ui/` - shadcn/ui components

### Component Structure
```svelte
<script lang="ts" module>
  // Types and module-level code
</script>

<script lang="ts">
  // Component imports
  import { ComponentName } from '$lib/components/ui/component-name';
  import { cn } from '$lib/utils';
  
  // Props interface
  interface Props {
    title: string;
    variant?: 'default' | 'secondary';
    className?: string;
  }
  
  // Props destructuring
  let { title, variant = 'default', className }: Props = $props();
  
  // Reactive state
  let isVisible = $state(false);
  let computedValue = $derived(title.length > 10);
</script>

<!-- Template -->
<div class={cn('base-styles', className)}>
  <h1>{title}</h1>
</div>
```

## API Development Standards

### Standard API Response Format
```typescript
// Success response
return json({ success: true, data: result });

// Error response  
return json({ success: false, error: 'Error message' }, { status: 500 });
```

### Error Handling Pattern
```typescript
export async function GET(): Promise<Response> {
  try {
    const data = await fetchData();
    return json({ success: true, data });
  } catch (error) {
    console.error('[API Error]', 'Operation failed:', error);
    return json({ 
      success: false, 
      error: 'Failed to fetch data' 
    }, { status: 500 });
  }
}
```

## Multi-Site Architecture

The platform supports three site types via `PUBLIC_SITE_TYPE` environment variable:
- `site-tool`: Tools/SaaS landing page
- `site-blog`: Blog-focused site  
- `site-game`: Gaming platform

### Dynamic Component Selection
```svelte
<script lang="ts">
  import ToolHomePage from '$lib/components/site-tool/ToolHomePage.svelte';
  import BlogHomePage from '$lib/components/site-blog/BlogHomePage.svelte';
  import GameHomePage from '$lib/components/site-game/GameHomePage.svelte';
  
  const siteComponents = {
    'site-tool': ToolHomePage,
    'site-blog': BlogHomePage,
    'site-game': GameHomePage
  } as const;
  
  const CurrentComponent = siteComponents[data.siteConfig.type] || ToolHomePage;
</script>

<svelte:component this={CurrentComponent} {data} />
```

## Styling Guidelines

- Use Tailwind CSS for all styling
- Prefer shadcn/ui components for UI elements
- Use `cn()` utility for conditional classes
- Follow mobile-first responsive design

### Example with tailwind-variants
```typescript
import { tv, type VariantProps } from 'tailwind-variants';

export const buttonVariants = tv({
  base: 'inline-flex items-center justify-center rounded-md text-sm font-medium',
  variants: {
    variant: {
      default: 'bg-primary text-primary-foreground hover:bg-primary/90',
      destructive: 'bg-destructive text-destructive-foreground hover:bg-destructive/90',
    },
    size: {
      default: 'h-10 px-4 py-2',
      sm: 'h-9 rounded-md px-3',
      lg: 'h-11 rounded-md px-8',
    },
  },
  defaultVariants: {
    variant: 'default',
    size: 'default',
  },
});
```

## File Naming Conventions

- Components: `PascalCase.svelte` (e.g., `UserProfile.svelte`)
- Pages: `+page.svelte`, `+layout.svelte`
- API routes: `+server.ts`
- Utilities: `kebab-case.ts` (e.g., `site-config.ts`)
- Types: `kebab-case.ts` (e.g., `api-types.ts`)

## Forbidden Patterns

❌ **Never use these patterns:**
- Svelte 4 syntax (`export let`, `on:click`, `$:`)
- `any` type without specific reason
- Inline styles instead of Tailwind classes
- Direct DOM manipulation (use Svelte reactivity)
- Creating `doc/` directories (only use `docs/`)

## CMS Integration

- Use Sveltia CMS embedded via iframe at `/vibbyai/cms`
- Content files in `src/content/` organized by language
- Never change CMS from iframe to independent page

## Database Priority Order

1. Environment variables (highest priority)
2. Supabase database
3. Local files
4. Default values (lowest priority)

## Performance Guidelines

- Use dynamic imports for large components
- Implement proper loading states
- Optimize images with Vercel optimization
- Use SvelteKit's SSR capabilities

## Code Review Checklist

Before submitting code, ensure:
- [ ] Uses Svelte 5 syntax exclusively
- [ ] All TypeScript types are properly defined
- [ ] API endpoints have proper error handling
- [ ] Components follow shadcn/ui patterns
- [ ] File names follow conventions
- [ ] No deprecated syntax is used
- [ ] Multi-language support is implemented
- [ ] Site-type specific components are in correct directories

Always prioritize type safety, performance, and maintainability in your code suggestions.
```

## 🔧 IDE Configuration

### 1. Cursor Settings

Configure Cursor for optimal Svelte development:

```json
{
  "svelte.enable-ts-plugin": true,
  "typescript.preferences.quoteStyle": "single",
  "editor.formatOnSave": true,
  "editor.codeActionsOnSave": {
    "source.fixAll.eslint": true
  },
  "files.associations": {
    "*.svelte": "svelte"
  }
}
```

### 2. Extensions Recommendations

Essential Cursor extensions for Vibby.ai development:

- **Svelte for VS Code** - Svelte language support
- **Tailwind CSS IntelliSense** - Tailwind class autocompletion
- **TypeScript Importer** - Auto import TypeScript modules
- **Prettier** - Code formatting
- **ESLint** - Code linting

### 3. Code Snippets

Create custom snippets for faster development:

```json
{
  "Svelte 5 Component": {
    "prefix": "sv5component",
    "body": [
      "<script lang=\"ts\">",
      "  interface Props {",
      "    ${1:propName}: ${2:string};",
      "  }",
      "  ",
      "  let { ${1:propName} }: Props = $props();",
      "</script>",
      "",
      "<div>",
      "  {${1:propName}}",
      "</div>"
    ],
    "description": "Create a new Svelte 5 component with props"
  }
}
```

## 🎯 Best Practices

### 1. Code Organization

```
src/lib/components/
├── ui/                 # shadcn/ui components
├── site-tool/         # Tool-specific components
├── site-blog/         # Blog-specific components
├── site-game/         # Game-specific components
└── common/            # Shared components
```

### 2. Type Safety

Always define interfaces for component props:

```typescript
interface UserCardProps {
  user: {
    id: string;
    name: string;
    email: string;
  };
  showActions?: boolean;
  onUserClick?: (userId: string) => void;
}
```

### 3. State Management

Use Svelte 5 runes for state management:

```svelte
<script lang="ts">
  // Component state
  let isLoading = $state(false);
  let userData = $state<User[]>([]);
  
  // Derived state
  let filteredUsers = $derived(
    userData.filter(user => user.active)
  );
  
  // Effects
  $effect(() => {
    if (isLoading) {
      fetchUsers();
    }
  });
</script>
```

By following these Cursor rules, you'll maintain consistent code quality and leverage Cursor's AI capabilities effectively for Vibby.ai development.