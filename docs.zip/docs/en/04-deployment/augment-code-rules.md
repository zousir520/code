# Augment Code Rules Configuration

This guide explains how to configure Augment Code for optimal development experience with your Vibby.ai project, including setup, rules, and best practices.

## 📖 Overview

Augment Code is an AI-powered coding assistant that can be configured with specific rules and context to understand your project's requirements, coding standards, and architectural patterns.

## 🚀 Quick Setup

### 1. Installation

```bash
# Install Augment Code extension in your IDE
# Or visit: https://augmentcode.com

# Initialize configuration
augment init
```

### 2. Configuration Files

Augment Code can be configured through multiple files:

```
.augment/
├── config.yaml          # Main configuration
├── rules.md             # Coding rules and guidelines
├── context.md           # Project context and architecture
└── templates/           # Code templates
```

## ⚙️ Configuration Structure

### 1. Main Configuration (.augment/config.yaml)

```yaml
# Augment Code Configuration for Vibby.ai
project:
  name: "Vibby.ai"
  type: "SvelteKit"
  version: "1.0.0"

# Language and framework settings
languages:
  primary: "TypeScript"
  frameworks: 
    - "SvelteKit"
    - "Svelte 5"
    - "TailwindCSS"

# Code style preferences
code_style:
  indentation: 2
  quotes: "single"
  semicolons: true
  trailing_commas: true

# AI assistance preferences
ai_settings:
  suggestions: true
  auto_complete: true
  code_review: true
  documentation: true

# File type associations
file_types:
  ".svelte": "svelte"
  ".ts": "typescript"
  ".md": "markdown"

# Custom patterns
patterns:
  components: "src/lib/components/**/*.svelte"
  api_routes: "src/routes/api/**/+server.ts"
  pages: "src/routes/**/+page.svelte"
```

### 2. Rules Configuration (.augment/rules.md)

```markdown
# Vibby.ai Augment Code Rules

## Core Principles

1. **Svelte 5 Only**: Use modern Svelte 5 syntax exclusively
2. **Type Safety**: All code must be properly typed with TypeScript
3. **Component-Based**: Follow component-driven development
4. **Performance First**: Optimize for speed and bundle size

## Syntax Rules

### ✅ Required Svelte 5 Syntax

```svelte
<script lang="ts">
  interface Props {
    title: string;
    count?: number;
  }
  
  let { title, count = 0 }: Props = $props();
  let doubled = $derived(count * 2);
  let message = $state('Hello');
</script>

<button onclick={() => count++}>
  {title}: {count}
</button>
```

### ❌ Forbidden Patterns

Never use these deprecated patterns:
- `export let` for props → Use `$props()`
- `$:` for reactivity → Use `$derived()`
- `on:click` events → Use `onclick`
- `any` type → Use specific types

## Component Architecture

### File Organization
```
src/lib/components/
├── ui/                 # shadcn/ui components
├── site-tool/         # Tool-specific components
├── site-blog/         # Blog-specific components
├── site-game/         # Game-specific components
└── common/            # Shared components
```

### Component Structure
```svelte
<script lang="ts" module>
  // Types and module-level exports
</script>

<script lang="ts">
  // Imports
  import { ComponentName } from '$lib/components/ui/component';
  
  // Props interface
  interface Props {
    // Define all props with types
  }
  
  // Props destructuring
  let { prop1, prop2 = defaultValue }: Props = $props();
  
  // State management
  let localState = $state(initialValue);
  let derivedState = $derived(computation);
</script>

<!-- Template with proper structure -->
<div class="component-wrapper">
  <!-- Component content -->
</div>
```

## API Development Standards

### Response Format
```typescript
// Success response
return json({ success: true, data: result });

// Error response
return json({ success: false, error: 'Message' }, { status: code });
```

### Error Handling
```typescript
export async function GET(): Promise<Response> {
  try {
    const data = await fetchData();
    return json({ success: true, data });
  } catch (error) {
    console.error('[API Error]', error);
    return json({ 
      success: false, 
      error: 'Operation failed' 
    }, { status: 500 });
  }
}
```

## TypeScript Requirements

### Interface Definitions
```typescript
// Component Props
interface ComponentProps {
  title: string;
  variant?: 'default' | 'secondary';
  onClick?: () => void;
}

// API Types
interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
}

// Site Configuration
interface SiteConfig {
  type: 'site-tool' | 'site-blog' | 'site-game';
  title: string;
  description: string;
}
```

## Styling Guidelines

### Tailwind CSS Usage
- Use utility classes for styling
- Prefer composition over custom CSS
- Use responsive design patterns
- Follow design system tokens

### shadcn/ui Integration
```svelte
<script lang="ts">
  import { Button } from '$lib/components/ui/button';
  import { Card } from '$lib/components/ui/card';
  import { cn } from '$lib/utils';
</script>

<Card class={cn('custom-styles', className)}>
  <Button variant="default" onclick={handleClick}>
    Action
  </Button>
</Card>
```

## Multi-Site Architecture

### Site Type Handling
```typescript
// Dynamic component selection based on site type
const siteComponents = {
  'site-tool': ToolHomePage,
  'site-blog': BlogHomePage, 
  'site-game': GameHomePage
} as const;

const Component = siteComponents[siteType] || ToolHomePage;
```

### Environment Configuration
```typescript
// Priority order for configuration
1. Environment variables (highest)
2. Database values
3. Local files
4. Default values (lowest)
```

## Performance Optimization

### Code Splitting
```typescript
// Dynamic imports for large components
const HeavyComponent = lazy(() => import('./HeavyComponent.svelte'));
```

### Image Optimization
```svelte
<!-- Use optimized images -->
<img 
  src="/optimized/{image}" 
  alt={alt}
  loading="lazy"
  class="responsive-image" 
/>
```

## Testing Requirements

### Component Testing
```typescript
import { render, screen } from '@testing-library/svelte';
import Component from './Component.svelte';

test('component renders correctly', () => {
  render(Component, { props: { title: 'Test' } });
  expect(screen.getByText('Test')).toBeInTheDocument();
});
```

## Code Quality Standards

### ESLint Rules
- No unused variables
- Consistent naming conventions
- Proper error handling
- Type safety enforcement

### Prettier Configuration
- 2-space indentation
- Single quotes
- Trailing commas
- 80-character line length
```

### 3. Context Documentation (.augment/context.md)

```markdown
# Vibby.ai Project Context

## Project Overview

Vibby.ai is a multi-site SaaS platform that can operate in three different modes:
- **site-tool**: Tools/SaaS landing page
- **site-blog**: Blog-focused website
- **site-game**: Gaming platform

## Technology Stack

- **Frontend**: SvelteKit with Svelte 5
- **Styling**: TailwindCSS + shadcn/ui
- **Backend**: SvelteKit API routes
- **Database**: Supabase
- **Deployment**: Vercel
- **Content**: Sveltia CMS

## Architecture Patterns

### Data Flow
1. Environment Variables (highest priority)
2. Supabase Database
3. Local Content Files
4. Default Configuration

### Component Hierarchy
- Root Layout (`+layout.svelte`)
- Site-specific layouts
- Page components
- Reusable UI components

### API Design
- RESTful endpoints under `/api/`
- Consistent response format
- Proper error handling
- Type-safe request/response

## Development Workflow

1. Start with `pnpm dev`
2. Make changes following Svelte 5 patterns
3. Test with `pnpm check`
4. Deploy to Vercel

## Common Patterns

### State Management
```svelte
<!-- Local state -->
let count = $state(0);

<!-- Derived state -->
let doubled = $derived(count * 2);

<!-- Effects -->
$effect(() => {
  console.log('Count changed:', count);
});
```

### Error Boundaries
```svelte
{#await promise}
  <LoadingSpinner />
{:then data}
  <DataDisplay {data} />
{:catch error}
  <ErrorMessage {error} />
{/await}
```

## Integration Points

### CMS Integration
- Sveltia CMS embedded at `/vibbyai/cms`
- Content files in `src/content/`
- Multi-language support with `.zh.md` suffix

### Database Integration
- Supabase client in `src/lib/supabase.ts`
- Type-safe database queries
- Fallback to file system in development

### Authentication
- Simple file-based auth for admin
- Supabase auth for users
- Session management in layouts
```

## 🎯 Advanced Features

### 1. Custom Templates

Create reusable code templates in `.augment/templates/`:

```svelte
<!-- .augment/templates/component.svelte -->
<script lang="ts">
  interface Props {
    {{propName}}: {{propType}};
  }
  
  let { {{propName}} }: Props = $props();
</script>

<div class="{{className}}">
  {{{propName}}}
</div>
```

### 2. Intelligent Code Suggestions

Configure Augment to provide context-aware suggestions:

```yaml
# .augment/suggestions.yaml
suggestions:
  components:
    - when: "creating new component"
      suggest: "Use Svelte 5 syntax and TypeScript interfaces"
    - when: "styling component"
      suggest: "Use Tailwind CSS utilities and shadcn/ui components"
  
  api:
    - when: "creating API endpoint"
      suggest: "Include proper error handling and type definitions"
    - when: "database operations"
      suggest: "Use Supabase client with type safety"
```

### 3. Project-Specific Shortcuts

Define common operations:

```yaml
# .augment/shortcuts.yaml
shortcuts:
  new_component:
    description: "Create new Svelte component"
    template: "component.svelte"
    location: "src/lib/components/"
  
  new_api:
    description: "Create new API endpoint"
    template: "api-endpoint.ts"
    location: "src/routes/api/"
  
  new_page:
    description: "Create new page"
    template: "page.svelte"
    location: "src/routes/"
```

## 🔧 Integration with Development Tools

### 1. VS Code Integration

```json
{
  "augment.enable": true,
  "augment.suggestions": true,
  "augment.autoComplete": true,
  "augment.codeReview": true
}
```

### 2. Git Hooks

```bash
# .git/hooks/pre-commit
#!/bin/bash
augment lint
augment check-rules
```

### 3. CI/CD Integration

```yaml
# .github/workflows/augment.yml
name: Augment Code Review
on: [push, pull_request]

jobs:
  augment-review:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Run Augment Code Review
        run: |
          augment review --changed-files
          augment check-compliance
```

## 🎯 Best Practices

### 1. Keep Rules Updated

- Review and update rules monthly
- Align with project evolution
- Document new patterns immediately

### 2. Context Awareness

- Provide rich project context
- Include architectural decisions
- Document common patterns

### 3. Team Collaboration

- Share configuration across team
- Document custom shortcuts
- Maintain consistent standards

### 4. Performance Monitoring

- Monitor suggestion accuracy
- Track code quality improvements
- Measure development velocity

By following these Augment Code rules and configurations, you'll maximize the AI assistant's effectiveness and maintain high code quality standards throughout your Vibby.ai project development.