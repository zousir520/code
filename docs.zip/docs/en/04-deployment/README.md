# Development Tools Configuration

This section contains comprehensive guides for configuring various AI-powered development tools with your Vibby.ai project.

## 📚 Available Guides

### 1. [Roo Code Rules](./roo-code-rules.md)
Learn how to use `.roo-rules` files to standardize your project development with automated compliance checking.

**Key Features:**
- Automated code compliance checking
- Svelte 5 syntax enforcement
- TypeScript type safety validation
- Component architecture guidelines

### 2. [Cursor IDE Rules](./cursor-rules.md)
Configure Cursor IDE with proper rules for optimal Vibby.ai development using `.cursorrules` files.

**Key Features:**
- Cursor IDE configuration
- AI-powered code suggestions
- Project-specific templates
- Code quality enforcement

### 3. [Claude.md Configuration](./claude-rules.md)
Set up comprehensive project context for Claude Code using the `CLAUDE.md` file.

**Key Features:**
- Project architecture documentation
- Development guidelines
- Common troubleshooting
- Essential commands reference

### 4. [Augment Code Rules](./augment-code-rules.md)
Configure Augment Code for optimal development experience with custom rules and templates.

**Key Features:**
- AI assistant configuration
- Custom code templates
- Project-specific shortcuts
- Team collaboration tools

## 🚀 Quick Start

### 1. Choose Your Tools

Select the AI development tools you want to use:

```bash
# For Roo Code users
pnpm check:roo

# For Cursor IDE users  
# Configure .cursorrules file

# For Claude Code users
# Ensure CLAUDE.md is up to date

# For Augment Code users
augment init
```

### 2. Universal Setup

All tools benefit from these project configurations:

```bash
# Ensure TypeScript is properly configured
pnpm check

# Verify Svelte 5 syntax compliance
pnpm check:rules

# Run full project validation
pnpm check:all
```

### 3. Tool-Specific Setup

Follow the individual guides for detailed setup instructions for each tool.

## 🎯 Common Principles

All development tools in this project follow these core principles:

### 1. Svelte 5 Syntax Only
```svelte
<!-- ✅ Correct -->
<script lang="ts">
  interface Props {
    title: string;
  }
  let { title }: Props = $props();
  let count = $state(0);
</script>

<button onclick={() => count++}>
  {title}: {count}
</button>
```

### 2. TypeScript Everywhere
- All components use TypeScript
- Proper interface definitions
- No `any` types without justification
- Strict type checking enabled

### 3. Component Architecture
```
src/lib/components/
├── ui/                 # shadcn/ui components
├── site-tool/         # Tool-specific components
├── site-blog/         # Blog-specific components  
├── site-game/         # Game-specific components
└── common/            # Shared components
```

### 4. API Standards
```typescript
// Standard response format
return json({ success: true, data: result });
return json({ success: false, error: 'Message' }, { status: 500 });
```

### 5. Multi-Site Support
- Site type determined by `PUBLIC_SITE_TYPE`
- Dynamic component selection
- Environment-based configuration

## 🔧 Development Workflow

### 1. Initial Setup
```bash
# Clone and install
git clone your-repo
cd your-repo
pnpm install

# Configure your preferred AI tools
# See individual guides for setup instructions
```

### 2. Daily Development
```bash
# Start development
pnpm dev

# Run checks frequently
pnpm check:rules

# Before committing
pnpm check:all
```

### 3. Code Review Process
- Verify tool configurations are followed
- Check compliance with Svelte 5 standards
- Ensure TypeScript type safety
- Validate component architecture

## 📋 Configuration Checklist

Use this checklist to ensure all tools are properly configured:

### Project Files
- [ ] `CLAUDE.md` exists and is up to date
- [ ] `.cursorrules` configured (if using Cursor)
- [ ] `.roo-rules` configured (if using Roo Code)
- [ ] `.augment/` directory set up (if using Augment Code)

### Code Standards
- [ ] All components use Svelte 5 syntax
- [ ] TypeScript interfaces defined
- [ ] API endpoints follow standard format
- [ ] Components organized by site type

### Development Environment
- [ ] IDE configured with appropriate extensions
- [ ] Linting and formatting rules active
- [ ] Type checking enabled
- [ ] Hot reload working

### Team Collaboration
- [ ] All team members using same tool configurations
- [ ] Documentation updated with any custom rules
- [ ] CI/CD pipeline includes rule checking

## 🎯 Best Practices

### 1. Keep Configurations Synchronized
- Update all tool configurations when project rules change
- Maintain consistency across different AI assistants
- Document any tool-specific exceptions

### 2. Regular Maintenance
- Review and update rules monthly
- Keep pace with framework updates
- Document new patterns as they emerge

### 3. Team Adoption
- Ensure all team members understand the configurations
- Provide training on tool-specific features
- Maintain shared configuration files

### 4. Continuous Improvement
- Monitor code quality metrics
- Gather feedback on tool effectiveness
- Iterate on configurations based on project needs

## 🚨 Troubleshooting

### Common Issues

#### Tool Conflicts
If multiple AI tools give conflicting suggestions:
1. Prioritize project-specific rules (CLAUDE.md, .roo-rules)
2. Follow Svelte 5 syntax standards
3. Maintain TypeScript type safety

#### Configuration Drift
If configurations become inconsistent:
1. Review all tool configuration files
2. Update to match current project standards  
3. Run compliance checks across all tools

#### Performance Issues
If AI tools slow down development:
1. Optimize configuration complexity
2. Reduce scope of real-time analysis
3. Use selective tool activation

### Getting Help

1. **Check Individual Guides**: Each tool has specific troubleshooting sections
2. **Project Documentation**: Refer to `CLAUDE.md` for project-specific guidance
3. **Team Resources**: Consult with team members on configuration best practices

By following these development tool configurations, you'll create a consistent, productive development environment that leverages AI assistance while maintaining high code quality standards.