# Technical Architecture Guide

Understanding the **Vibby.ai** technical architecture empowers developers to build, customize, and extend the platform effectively.

## 🏗️ Architecture Overview

Vibby.ai is built on modern web technologies designed for performance, scalability, and developer productivity.

### Core Technology Stack

**Frontend Framework**
- **SvelteKit**: Full-stack framework with SSR/SSG
- **TypeScript**: Type-safe development
- **TailwindCSS**: Utility-first CSS framework
- **Svelte 5**: Latest Svelte with runes

**Backend & Services**
- **Node.js**: JavaScript runtime
- **Supabase**: Database and authentication (optional)
- **File-based CMS**: Git-powered content management
- **API Routes**: SvelteKit server-side functions

**Development Tools**
- **Vite**: Fast build tool and dev server
- **ESLint**: Code linting and formatting
- **PostCSS**: CSS processing and optimization
- **pnpm**: Fast, efficient package manager

### Architecture Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                    Vibby.ai Architecture                    │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐     │
│  │   Client    │    │   Server    │    │  External   │     │
│  │  (Browser)  │    │ (SvelteKit) │    │  Services   │     │
│  └─────────────┘    └─────────────┘    └─────────────┘     │
│         │                   │                   │           │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐     │
│  │   Svelte    │    │ API Routes  │    │  Supabase   │     │
│  │ Components  │◄──►│   +server   │◄──►│  Database   │     │
│  └─────────────┘    └─────────────┘    └─────────────┘     │
│         │                   │                   │           │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐     │
│  │ TailwindCSS │    │ Content API │    │    SMTP     │     │
│  │   Styles    │    │File System │    │   Email     │     │
│  └─────────────┘    └─────────────┘    └─────────────┘     │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                      File Structure                         │
│                                                             │
│  src/                          static/                      │
│  ├── routes/          (Pages)  ├── admin/     (CMS)        │
│  ├── lib/             (Utils)  ├── images/    (Assets)     │
│  ├── content/         (Data)   └── uploads/   (Media)      │
│  └── app.html         (Shell)                              │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## 📁 Project Structure Deep Dive

### Source Code Organization

```
src/
├── app.html                    # HTML shell template
├── app.css                     # Global styles
├── app.d.ts                    # TypeScript definitions
├── hooks.server.ts             # Server-side hooks
├── routes/                     # SvelteKit routes
│   ├── +layout.svelte          # Root layout
│   ├── +layout.server.ts       # Root layout server logic
│   ├── +page.svelte           # Homepage component
│   ├── +page.server.ts        # Homepage server logic
│   ├── [lang]/                # Internationalized routes
│   │   ├── +layout.svelte
│   │   ├── +page.svelte
│   │   ├── blog/
│   │   └── about/
│   ├── api/                   # API endpoints
│   │   ├── ping/+server.ts
│   │   ├── blog/+server.ts
│   │   └── admin/
│   ├── vibbyai/               # Admin dashboard
│   │   ├── +layout.svelte
│   │   ├── +page.svelte
│   │   ├── cms/+page.svelte
│   │   └── settings/
│   └── blog/                  # Blog routes
│       ├── +layout.svelte
│       ├── +page.svelte
│       └── [slug]/+page.svelte
├── lib/                       # Shared libraries
│   ├── components/            # Reusable components
│   │   ├── ui/               # UI component library
│   │   ├── blocks/           # Page building blocks
│   │   ├── blog/             # Blog-specific components
│   │   └── dashboard/        # Admin components
│   ├── services/             # Business logic services
│   │   ├── content.ts        # Content management
│   │   ├── api-client.ts     # API utilities
│   │   └── auth.ts           # Authentication
│   ├── stores/               # Svelte stores
│   │   ├── siteConfig.ts     # Site configuration
│   │   └── uiText.ts         # UI text management
│   ├── utils/                # Utility functions
│   │   ├── response.ts       # HTTP response helpers
│   │   └── time.ts           # Date/time utilities
│   └── types/                # TypeScript type definitions
│       ├── content.ts        # Content types
│       └── api.ts            # API types
└── content/                  # Content files
    ├── blog/                 # Blog posts
    ├── pages/                # Static pages
    ├── home/                 # Homepage content
    └── site-config.json      # Site configuration
```

### Configuration Files

```
Project Root/
├── package.json              # Dependencies and scripts
├── pnpm-lock.yaml           # Lock file for pnpm
├── svelte.config.js         # SvelteKit configuration
├── vite.config.ts           # Vite build configuration
├── tailwind.config.js       # TailwindCSS configuration
├── postcss.config.js        # PostCSS configuration
├── tsconfig.json            # TypeScript configuration
├── .env.example             # Environment variables template
├── .gitignore               # Git ignore rules
└── vercel.json              # Deployment configuration
```

## 🔧 Core Systems Architecture

### 1. Routing System

#### SvelteKit File-Based Routing

```typescript
// Route structure examples
const routeStructure = {
  // Static routes
  '/': 'src/routes/+page.svelte',
  '/about': 'src/routes/about/+page.svelte',
  '/contact': 'src/routes/contact/+page.svelte',
  
  // Dynamic routes
  '/blog/[slug]': 'src/routes/blog/[slug]/+page.svelte',
  '/[lang]/blog/[slug]': 'src/routes/[lang]/blog/[slug]/+page.svelte',
  
  // API routes
  '/api/ping': 'src/routes/api/ping/+server.ts',
  '/api/blog/posts': 'src/routes/api/blog/posts/+server.ts',
  
  // Admin routes
  '/vibbyai': 'src/routes/vibbyai/+page.svelte',
  '/vibbyai/cms': 'src/routes/vibbyai/cms/+page.svelte'
};
```

#### Route Loading Patterns

```typescript
// +page.server.ts - Server-side data loading
export async function load({ params, url }) {
  const { slug } = params;
  
  // Load blog post data
  const post = await getBlogPost(slug);
  
  if (!post) {
    throw error(404, 'Post not found');
  }
  
  return {
    post,
    meta: {
      title: post.title,
      description: post.excerpt
    }
  };
}

// +page.svelte - Client-side component
<script lang="ts">
  import type { PageData } from './$types';
  
  export let data: PageData;
  
  $: ({ post, meta } = data);
</script>

<svelte:head>
  <title>{meta.title}</title>
  <meta name="description" content={meta.description} />
</svelte:head>

<article>
  <h1>{post.title}</h1>
  <div>{@html post.content}</div>
</article>
```

### 2. Content Management System

#### File-Based Content Architecture

```typescript
// Content loading system
interface ContentLoader {
  // Load blog posts
  getBlogPosts(): Promise<BlogPost[]>;
  getBlogPost(slug: string): Promise<BlogPost | null>;
  
  // Load static pages
  getPage(slug: string): Promise<Page | null>;
  getPages(): Promise<Page[]>;
  
  // Load site configuration
  getSiteConfig(): Promise<SiteConfig>;
  getNavigationConfig(): Promise<NavigationConfig>;
}

// Implementation
export class FileContentLoader implements ContentLoader {
  private contentDir = 'src/content';
  
  async getBlogPosts(): Promise<BlogPost[]> {
    const files = await glob(`${this.contentDir}/blog/*.md`);
    const posts = await Promise.all(
      files.map(file => this.loadMarkdownFile(file))
    );
    
    return posts
      .filter(post => post.published)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }
  
  private async loadMarkdownFile(filePath: string) {
    const content = await fs.readFile(filePath, 'utf-8');
    const { data: frontmatter, content: body } = matter(content);
    
    return {
      ...frontmatter,
      content: await this.processMarkdown(body),
      slug: this.extractSlug(filePath)
    };
  }
}
```

#### Content Types Definition

```typescript
// TypeScript interfaces for content
export interface BlogPost {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  author: Author;
  publishedAt: string;
  updatedAt: string;
  tags: string[];
  categories: string[];
  featured: boolean;
  published: boolean;
  readingTime: number;
  image?: string;
  seo: SEOMetadata;
}

export interface Page {
  id: string;
  title: string;
  slug: string;
  content: string;
  template: string;
  published: boolean;
  updatedAt: string;
  seo: SEOMetadata;
}

export interface SiteConfig {
  siteName: string;
  siteDescription: string;
  siteUrl: string;
  defaultLanguage: string;
  supportedLanguages: string[];
  theme: ThemeConfig;
  features: FeatureConfig;
  contact: ContactInfo;
  social: SocialLinks;
}
```

### 3. API Architecture

#### RESTful API Design

```typescript
// API route structure
export const apiRoutes = {
  // Health and status
  'GET /api/ping': () => ({ status: 'ok' }),
  'GET /api/health': () => getSystemHealth(),
  
  // Content endpoints
  'GET /api/blog/posts': (params) => getBlogPosts(params),
  'GET /api/blog/posts/[slug]': (slug) => getBlogPost(slug),
  'POST /api/blog/posts': (data) => createBlogPost(data),
  
  // Site configuration
  'GET /api/site-config': () => getSiteConfig(),
  'PUT /api/site-config': (data) => updateSiteConfig(data),
  
  // Admin endpoints
  'GET /api/admin/stats': () => getAdminStats(),
  'POST /api/admin/env-config': (data) => updateEnvConfig(data)
};

// API response format
interface APIResponse<T> {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
    details?: unknown;
  };
  meta?: {
    pagination?: PaginationInfo;
    timestamp: string;
  };
}
```

#### API Implementation Example

```typescript
// src/routes/api/blog/posts/+server.ts
import { json } from '@sveltejs/kit';
import type { RequestHandler } from './$types';
import { getBlogPosts } from '$lib/services/content';

export const GET: RequestHandler = async ({ url }) => {
  try {
    const page = Number(url.searchParams.get('page')) || 1;
    const limit = Number(url.searchParams.get('limit')) || 10;
    const tag = url.searchParams.get('tag');
    
    const { posts, total } = await getBlogPosts({ page, limit, tag });
    
    return json({
      success: true,
      data: {
        posts,
        pagination: {
          current: page,
          total: Math.ceil(total / limit),
          hasNext: page * limit < total,
          hasPrev: page > 1
        }
      },
      meta: {
        timestamp: new Date().toISOString()
      }
    });
  } catch (error) {
    return json({
      success: false,
      error: {
        code: 'INTERNAL_ERROR',
        message: 'Failed to fetch blog posts'
      }
    }, { status: 500 });
  }
};
```

### 4. State Management

#### Svelte Stores Architecture

```typescript
// Site configuration store
import { writable, derived } from 'svelte/store';
import type { SiteConfig } from '$lib/types';

// Core stores
export const siteConfig = writable<SiteConfig | null>(null);
export const currentLanguage = writable<string>('en');
export const theme = writable<'light' | 'dark'>('light');

// Derived stores
export const siteName = derived(
  siteConfig,
  ($config) => $config?.siteName || 'Vibby.ai'
);

export const supportedLanguages = derived(
  siteConfig,
  ($config) => $config?.supportedLanguages || ['en']
);

// Store actions
export const siteConfigActions = {
  async load() {
    const response = await fetch('/api/site-config');
    const config = await response.json();
    siteConfig.set(config.data);
  },
  
  async update(updates: Partial<SiteConfig>) {
    const response = await fetch('/api/site-config', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates)
    });
    
    if (response.ok) {
      const updated = await response.json();
      siteConfig.set(updated.data);
    }
  }
};
```

#### Component State Patterns

```svelte
<!-- Component with reactive state -->
<script lang="ts">
  import { onMount } from 'svelte';
  import { siteConfig, theme } from '$lib/stores';
  
  // Props
  export let title: string;
  export let content: string;
  
  // Local state using Svelte 5 runes
  let loading = $state(false);
  let error = $state<string | null>(null);
  
  // Reactive computations
  const isDarkMode = $derived($theme === 'dark');
  const pageTitle = $derived(`${title} | ${$siteConfig?.siteName}`);
  
  // Effects
  onMount(() => {
    // Component initialization
    loading = false;
  });
  
  // Event handlers
  function handleAction() {
    loading = true;
    // Async operation
    setTimeout(() => {
      loading = false;
    }, 1000);
  }
</script>

<div class="page" class:dark={isDarkMode}>
  <h1>{pageTitle}</h1>
  
  {#if loading}
    <div class="loading">Loading...</div>
  {:else if error}
    <div class="error">{error}</div>
  {:else}
    <div class="content">{@html content}</div>
  {/if}
  
  <button onclick={handleAction} disabled={loading}>
    {loading ? 'Processing...' : 'Take Action'}
  </button>
</div>
```

### 5. Plugin Architecture

#### Plugin System Design

```typescript
// Plugin interface
export interface Plugin {
  id: string;
  name: string;
  version: string;
  description: string;
  
  // Lifecycle hooks
  onInit?(): Promise<void>;
  onActivate?(): Promise<void>;
  onDeactivate?(): Promise<void>;
  
  // Extension points
  routes?: PluginRoute[];
  components?: PluginComponent[];
  services?: PluginService[];
  hooks?: PluginHook[];
}

// Plugin manager
export class PluginManager {
  private plugins = new Map<string, Plugin>();
  private activePlugins = new Set<string>();
  
  async loadPlugin(plugin: Plugin) {
    this.plugins.set(plugin.id, plugin);
    
    if (plugin.onInit) {
      await plugin.onInit();
    }
  }
  
  async activatePlugin(pluginId: string) {
    const plugin = this.plugins.get(pluginId);
    if (!plugin) throw new Error(`Plugin ${pluginId} not found`);
    
    if (plugin.onActivate) {
      await plugin.onActivate();
    }
    
    this.activePlugins.add(pluginId);
  }
  
  getActivePlugins(): Plugin[] {
    return Array.from(this.activePlugins)
      .map(id => this.plugins.get(id)!)
      .filter(Boolean);
  }
}
```

#### Example Plugin Implementation

```typescript
// Game plugin example
export const gamePlugin: Plugin = {
  id: 'game-plugin',
  name: 'Game Content Plugin',
  version: '1.0.0',
  description: 'Adds game-related content management features',
  
  async onInit() {
    console.log('Game plugin initialized');
  },
  
  routes: [
    {
      path: '/games',
      component: 'GameListPage'
    },
    {
      path: '/games/[slug]',
      component: 'GameDetailPage'
    }
  ],
  
  components: [
    {
      name: 'GameCard',
      component: GameCard
    },
    {
      name: 'GameGrid',
      component: GameGrid
    }
  ],
  
  services: [
    {
      name: 'gameService',
      implementation: new GameService()
    }
  ]
};
```

## 🔐 Security Architecture

### Authentication & Authorization

#### Authentication Flow

```typescript
// Authentication service
export class AuthService {
  private sessionStore = writable<Session | null>(null);
  
  async login(credentials: LoginCredentials): Promise<Session> {
    const response = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(credentials)
    });
    
    if (!response.ok) {
      throw new Error('Login failed');
    }
    
    const { session } = await response.json();
    this.sessionStore.set(session);
    
    return session;
  }
  
  async logout(): Promise<void> {
    await fetch('/api/auth/logout', { method: 'POST' });
    this.sessionStore.set(null);
  }
  
  async checkAuth(): Promise<Session | null> {
    try {
      const response = await fetch('/api/auth/status');
      if (response.ok) {
        const { session } = await response.json();
        this.sessionStore.set(session);
        return session;
      }
    } catch (error) {
      // Handle auth check error
    }
    
    this.sessionStore.set(null);
    return null;
  }
}
```

#### Authorization Middleware

```typescript
// Server-side authorization hooks
export async function handleAuth({ event, resolve }) {
  const token = event.cookies.get('session-token');
  
  if (token) {
    try {
      const session = await verifyToken(token);
      event.locals.user = session.user;
      event.locals.session = session;
    } catch (error) {
      // Invalid token, clear cookie
      event.cookies.delete('session-token');
    }
  }
  
  return resolve(event);
}

// Route protection
export function requireAuth(handler: RequestHandler): RequestHandler {
  return async (event) => {
    if (!event.locals.user) {
      return new Response(null, {
        status: 401,
        headers: { 'WWW-Authenticate': 'Bearer' }
      });
    }
    
    return handler(event);
  };
}

// Role-based access control
export function requireRole(role: string) {
  return function (handler: RequestHandler): RequestHandler {
    return async (event) => {
      const user = event.locals.user;
      
      if (!user || !user.roles.includes(role)) {
        return new Response(null, { status: 403 });
      }
      
      return handler(event);
    };
  };
}
```

### Data Security

#### Encryption & Environment Variables

```typescript
// Environment configuration service
export class EnvConfigService {
  private encryptionKey: string;
  
  constructor() {
    this.encryptionKey = process.env.ENCRYPTION_SECRET || this.generateKey();
  }
  
  encrypt(value: string): string {
    const cipher = crypto.createCipher('aes-256-cbc', this.encryptionKey);
    let encrypted = cipher.update(value, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    return encrypted;
  }
  
  decrypt(encryptedValue: string): string {
    const decipher = crypto.createDecipher('aes-256-cbc', this.encryptionKey);
    let decrypted = decipher.update(encryptedValue, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
  }
  
  private generateKey(): string {
    return crypto.randomBytes(32).toString('hex');
  }
}
```

## 🚀 Performance Architecture

### Build Optimization

#### Vite Configuration

```typescript
// vite.config.ts
import { sveltekit } from '@sveltejs/kit/vite';
import { defineConfig } from 'vite';

export default defineConfig({
  plugins: [sveltekit()],
  
  build: {
    rollupOptions: {
      output: {
        manualChunks: {
          // Vendor chunks
          'vendor-svelte': ['svelte'],
          'vendor-ui': ['@tailwindcss/forms', '@tailwindcss/typography'],
          
          // App chunks
          'admin': ['src/routes/vibbyai'],
          'blog': ['src/routes/blog']
        }
      }
    }
  },
  
  optimizeDeps: {
    include: ['marked', 'gray-matter']
  },
  
  server: {
    port: 5173,
    host: true
  }
});
```

#### Code Splitting Strategy

```typescript
// Dynamic imports for code splitting
export async function loadAdminModule() {
  const { AdminDashboard } = await import('$lib/components/dashboard/AdminDashboard.svelte');
  return AdminDashboard;
}

export async function loadBlogModule() {
  const { BlogPost } = await import('$lib/components/blog/BlogPost.svelte');
  return BlogPost;
}

// Lazy loading components
<script lang="ts">
  import { onMount } from 'svelte';
  
  let AdminComponent: any = null;
  
  onMount(async () => {
    if (userIsAdmin) {
      AdminComponent = await loadAdminModule();
    }
  });
</script>

{#if AdminComponent}
  <svelte:component this={AdminComponent} />
{/if}
```

### Caching Strategy

#### Server-Side Caching

```typescript
// Content caching service
export class ContentCache {
  private cache = new Map<string, CacheEntry>();
  private ttl = 5 * 60 * 1000; // 5 minutes
  
  async get<T>(key: string, loader: () => Promise<T>): Promise<T> {
    const cached = this.cache.get(key);
    
    if (cached && cached.expiry > Date.now()) {
      return cached.value;
    }
    
    const value = await loader();
    this.cache.set(key, {
      value,
      expiry: Date.now() + this.ttl
    });
    
    return value;
  }
  
  invalidate(pattern: string) {
    for (const key of this.cache.keys()) {
      if (key.includes(pattern)) {
        this.cache.delete(key);
      }
    }
  }
}

// Usage in API routes
export const GET: RequestHandler = async ({ params }) => {
  const { slug } = params;
  
  const post = await contentCache.get(`blog:${slug}`, () => 
    getBlogPost(slug)
  );
  
  return json({ post });
};
```

## 🔄 Development Workflow

### Local Development Setup

```bash
# Development environment setup
git clone https://github.com/your-repo/vibby.ai.git
cd vibby.ai

# Install dependencies
pnpm install

# Set up environment
cp .env.example .env
# Edit .env with your configuration

# Start development server
pnpm dev

# Open in browser
open http://localhost:5173
```

### Build & Deployment Process

```bash
# Production build
pnpm build

# Preview production build
pnpm preview

# Type checking
pnpm check

# Linting
pnpm lint

# Testing (if configured)
pnpm test
```

### Development Scripts

```json
{
  "scripts": {
    "dev": "vite dev",
    "build": "vite build",
    "preview": "vite preview",
    "check": "svelte-kit sync && svelte-check --tsconfig ./tsconfig.json",
    "check:watch": "svelte-kit sync && svelte-check --tsconfig ./tsconfig.json --watch",
    "lint": "eslint .",
    "format": "prettier --write .",
    "typesafe-i18n": "typesafe-i18n"
  }
}
```

## 🧪 Testing Architecture

### Testing Strategy

```typescript
// Unit testing with Vitest
import { describe, it, expect } from 'vitest';
import { getBlogPost } from '$lib/services/content';

describe('Content Service', () => {
  it('should load blog post by slug', async () => {
    const post = await getBlogPost('test-post');
    
    expect(post).toBeDefined();
    expect(post.title).toBe('Test Post');
    expect(post.published).toBe(true);
  });
  
  it('should return null for non-existent post', async () => {
    const post = await getBlogPost('non-existent');
    expect(post).toBeNull();
  });
});

// Component testing with Testing Library
import { render, screen } from '@testing-library/svelte';
import BlogPost from '$lib/components/blog/BlogPost.svelte';

describe('BlogPost Component', () => {
  it('renders blog post content', () => {
    const post = {
      title: 'Test Post',
      content: '<p>Test content</p>',
      author: 'Test Author'
    };
    
    render(BlogPost, { props: { post } });
    
    expect(screen.getByText('Test Post')).toBeInTheDocument();
    expect(screen.getByText('Test content')).toBeInTheDocument();
  });
});
```

### E2E Testing Setup

```typescript
// Playwright E2E tests
import { test, expect } from '@playwright/test';

test('homepage loads correctly', async ({ page }) => {
  await page.goto('/');
  
  await expect(page).toHaveTitle(/Vibby.ai/);
  await expect(page.locator('h1')).toContainText('Build Your AI Startup');
});

test('blog navigation works', async ({ page }) => {
  await page.goto('/');
  await page.click('text=Blog');
  
  await expect(page).toHaveURL('/blog');
  await expect(page.locator('h1')).toContainText('Blog');
});

test('admin dashboard requires authentication', async ({ page }) => {
  await page.goto('/vibbyai');
  
  // Should redirect to login or show login form
  await expect(page).toHaveURL(/login/);
});
```

## 📊 Monitoring & Analytics

### Performance Monitoring

```typescript
// Performance tracking service
export class PerformanceService {
  private metrics = new Map<string, PerformanceMetric>();
  
  startMeasure(name: string) {
    performance.mark(`${name}-start`);
  }
  
  endMeasure(name: string) {
    performance.mark(`${name}-end`);
    performance.measure(name, `${name}-start`, `${name}-end`);
    
    const measure = performance.getEntriesByName(name)[0];
    this.recordMetric(name, measure.duration);
  }
  
  private recordMetric(name: string, duration: number) {
    // Send to analytics service
    if (typeof window !== 'undefined' && window.gtag) {
      window.gtag('event', 'timing_complete', {
        name: name,
        value: Math.round(duration)
      });
    }
  }
}
```

### Error Tracking

```typescript
// Error handling service
export class ErrorService {
  static handleError(error: Error, context?: any) {
    console.error('Application error:', error, context);
    
    // Send to error tracking service
    if (typeof window !== 'undefined') {
      // Example: Sentry integration
      // Sentry.captureException(error, { extra: context });
    }
  }
  
  static handleApiError(response: Response, context?: any) {
    const error = new Error(`API Error: ${response.status} ${response.statusText}`);
    this.handleError(error, { ...context, url: response.url });
  }
}
```

---

**🏗️ Technical Architecture Mastered!** You now understand the complete technical foundation of Vibby.ai and can build, customize, and extend the platform effectively.

**Next Steps**: [Learn API Integration](./api-integration.md) or [Explore Customization Options](./customization.md)