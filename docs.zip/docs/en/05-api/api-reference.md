# API Reference

Complete API documentation for **Vibby.ai**. This guide covers all available endpoints, authentication methods, and integration examples.

## 🚀 API Overview

### Base Information

- **Base URL**: `https://yourdomain.com/api`
- **Protocol**: HTTPS only
- **Format**: JSON
- **Authentication**: API Key or Session-based
- **Rate Limiting**: 1000 requests/hour (adjustable)
- **Versioning**: URL-based (`/api/v1/`)

### Quick Start

```bash
# Health check
curl https://yourdomain.com/api/ping

# Example authenticated request
curl -H "Authorization: Bearer YOUR_API_KEY" \
     https://yourdomain.com/api/content/posts
```

## 🔐 Authentication

### API Key Authentication

#### Getting API Keys

1. **Admin Dashboard**: Go to `/vibbyai/api-keys`
2. **Create Key**: Click "Generate New API Key"
3. **Configure Permissions**: Set access levels
4. **Copy Key**: Save securely (shown only once)

#### Using API Keys

**Header Authentication** (Recommended):
```bash
curl -H "Authorization: Bearer YOUR_API_KEY" \
     https://yourdomain.com/api/endpoint
```

**Query Parameter**:
```bash
curl "https://yourdomain.com/api/endpoint?api_key=YOUR_API_KEY"
```

#### API Key Management

```typescript
// TypeScript interface for API keys
interface ApiKey {
  id: string;
  name: string;
  key: string;
  permissions: string[];
  createdAt: string;
  lastUsed: string;
  rateLimit: number;
  active: boolean;
}
```

### Session Authentication

For web applications using cookies:

```javascript
// Login first
const response = await fetch('/api/auth/login', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ username, password }),
  credentials: 'include'
});

// Subsequent requests include session cookie automatically
const data = await fetch('/api/admin/stats', {
  credentials: 'include'
});
```

## 📊 Core API Endpoints

### Health & Status

#### GET /api/ping
**Description**: Health check endpoint

```bash
curl https://yourdomain.com/api/ping
```

**Response**:
```json
{
  "status": "ok",
  "timestamp": "2024-01-15T10:30:00Z",
  "version": "1.0.0",
  "uptime": 86400
}
```

#### GET /api/health
**Description**: Detailed system health

```bash
curl https://yourdomain.com/api/health
```

**Response**:
```json
{
  "status": "healthy",
  "checks": {
    "database": "ok",
    "email": "ok",
    "storage": "ok"
  },
  "metrics": {
    "memoryUsage": "45%",
    "cpuUsage": "12%",
    "diskUsage": "60%"
  }
}
```

## 📝 Content API

### Blog Posts

#### GET /api/blog/posts
**Description**: Retrieve blog posts

**Parameters**:
- `page` (number): Page number (default: 1)
- `limit` (number): Posts per page (default: 10, max: 100)
- `tag` (string): Filter by tag
- `author` (string): Filter by author
- `published` (boolean): Filter by publication status
- `search` (string): Search in title and content

```bash
curl "https://yourdomain.com/api/blog/posts?page=1&limit=5&published=true"
```

**Response**:
```json
{
  "posts": [
    {
      "id": "post-1",
      "title": "Getting Started with AI",
      "slug": "getting-started-with-ai",
      "excerpt": "Learn the basics of artificial intelligence...",
      "content": "Full markdown content...",
      "author": {
        "name": "John Doe",
        "email": "john@example.com",
        "avatar": "/images/authors/john.jpg"
      },
      "publishedAt": "2024-01-15T09:00:00Z",
      "updatedAt": "2024-01-15T10:30:00Z",
      "tags": ["AI", "Tutorial"],
      "featured": true,
      "readingTime": 5,
      "image": "/images/blog/ai-basics.jpg",
      "seo": {
        "title": "Getting Started with AI - Complete Guide",
        "description": "Comprehensive guide to artificial intelligence..."
      }
    }
  ],
  "pagination": {
    "current": 1,
    "pages": 10,
    "total": 95,
    "hasNext": true,
    "hasPrev": false
  }
}
```

#### GET /api/blog/posts/{slug}
**Description**: Get single blog post

```bash
curl https://yourdomain.com/api/blog/posts/getting-started-with-ai
```

**Response**:
```json
{
  "post": {
    "id": "post-1",
    "title": "Getting Started with AI",
    "slug": "getting-started-with-ai",
    "content": "Full markdown content with table of contents...",
    "tableOfContents": [
      { "level": 2, "title": "Introduction", "id": "introduction" },
      { "level": 2, "title": "Core Concepts", "id": "core-concepts" }
    ],
    "related": [
      {
        "title": "Advanced AI Techniques",
        "slug": "advanced-ai-techniques",
        "excerpt": "Take your AI knowledge to the next level..."
      }
    ],
    "prevPost": {
      "title": "Previous Post",
      "slug": "previous-post"
    },
    "nextPost": {
      "title": "Next Post", 
      "slug": "next-post"
    }
  }
}
```

#### POST /api/blog/posts
**Description**: Create new blog post (Admin only)

**Headers**:
```
Authorization: Bearer YOUR_API_KEY
Content-Type: application/json
```

**Body**:
```json
{
  "title": "New Blog Post",
  "content": "Markdown content here...",
  "excerpt": "Brief description",
  "tags": ["tag1", "tag2"],
  "featured": false,
  "published": true,
  "publishedAt": "2024-01-15T09:00:00Z",
  "seo": {
    "title": "Custom SEO Title",
    "description": "Custom meta description"
  }
}
```

**Response**:
```json
{
  "success": true,
  "post": {
    "id": "new-post-id",
    "slug": "new-blog-post",
    "createdAt": "2024-01-15T10:30:00Z"
  }
}
```

### Pages

#### GET /api/content/pages
**Description**: Get all pages

```bash
curl https://yourdomain.com/api/content/pages
```

**Response**:
```json
{
  "pages": [
    {
      "id": "about",
      "title": "About Us",
      "slug": "about",
      "content": "Page content...",
      "template": "default",
      "published": true,
      "updatedAt": "2024-01-15T10:30:00Z"
    }
  ]
}
```

#### GET /api/content/pages/{slug}
**Description**: Get single page

```bash
curl https://yourdomain.com/api/content/pages/about
```

### Homepage Content

#### GET /api/content/homepage
**Description**: Get homepage sections

```bash
curl https://yourdomain.com/api/content/homepage
```

**Response**:
```json
{
  "hero": {
    "title": "Build Your AI Startup Fast",
    "subtitle": "Everything you need to launch",
    "cta": {
      "primary": { "label": "Get Started", "url": "/signup" }
    }
  },
  "features": {
    "title": "Powerful Features",
    "items": [...]
  },
  "faq": {
    "title": "FAQ",
    "items": [...]
  }
}
```

## 🔧 Site Configuration API

### General Settings

#### GET /api/site-config
**Description**: Get site configuration

```bash
curl https://yourdomain.com/api/site-config
```

**Response**:
```json
{
  "siteName": "Vibby.ai",
  "siteDescription": "AI Startup Platform",
  "siteUrl": "https://yourdomain.com",
  "defaultLanguage": "en",
  "supportedLanguages": ["en", "zh"],
  "theme": {
    "defaultMode": "light",
    "allowDarkMode": true
  },
  "features": {
    "blog": true,
    "multilingual": true,
    "analytics": true
  }
}
```

#### PUT /api/site-config
**Description**: Update site configuration (Admin only)

**Headers**:
```
Authorization: Bearer YOUR_ADMIN_API_KEY
Content-Type: application/json
```

**Body**:
```json
{
  "siteName": "New Site Name",
  "siteDescription": "Updated description"
}
```

### Navigation

#### GET /api/content/navigation
**Description**: Get navigation structure

```bash
curl https://yourdomain.com/api/content/navigation
```

**Response**:
```json
{
  "header": {
    "logo": { "text": "Vibby.ai", "image": "/logo.svg" },
    "menu": [
      { "label": "Home", "url": "/" },
      { "label": "About", "url": "/about" }
    ]
  },
  "footer": {
    "sections": [...]
  }
}
```

## 👤 User Management API

### Authentication

#### POST /api/auth/login
**Description**: User login

**Body**:
```json
{
  "email": "user@example.com",
  "password": "secure_password"
}
```

**Response**:
```json
{
  "success": true,
  "user": {
    "id": "user-123",
    "email": "user@example.com",
    "name": "John Doe",
    "role": "admin"
  },
  "session": {
    "token": "session_token",
    "expiresAt": "2024-01-16T10:30:00Z"
  }
}
```

#### POST /api/auth/logout
**Description**: User logout

```bash
curl -X POST https://yourdomain.com/api/auth/logout \
     -H "Authorization: Bearer SESSION_TOKEN"
```

#### GET /api/auth/status
**Description**: Check authentication status

```bash
curl https://yourdomain.com/api/auth/status \
     -H "Authorization: Bearer SESSION_TOKEN"
```

**Response**:
```json
{
  "authenticated": true,
  "user": {
    "id": "user-123",
    "email": "user@example.com",
    "role": "admin"
  }
}
```

## 📊 Analytics API

### Usage Statistics

#### GET /api/analytics/stats
**Description**: Get site statistics (Admin only)

```bash
curl https://yourdomain.com/api/analytics/stats \
     -H "Authorization: Bearer YOUR_ADMIN_API_KEY"
```

**Response**:
```json
{
  "overview": {
    "totalPosts": 45,
    "totalPages": 12,
    "totalUsers": 156,
    "monthlyVisitors": 2340
  },
  "recent": {
    "newPosts": 3,
    "newUsers": 12,
    "pageViews": 890
  },
  "popular": {
    "posts": [
      {
        "title": "Most Popular Post",
        "slug": "most-popular-post",
        "views": 1250
      }
    ],
    "pages": [
      {
        "title": "Popular Page",
        "slug": "popular-page", 
        "views": 890
      }
    ]
  }
}
```

#### GET /api/analytics/performance
**Description**: Get performance metrics

**Parameters**:
- `period` (string): "day", "week", "month", "year"
- `metric` (string): "views", "users", "sessions"

```bash
curl "https://yourdomain.com/api/analytics/performance?period=week&metric=views" \
     -H "Authorization: Bearer YOUR_ADMIN_API_KEY"
```

## 🛠️ Admin API

### System Management

#### GET /api/admin/system
**Description**: Get system information

```bash
curl https://yourdomain.com/api/admin/system \
     -H "Authorization: Bearer YOUR_ADMIN_API_KEY"
```

**Response**:
```json
{
  "version": "1.0.0",
  "environment": "production",
  "uptime": 86400,
  "memory": {
    "used": "45MB",
    "total": "100MB",
    "percentage": 45
  },
  "storage": {
    "used": "2.1GB",
    "total": "10GB",
    "percentage": 21
  }
}
```

### Environment Configuration

#### GET /api/env-config
**Description**: Get environment configuration

#### POST /api/env-config
**Description**: Update environment settings

**Body**:
```json
{
  "SITE_NAME": "New Site Name",
  "SITE_URL": "https://newdomain.com",
  "ENABLE_ANALYTICS": "true"
}
```

## 🔍 Search API

### Content Search

#### GET /api/search
**Description**: Search content

**Parameters**:
- `q` (string): Search query
- `type` (string): "posts", "pages", "all"
- `limit` (number): Results limit

```bash
curl "https://yourdomain.com/api/search?q=artificial%20intelligence&type=posts&limit=5"
```

**Response**:
```json
{
  "query": "artificial intelligence",
  "results": [
    {
      "type": "post",
      "title": "Getting Started with AI",
      "excerpt": "Learn the basics of artificial intelligence...",
      "url": "/blog/getting-started-with-ai",
      "score": 0.95
    }
  ],
  "total": 12,
  "took": 45
}
```

## 📧 Email API

### Contact Forms

#### POST /api/contact
**Description**: Submit contact form

**Body**:
```json
{
  "name": "John Doe",
  "email": "john@example.com",
  "subject": "General Inquiry",
  "message": "Hello, I have a question about..."
}
```

**Response**:
```json
{
  "success": true,
  "message": "Thank you for your message. We'll get back to you soon!"
}
```

### Newsletter

#### POST /api/newsletter/subscribe
**Description**: Subscribe to newsletter

**Body**:
```json
{
  "email": "subscriber@example.com",
  "preferences": {
    "weekly": true,
    "product_updates": true
  }
}
```

## 🔧 Utility Endpoints

### File Upload

#### POST /api/upload
**Description**: Upload files (Admin only)

**Headers**:
```
Authorization: Bearer YOUR_ADMIN_API_KEY
Content-Type: multipart/form-data
```

**Body**: FormData with file

**Response**:
```json
{
  "success": true,
  "file": {
    "filename": "image.jpg",
    "url": "/uploads/images/image.jpg",
    "size": 102400,
    "type": "image/jpeg"
  }
}
```

### Sitemap

#### GET /api/sitemap
**Description**: Get sitemap data

```bash
curl https://yourdomain.com/api/sitemap
```

**Response**:
```json
{
  "urls": [
    {
      "loc": "https://yourdomain.com/",
      "lastmod": "2024-01-15",
      "changefreq": "daily",
      "priority": 1.0
    },
    {
      "loc": "https://yourdomain.com/blog/post-1",
      "lastmod": "2024-01-15",
      "changefreq": "monthly",
      "priority": 0.8
    }
  ]
}
```

## 📚 SDK & Libraries

### JavaScript/TypeScript SDK

```bash
npm install @vibby/api-sdk
```

```typescript
import { VibbyAPI } from '@vibby/api-sdk';

const api = new VibbyAPI({
  baseUrl: 'https://yourdomain.com/api',
  apiKey: 'YOUR_API_KEY'
});

// Get blog posts
const posts = await api.blog.getPosts({ limit: 10 });

// Create a post
const newPost = await api.blog.createPost({
  title: 'New Post',
  content: 'Content here...'
});

// Get site config
const config = await api.site.getConfig();
```

### Python SDK

```bash
pip install vibby-api
```

```python
from vibby_api import VibbyAPI

api = VibbyAPI(
    base_url='https://yourdomain.com/api',
    api_key='YOUR_API_KEY'
)

# Get blog posts
posts = api.blog.get_posts(limit=10)

# Create a post
new_post = api.blog.create_post({
    'title': 'New Post',
    'content': 'Content here...'
})
```

## ⚠️ Error Handling

### HTTP Status Codes

- `200` - Success
- `201` - Created
- `400` - Bad Request
- `401` - Unauthorized
- `403` - Forbidden
- `404` - Not Found
- `422` - Validation Error
- `429` - Rate Limited
- `500` - Server Error

### Error Response Format

```json
{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Invalid input data",
    "details": {
      "field": "email",
      "reason": "Invalid email format"
    },
    "timestamp": "2024-01-15T10:30:00Z",
    "requestId": "req-123"
  }
}
```

### Common Error Codes

- `UNAUTHORIZED` - Invalid or missing API key
- `VALIDATION_ERROR` - Invalid request data
- `NOT_FOUND` - Resource not found
- `RATE_LIMITED` - Too many requests
- `PERMISSION_DENIED` - Insufficient permissions

## 🚦 Rate Limiting

### Default Limits

- **Authenticated**: 1000 requests/hour
- **Anonymous**: 100 requests/hour
- **Admin**: 5000 requests/hour

### Rate Limit Headers

```
X-RateLimit-Limit: 1000
X-RateLimit-Remaining: 999
X-RateLimit-Reset: 1642262400
X-RateLimit-Retry-After: 3600
```

### Handling Rate Limits

```javascript
const response = await fetch('/api/endpoint');

if (response.status === 429) {
  const retryAfter = response.headers.get('X-RateLimit-Retry-After');
  console.log(`Rate limited. Retry after ${retryAfter} seconds`);
}
```

## 🔒 Security Best Practices

### API Key Security

- **Never expose API keys** in client-side code
- **Use environment variables** for API keys
- **Rotate keys regularly**
- **Use appropriate permissions** (principle of least privilege)
- **Monitor API key usage**

### Request Security

- **Always use HTTPS** in production
- **Validate all inputs** on the server side
- **Implement proper CORS** policies
- **Use request signing** for sensitive operations

### Example Secure Implementation

```javascript
// ✅ Correct - Server-side API call
// api/server-endpoint.js
export async function POST({ request }) {
  const apiKey = process.env.VIBBY_API_KEY; // Server-side only
  
  const response = await fetch('https://api.vibby.ai/endpoint', {
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json'
    }
  });
  
  return response.json();
}

// ❌ Incorrect - Client-side exposure
// components/Component.svelte
const apiKey = 'your-api-key'; // Never do this!
```

## 📞 Support & Resources

### Getting Help

- **API Documentation**: This guide
- **Interactive API Explorer**: `/api/docs` (if enabled)
- **GitHub Issues**: [Report API Issues](https://github.com/gstarwd/vibby.ai/issues)
- **Community**: [Developer Discussions](https://github.com/gstarwd/vibby.ai/discussions)

### Additional Resources

- **Postman Collection**: Download from `/api/postman`
- **OpenAPI Spec**: Available at `/api/openapi.json`
- **Code Examples**: [GitHub Repository](https://github.com/gstarwd/vibby.ai-examples)

---

**API Reference Complete!** 🎉  
**Next Steps**: [Explore authentication](./authentication.md) or [check out deployment guides](../04-deployment/deployment-guide.md)