# API 响应标准化指南

## 概述

本指南制定了项目中所有API端点的响应格式标准，确保前后端数据交互的一致性和可维护性。

## 标准API响应格式

### 成功响应

所有成功的API响应必须使用 `successResponse()` 函数，格式如下：

```typescript
{
  "success": true,
  "data": T,                    // 实际返回的数据
  "message": "操作成功描述",     // 可选的成功消息
  "timestamp": "2025-07-17T13:21:26.593Z",
  "source": "/api/endpoint"     // API端点路径
}
```

### 错误响应

所有错误响应必须使用 `handleApiError()` 函数，格式如下：

```typescript
{
  "success": false,
  "error": "错误描述",
  "code": "ERROR_CODE",
  "timestamp": "2025-07-17T13:21:26.593Z",
  "source": "/api/endpoint"
}
```

## 后端实现规范

### 1. 使用标准化工具函数

**正确做法：**
```typescript
import { successResponse, handleApiError } from '$lib/utils/api-error-handler';

export async function GET() {
  try {
    const data = await loadData();
    return successResponse(data, 'Data loaded successfully', '/api/endpoint');
  } catch (error) {
    return handleApiError(error, '/api/endpoint');
  }
}
```

**错误做法：**
```typescript
// ❌ 不要直接返回json()
return json({ success: true, data });

// ❌ 不要返回null或undefined
return successResponse(null, 'Success');
```

### 2. POST方法返回更新后的数据

```typescript
export async function POST({ request }) {
  try {
    const requestData = await request.json();
    
    // 处理数据
    const updatedData = await saveData(requestData);
    
    // 返回更新后的完整数据
    return successResponse(updatedData, 'Data saved successfully', '/api/endpoint');
  } catch (error) {
    return handleApiError(error, '/api/endpoint');
  }
}
```

### 3. 数据验证

```typescript
import { validateRequest } from '$lib/utils/api-error-handler';

export async function POST({ request }) {
  try {
    const data = await request.json();
    
    // 验证必填字段
    validateRequest(data, ['field1', 'field2']);
    
    // 继续处理...
  } catch (error) {
    return handleApiError(error, '/api/endpoint');
  }
}
```

## 前端处理规范

### 1. 标准API调用模式

```typescript
async function callApi() {
  try {
    const response = await fetch('/api/endpoint');
    
    if (response.ok) {
      const result = await response.json();
      
      // 检查标准化响应格式
      if (result.success && result.data) {
        // 使用 result.data
        return result.data;
      } else {
        console.error('API返回格式错误:', result);
        throw new Error(result.error || 'API响应格式无效');
      }
    } else {
      const errorResult = await response.json();
      throw new Error(errorResult.error || `HTTP ${response.status}`);
    }
  } catch (error) {
    console.error('API调用失败:', error);
    throw error;
  }
}
```

### 2. POST请求处理

```typescript
async function saveData(data: any) {
  try {
    const response = await fetch('/api/endpoint', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(data)
    });

    if (response.ok) {
      const result = await response.json();
      
      if (result.success) {
        console.log('保存成功:', result.message);
        
        // 如果返回了更新后的数据，使用它来更新本地状态
        if (result.data) {
          return result.data;
        }
      } else {
        throw new Error(result.error || '保存失败');
      }
    } else {
      throw new Error(`保存请求失败: ${response.status}`);
    }
  } catch (error) {
    console.error('保存数据失败:', error);
    throw error;
  }
}
```

### 3. 错误处理

```typescript
// 显示用户友好的错误信息
function handleApiError(error: any) {
  let message = '操作失败，请稍后重试';
  
  if (error.message) {
    // 根据错误类型显示不同消息
    if (error.message.includes('网络')) {
      message = '网络连接失败，请检查网络后重试';
    } else if (error.message.includes('权限')) {
      message = '您没有执行此操作的权限';
    } else {
      message = error.message;
    }
  }
  
  // 显示错误消息给用户
  showErrorToast(message);
}
```

## 数据文件格式规范

### 1. JSON数据文件结构

**正确格式（纯数据）：**
```json
{
  "month1": {
    "anchors": {
      "homepage-only": false,
      "natural-anchors": true
    }
  }
}
```

**错误格式（包含API包装）：**
```json
{
  "success": true,
  "data": {
    "month1": {
      "anchors": {
        "homepage-only": false
      }
    }
  },
  "message": "Success"
}
```

### 2. 文件命名约定

- 使用kebab-case：`seo-progress.json`
- 备份文件：`backlink-data-backup-20250713.json`
- 临时文件：`temp-data.json`

## API端点命名规范

### 1. RESTful风格

- GET `/api/seo-progress` - 获取SEO进度
- POST `/api/seo-progress` - 保存SEO进度
- GET `/api/backlink-data` - 获取外链数据
- POST `/api/backlink-data` - 保存外链数据

### 2. 响应时间要求

- 数据读取：< 500ms
- 数据保存：< 1000ms
- 复杂查询：< 2000ms

## 错误代码规范

### 1. 客户端错误 (4xx)

- `400 VALIDATION_ERROR` - 请求数据验证失败
- `401 UNAUTHORIZED` - 未授权访问
- `403 FORBIDDEN` - 权限不足
- `404 NOT_FOUND` - 资源不存在

### 2. 服务端错误 (5xx)

- `500 INTERNAL_ERROR` - 内部服务器错误
- `500 DATABASE_ERROR` - 数据库操作失败
- `500 FILE_ERROR` - 文件操作失败

## 日志记录规范

### 1. 成功操作日志

```typescript
console.log('[API Success]', {
  endpoint: '/api/seo-progress',
  method: 'POST',
  timestamp: new Date().toISOString(),
  dataSize: JSON.stringify(data).length
});
```

### 2. 错误日志

```typescript
console.error('[API Error]', {
  endpoint: '/api/seo-progress',
  method: 'POST',
  error: error.message,
  stack: error.stack,
  timestamp: new Date().toISOString()
});
```

## 测试要求

### 1. API端点测试

每个API端点必须测试：
- ✅ 成功情况下的响应格式
- ✅ 错误情况下的响应格式
- ✅ 数据验证的正确性
- ✅ 响应时间性能

### 2. 前端集成测试

每个前端页面必须测试：
- ✅ 正确处理成功响应
- ✅ 正确处理错误响应
- ✅ 加载状态的显示
- ✅ 数据保存后的状态更新

## 迁移检查清单

在修改现有API时，请检查：

- [ ] 是否使用了 `successResponse()` 函数
- [ ] 是否返回了实际数据而不是null
- [ ] 前端是否正确提取 `result.data`
- [ ] 数据文件是否移除了API包装格式
- [ ] 错误处理是否使用了 `handleApiError()`
- [ ] 是否添加了适当的日志记录

## 常见问题和解决方案

### 1. 前端收到undefined数据

**原因：** API返回了null或前端没有正确提取data字段

**解决：**
```typescript
// 后端
return successResponse(actualData, 'Success'); // 不要传null

// 前端
const data = result.data; // 而不是直接使用result
```

### 2. 数据保存后界面没有更新

**原因：** API没有返回更新后的数据

**解决：**
```typescript
// 后端POST方法
const updatedData = await saveData(requestData);
return successResponse(updatedData, 'Saved successfully');

// 前端
if (result.data) {
  localState = result.data; // 更新本地状态
}
```

### 3. 错误信息不够友好

**原因：** 没有使用标准化的错误处理

**解决：**
```typescript
// 使用预定义的错误类型
throw ApiErrors.ValidationError('字段不能为空', { field: 'name' });
```

## 版本历史

- v1.0.0 (2025-07-17) - 初始版本，建立基本标准
- 后续版本将记录重要的API格式变更

---

遵循这些标准将确保项目的API接口保持一致性、可维护性和用户友好性。