# Common Issues & Solutions

Comprehensive troubleshooting guide for **Vibby.ai** covering the most common issues developers and users encounter, with step-by-step solutions.

## 🔧 Quick Diagnostics

### System Health Check

Run these commands to quickly assess your system:

```bash
# Check Node.js version
node --version
# Should be 18.0.0 or higher

# Check npm/pnpm version
pnpm --version
npm --version

# Verify Git installation
git --version

# Check if development server is running
curl http://localhost:5173/api/ping
```

### Environment Validation

```bash
# Check critical environment variables
echo "NODE_ENV: $NODE_ENV"
echo "PUBLIC_SITE_URL: $PUBLIC_SITE_URL"

# Validate .env file exists
ls -la .env

# Check for common configuration issues
node -e "
const fs = require('fs');
const path = require('path');

// Check if critical files exist
const criticalFiles = [
  'package.json',
  'svelte.config.js',
  'vite.config.ts',
  'src/app.html'
];

criticalFiles.forEach(file => {
  if (fs.existsSync(file)) {
    console.log('✅', file);
  } else {
    console.log('❌', file, 'NOT FOUND');
  }
});
"
```

## 🚨 Installation & Setup Issues

### Issue: `pnpm install` Fails

**Symptoms:**
- Package installation errors
- Permission denied errors
- Network timeout errors

**Solutions:**

```bash
# Clear package manager cache
pnpm store prune
npm cache clean --force

# Fix permission issues (macOS/Linux)
sudo chown -R $(whoami) ~/.npm
sudo chown -R $(whoami) ~/.pnpm

# Use different registry if network issues
pnpm install --registry https://registry.npmjs.org/

# Alternative: Use npm instead
rm -f pnpm-lock.yaml
npm install
```

### Issue: Node.js Version Conflicts

**Symptoms:**
- "Engine not supported" errors
- Build failures with version-specific features

**Solutions:**

```bash
# Using nvm (recommended)
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash
source ~/.bashrc
nvm install 18
nvm use 18
nvm alias default 18

# Using Homebrew (macOS)
brew install node@18
brew link node@18 --force

# Verify installation
node --version
npm --version
```

### Issue: Git Clone Fails

**Symptoms:**
- Permission denied (publickey)
- Repository not found
- SSL certificate errors

**Solutions:**

```bash
# Use HTTPS instead of SSH
git clone https://github.com/your-username/vibby.ai.git

# Fix SSH key issues
ssh-keygen -t ed25519 -C "your-email@example.com"
cat ~/.ssh/id_ed25519.pub
# Add this key to your GitHub account

# Fix SSL issues
git config --global http.sslverify false  # Temporary fix
# Or update certificates
git config --global http.sslcainfo /path/to/ca-bundle.crt
```

## 🖥️ Development Server Issues

### Issue: Development Server Won't Start

**Symptoms:**
- Port already in use
- Server fails to start
- Blank page or connection refused

**Solutions:**

```bash
# Check what's using port 5173
lsof -i :5173
netstat -tulpn | grep 5173

# Kill process using the port
kill -9 [PID]

# Start on different port
pnpm dev --port 3000

# Clear SvelteKit cache
rm -rf .svelte-kit
pnpm dev

# Check for TypeScript errors
pnpm run check
```

### Issue: Hot Module Replacement (HMR) Not Working

**Symptoms:**
- Changes don't reflect automatically
- Browser doesn't update
- Console shows HMR errors

**Solutions:**

```bash
# Restart development server
pnpm dev

# Clear browser cache
# Press Ctrl+Shift+R (Windows/Linux) or Cmd+Shift+R (macOS)

# Check Vite configuration
# vite.config.ts should have:
```

```typescript
export default defineConfig({
  plugins: [sveltekit()],
  server: {
    hmr: {
      port: 5173
    }
  }
});
```

### Issue: Static Files Not Loading

**Symptoms:**
- Images, CSS, or JS files return 404
- Assets show broken links
- Static files not accessible

**Solutions:**

```bash
# Check file paths
ls -la static/
ls -la static/images/

# Verify static file references
# Correct: /images/logo.svg
# Incorrect: ./images/logo.svg or images/logo.svg

# Check Vite static handling in vite.config.ts
```

```typescript
export default defineConfig({
  plugins: [sveltekit()],
  publicDir: 'static'
});
```

## 📝 Content Management Issues

### Issue: CMS Interface Not Loading

**Symptoms:**
- `/vibbyai/cms` shows blank page
- Admin interface not accessible
- Authentication errors

**Solutions:**

```bash
# Check if admin files exist
ls -la static/admin/
cat static/admin/config.yml

# Verify CMS configuration
```

```yaml
# static/admin/config.yml should contain:
backend:
  name: git-gateway
  branch: main

media_folder: "static/uploads"
public_folder: "/uploads"

collections:
  - name: "blog"
    label: "Blog Posts"
    folder: "src/content/blog"
    # ... rest of configuration
```

```bash
# Check iframe integration
# src/routes/vibbyai/cms/+page.svelte should have:
```

```svelte
<iframe
  src="/admin"
  title="Sveltia CMS"
  class="absolute inset-0 w-full h-full border-0"
  sandbox="allow-same-origin allow-scripts allow-forms allow-popups"
></iframe>
```

### Issue: Blog Posts Not Displaying

**Symptoms:**
- Blog page shows no posts
- Individual blog posts return 404
- Content not parsing correctly

**Solutions:**

```bash
# Check blog post files
ls -la src/content/blog/
cat src/content/blog/[first-post].md

# Verify frontmatter format
```

```markdown
---
title: "Post Title"
slug: "post-slug"
date: "2024-01-15"
published: true
---

# Post content here
```

```bash
# Check content loading logic
# Verify gray-matter is processing files correctly
node -e "
const matter = require('gray-matter');
const fs = require('fs');
const file = fs.readFileSync('src/content/blog/example.md', 'utf8');
const { data, content } = matter(file);
console.log('Frontmatter:', data);
console.log('Content length:', content.length);
"
```

### Issue: Markdown Not Rendering

**Symptoms:**
- Raw markdown displayed instead of HTML
- Formatting not applied
- Code blocks not highlighted

**Solutions:**

```bash
# Install marked if missing
pnpm add marked
pnpm add @types/marked -D

# Check markdown processing
```

```typescript
// src/lib/content.ts
import { marked } from 'marked';

// Configure marked
marked.setOptions({
  gfm: true,
  breaks: true,
  headerIds: true
});

export function processMarkdown(content: string): string {
  return marked(content);
}
```

```svelte
<!-- In Svelte components -->
<div class="prose">
  {@html processedContent}
</div>
```

## 🔐 Authentication Issues

### Issue: Admin Access Denied

**Symptoms:**
- Cannot access `/vibbyai` dashboard
- Authentication redirects
- Session timeouts

**Solutions:**

```bash
# Check authentication configuration
cat src/lib/auth.ts

# Verify environment variables
echo "ENCRYPTION_SECRET: ${ENCRYPTION_SECRET:0:10}..."

# Reset admin credentials (if using simple auth)
```

```typescript
// src/lib/auth/simple-auth.ts
export const adminCredentials = {
  username: 'admin',
  password: 'your-secure-password' // Change this!
};
```

### Issue: Session Management Problems

**Symptoms:**
- Frequent logouts
- Session not persisting
- Cookie issues

**Solutions:**

```typescript
// src/hooks.server.ts
import { dev } from '$app/environment';

export async function handle({ event, resolve }) {
  // Configure session cookies
  const cookieOptions = {
    httpOnly: true,
    secure: !dev,
    sameSite: 'lax' as const,
    maxAge: 60 * 60 * 24 * 7 // 7 days
  };
  
  // Rest of auth logic
  return resolve(event);
}
```

## 🌐 API Issues

### Issue: API Endpoints Returning 404

**Symptoms:**
- `/api/*` routes not working
- Server functions not executing
- CORS errors

**Solutions:**

```bash
# Check API file structure
ls -la src/routes/api/
ls -la src/routes/api/blog/

# Verify +server.ts files exist
```

```typescript
// src/routes/api/ping/+server.ts
import { json } from '@sveltejs/kit';

export async function GET() {
  return json({ status: 'ok', timestamp: new Date().toISOString() });
}
```

```bash
# Test API endpoints
curl http://localhost:5173/api/ping
curl http://localhost:5173/api/blog/posts
```

### Issue: Database Connection Errors

**Symptoms:**
- Supabase connection timeouts
- Database query failures
- Environment variable issues

**Solutions:**

```bash
# Test Supabase connection
node -e "
const { createClient } = require('@supabase/supabase-js');
const supabase = createClient(
  process.env.PUBLIC_SUPABASE_URL,
  process.env.PUBLIC_SUPABASE_ANON_KEY
);

async function test() {
  try {
    const { data, error } = await supabase.from('test').select('*').limit(1);
    console.log('✅ Supabase connection successful');
  } catch (err) {
    console.error('❌ Supabase connection failed:', err.message);
  }
}
test();
"
```

```typescript
// src/lib/supabase.ts - Verify configuration
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseKey);
```

## 🎨 Styling Issues

### Issue: TailwindCSS Not Working

**Symptoms:**
- Styles not applying
- Utility classes not working
- CSS not generating

**Solutions:**

```bash
# Check Tailwind configuration
cat tailwind.config.js
cat postcss.config.js

# Verify content paths in tailwind.config.js
```

```javascript
module.exports = {
  content: [
    './src/**/*.{html,js,svelte,ts}',
    './src/**/*.svelte'
  ],
  theme: {
    extend: {}
  },
  plugins: []
};
```

```bash
# Check PostCSS configuration
```

```javascript
// postcss.config.js
module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {}
  }
};
```

```css
/* src/app.css - Verify Tailwind directives */
@tailwind base;
@tailwind components;
@tailwind utilities;
```

### Issue: Custom Styles Not Loading

**Symptoms:**
- CSS files not found
- Styles overridden
- Import errors

**Solutions:**

```svelte
<!-- In +layout.svelte -->
<script>
  import '../app.css';
</script>

<!-- Component-specific styles -->
<style>
  .custom-class {
    /* Custom styles here */
  }
</style>
```

```typescript
// In vite.config.ts - CSS processing
export default defineConfig({
  css: {
    preprocessorOptions: {
      scss: {
        additionalData: '@use "src/variables.scss" as *;'
      }
    }
  }
});
```

## 🏗️ Build Issues

### Issue: Production Build Fails

**Symptoms:**
- Build process errors
- TypeScript compilation failures
- Missing dependencies

**Solutions:**

```bash
# Clear build cache
rm -rf .svelte-kit dist node_modules
pnpm install
pnpm run build

# Check for TypeScript errors
pnpm run check

# Verbose build output
pnpm run build --verbose

# Check build logs
npm run build 2>&1 | tee build.log
```

### Issue: Import/Export Errors

**Symptoms:**
- Module not found errors
- Circular dependency warnings
- Dynamic import failures

**Solutions:**

```typescript
// Fix relative imports
// Instead of: import './component'
import Component from './Component.svelte';

// Fix dynamic imports
const Component = await import('./Component.svelte');

// Check tsconfig.json paths
```

```json
{
  "compilerOptions": {
    "baseUrl": ".",
    "paths": {
      "$lib": ["src/lib"],
      "$lib/*": ["src/lib/*"]
    }
  }
}
```

### Issue: Environment Variables Not Working

**Symptoms:**
- `undefined` values in production
- Variables not accessible in client
- Build-time vs runtime issues

**Solutions:**

```bash
# Check .env file location and syntax
cat .env

# Verify variable naming
# Client-side: must start with PUBLIC_
PUBLIC_SITE_URL=https://example.com

# Server-side: any name
PRIVATE_API_KEY=secret

# Check import.meta.env usage
```

```typescript
// Client-side access
const siteUrl = import.meta.env.VITE_SITE_URL; // Vite prefix
const publicUrl = import.meta.env.PUBLIC_SITE_URL; // SvelteKit prefix

// Server-side access
const privateKey = process.env.PRIVATE_API_KEY;
```

## 📱 Mobile & Browser Issues

### Issue: Mobile Layout Problems

**Symptoms:**
- Layout breaks on mobile
- Text too small
- Touch targets too small

**Solutions:**

```html
<!-- Verify viewport meta tag in app.html -->
<meta name="viewport" content="width=device-width, initial-scale=1.0">
```

```css
/* Responsive design fixes */
@media (max-width: 768px) {
  .container {
    padding: 1rem;
  }
  
  .text-responsive {
    font-size: clamp(1rem, 4vw, 1.5rem);
  }
}

/* Touch-friendly buttons */
.button {
  min-height: 44px;
  min-width: 44px;
}
```

### Issue: Browser Compatibility

**Symptoms:**
- Features not working in older browsers
- JavaScript errors in Safari/IE
- CSS not supported

**Solutions:**

```typescript
// Check browser support in vite.config.ts
export default defineConfig({
  build: {
    target: ['es2020', 'chrome80', 'firefox78', 'safari13']
  }
});
```

```javascript
// Feature detection instead of browser detection
if ('serviceWorker' in navigator) {
  // Service worker code
}

if (CSS.supports('display', 'grid')) {
  // Grid layout code
}
```

## 🔍 Performance Issues

### Issue: Slow Page Load Times

**Symptoms:**
- High lighthouse scores
- Slow Time to First Byte (TTFB)
- Large bundle sizes

**Solutions:**

```bash
# Analyze bundle size
pnpm run build
npx vite-bundle-analyzer dist

# Optimize images
npm install imagemin imagemin-webp imagemin-mozjpeg
```

```typescript
// Code splitting
export async function load() {
  const { heavyComponent } = await import('$lib/heavy-component');
  return {
    component: heavyComponent
  };
}

// Lazy loading images
<img loading="lazy" src="/image.jpg" alt="Description" />
```

### Issue: Memory Leaks

**Symptoms:**
- Browser tab crashes
- Increasing memory usage
- Performance degradation over time

**Solutions:**

```svelte
<script>
  import { onDestroy } from 'svelte';
  
  let interval;
  
  onMount(() => {
    interval = setInterval(() => {
      // Some recurring task
    }, 1000);
  });
  
  onDestroy(() => {
    if (interval) {
      clearInterval(interval);
    }
  });
</script>
```

## 🔧 Advanced Troubleshooting

### Debug Mode

Enable debug mode for detailed logging:

```bash
# Environment variable
DEBUG=true pnpm dev

# Or in .env
DEBUG=true
LOG_LEVEL=debug
```

```typescript
// src/lib/debug.ts
export function debug(message: string, data?: any) {
  if (import.meta.env.MODE === 'development' || process.env.DEBUG) {
    console.log(`[DEBUG] ${message}`, data);
  }
}
```

### Network Issues

```bash
# Test API connectivity
curl -v http://localhost:5173/api/ping

# Check DNS resolution
nslookup yourdomain.com
dig yourdomain.com

# Test SSL certificate
openssl s_client -connect yourdomain.com:443
```

### Performance Profiling

```bash
# Install clinic.js for Node.js profiling
npm install -g clinic

# Profile application
clinic doctor -- node build/index.js
clinic flame -- node build/index.js
clinic bubbleprof -- node build/index.js
```

## 📞 Getting Help

### Self-Diagnosis Checklist

Before seeking help, try these steps:

1. **Check Recent Changes**
   - What was the last thing you changed?
   - Can you reproduce the issue?
   - Does it happen in incognito mode?

2. **Verify Environment**
   - Are all dependencies installed?
   - Are environment variables set correctly?
   - Is the development server running?

3. **Check Logs**
   - Browser console errors
   - Terminal/command line output
   - Network tab in browser dev tools

4. **Test in Clean Environment**
   - Fresh git clone
   - Clean npm install
   - Default configuration

### Log Collection

```bash
# Collect comprehensive system info
echo "=== System Information ===" > debug-info.txt
echo "Node.js: $(node --version)" >> debug-info.txt
echo "npm: $(npm --version)" >> debug-info.txt
echo "OS: $(uname -a)" >> debug-info.txt
echo "" >> debug-info.txt

echo "=== Package.json ===" >> debug-info.txt
cat package.json >> debug-info.txt
echo "" >> debug-info.txt

echo "=== Environment ===" >> debug-info.txt
env | grep -E "NODE_|PUBLIC_|VITE_" >> debug-info.txt
echo "" >> debug-info.txt

echo "=== Build Output ===" >> debug-info.txt
npm run build 2>&1 >> debug-info.txt
```

### Community Support

- **GitHub Issues**: [Report bugs and issues](https://github.com/your-repo/vibby.ai/issues)
- **Discussions**: [Ask questions and share tips](https://github.com/your-repo/vibby.ai/discussions)
- **Discord**: [Join our community chat](https://discord.gg/vibby-ai)
- **Stack Overflow**: Tag questions with `vibby-ai` and `sveltekit`

### Professional Support

For enterprise users requiring immediate assistance:
- **Priority Support**: support@vibby.ai
- **Emergency Hotline**: +1-555-VIBBY-AI
- **Consulting Services**: consulting@vibby.ai

---

**🔧 Troubleshooting Complete!** Most issues can be resolved with these solutions. If you're still experiencing problems, don't hesitate to reach out to our community or support team.

**Next Steps**: [Performance Optimization](./performance.md) or [Error Messages Reference](./error-messages.md)